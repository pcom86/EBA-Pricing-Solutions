"""Product recipes — declarative ingredient lists per product."""

# ============================================================
# GLA
# ============================================================
GLA = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data",
    "cover_column":          "gla",
    "apply_tax_gross_up":    True,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",

    "rate_factors": [
        {"kind": "mortality",   "product": "gla",  "age_col": "age_nb"},
        {"kind": "salary_band", "product": "gla",  "factor": "inc_adj"},
        {"kind": "salary_band", "product": "gla",  "factor": "acaf_adj"},
        {"kind": "industry",    "product": "gla",  "factor": "inc_adj",  "by_scheme_size": True},
        {"kind": "industry",    "product": "gla",  "factor": "acaf_adj", "by_scheme_size": True},
        {"kind": "trend",       "product": "gla"},
    ],
    "aids_factors": [],
    "add_ons": ["co_premium_gla"],
    "profit_margin_key":     ("gla", "standard"),
    "profit_margin_dc_key":  ("gla", "dc"),
}


# ============================================================
# LSDB
# Two nuances vs GLA:
#   1. Members with Status="DB" pay 0 premium (already disabled → can't
#      re-disable). Enforced via zero_when_status_in.
#   2. Profit margin depends on cover source:
#        Cover in member data -> 9.5% (DC variant)
#        Multiple of Salary   -> 7.5% (Standard variant)
#   3. Profit margin basis is NET RISK (basic + aids), NOT total_annual.
#      TT LSDB!BR4 = BO4*AZ4 = qx × cover = net_risk × margin_rate.
#      Amazon didn't catch this because Amazon LSDB has co_premium=0,
#      so total_annual == net_risk on that scheme. Hulamin surfaced it
#      via its 243,582 of LSDB CO — engine excess of 18,268.67 = 7.5% of CO.
# ============================================================
LSDB = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data",
    "cover_column":          "lsdb",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",

    "rate_factors": [
        {"kind": "mortality",         "product": "lsdb", "age_col": "age_nb"},
        {"kind": "salary_band",       "product": "lsdb", "factor": "inc_adj"},
        {"kind": "salary_band",       "product": "lsdb", "factor": "acaf_adj"},
        {"kind": "industry",          "product": "lsdb", "factor": "inc_adj",  "by_scheme_size": True},
        {"kind": "industry",          "product": "lsdb", "factor": "acaf_adj", "by_scheme_size": True},
        {"kind": "waiting_pd",        "product": "lsdb"},
        {"kind": "baseline_yr",       "product": "lsdb", "factor": "baseline_adj"},
        {"kind": "product_type_adj",  "product": "lsdb"},
    ],

    "aids_factors": [],
    "add_ons": ["co_premium_lsdb"],

    # Zero premium for already-disabled members
    "zero_when_status_in": ("DB",),
    "ineligible_status":   ("DB",),

    # Cover-type-driven margin selection
    "profit_margin_key_by_cover_type": {
        # TT: LSDB!BR4 = net_risk * IF(cover_type="Multiple", Profit_Margin_LSDB,
        # Profit_Margin_LSDB_DC).  Multiple -> 0.075; ALL DC-style cover types
        # ("Cover in member data" AND "Age Bands(Cover in Member data...)") -> 0.095.
        # Prior map sent Age-Bands members to _default=standard, undercharging profit
        # by 106,249.77 (blended 0.083395 vs TT 0.090103).
        "Multiple": ("lsdb", "standard"),   # 0.075
        "_default": ("lsdb", "dc"),         # 0.095 — every non-Multiple cover type
    },
    # profit_margin_basis defaults to 'net_risk' — do NOT set to 'total_annual'.
    # TT LSDB!BR4 = BO4 * AZ4 = qx × cover = net_risk × margin.
}

# ============================================================
# ACCIDENT DEATH
# ============================================================
ACCIDENT_DEATH = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data",
    "cover_column":          "accident_death",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",

    "cover_caps": [
        {"kind": "category_max_cover_field", "field": "maximum_cover"},
        {"kind": "cap_by_prior_cover", "prior": "gla"},
    ],

    "rate_factors": [
        {"kind": "mortality",     "product": "adb",  "age_col": "age_nb"},
        {"kind": "salary_factor", "product": "adb"},
    ],

    "aids_factors": [],
    "add_ons": [],
    "profit_margin_key": ("adb", "standard"),
}


# ============================================================
# ACCIDENT DISABILITY
# ============================================================
ACCIDENT_DISABILITY = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data",
    "cover_column":          "accident_db",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",
    "zero_when_status_in": ("DB",),

    "cover_caps": [
        {"kind": "category_max_cover_field", "field": "maximum_cover"},
        {"kind": "cap_by_lsdb_or_gla"},
    ],

    "rate_factors": [
        {"kind": "mortality",     "product": "accdb",  "age_col": "age_nb"},
        {"kind": "salary_factor", "product": "accdb"},
    ],

    "aids_factors": [],
    "add_ons": [],
    "profit_margin_key": ("accdb", "standard"),
}


# ============================================================
# DISMEMBERMENT
# ============================================================
DISMEMBERMENT = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data",
    "cover_column":          "dismemberment",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",
    "zero_when_status_in": ("DB",),

    "cover_caps": [
        {"kind": "category_max_cover_field", "field": "maximum_cover"},
        {"kind": "cap_by_lsdb_or_gla"},
    ],

    "rate_factors": [
        {"kind": "mortality",     "product": "dism",  "age_col": "age_nb"},
        {"kind": "salary_factor", "product": "dism"},
    ],

    "aids_factors": [],
    "add_ons": [],
    "profit_margin_key": ("dismem", "standard"),
}


# ============================================================
# TERMINAL ILLNESS
# Excel: premium = GLA_basic × TI_factor × TI_cover / GLA_cover
# Uses ti_factors table (cost_basis × age × gender)
# ============================================================
TERMINAL = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data_or_gla",   # new: 'Set equal to GLA Cover' handling
    "cover_column":          "terminal_illness",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",

    "cover_caps": [
        {"kind": "category_max_cover_field", "field": "maximum_cover"},
    ],

    # NO rate_factors — Terminal uses a bespoke premium formula
    "rate_factors": [],
    "aids_factors": [],
    "add_ons": [],

    # Special hook: bypass normal Step 7, compute premium via ti_scales_gla
    "special_premium": {
        "kind": "ti_scales_gla",
        "cost_basis_map": {
            "first_year_no_spread":  "first_year",   # cats first_year_of_cover=Yes AND spread=No
            "first_year_spread":     "uniform",      # spread=Yes
            "ongoing":               "ongoing",      # default
        },
    },

    "profit_margin_key": ("ti", "standard"),
}

# ============================================================
# SPOUSE GLA
# BJ1 flag (CatInput - Save cell BJ1) drives BOTH the member source
# AND the mortality treatment:
#   BJ1 = No  -> members from GLA sheet, mortality gender-SWAPPED
#               (main member proxies spouse; look up opposite gender)
#   BJ1 = Yes -> members from SP sheet, mortality NORMAL
#               (spouse's own gender, straight lookup on GLA basis)
# All other factors are identical across the two paths.
# ============================================================
SPOUSE_GLA = {
    "member_source":         "spouse_dynamic",   # resolved in engine from ctr.scheme.spouse_use_sp_sheet
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data",
    "cover_column":          "spouse_s_life_cover",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",

    "cover_caps": [
        {"kind": "spouse_cover_cap", "prior": "gla",
         "max_multiple_key": ("spouse_gla", "max_multiple")},
        {"kind": "category_max_cover_field", "field": "max_spouse_cover"},
    ],

    # Twin factor lists — engine picks based on scheme.spouse_use_sp_sheet.
    # Only the mortality factor differs; all other factors are identical.
    "rate_factors_gla_source": [
        # L1 = No: member proxies spouse -> gender-swapped mortality on GLA basis
        {"kind": "mortality_gender_swap", "product": "gla", "age_col": "age_nb"},
        {"kind": "salary_band", "product": "gla", "factor": "inc_adj"},
        {"kind": "salary_band", "product": "gla", "factor": "acaf_adj"},
        {"kind": "industry",    "product": "gla", "factor": "inc_adj",  "by_scheme_size": True},
        {"kind": "industry",    "product": "gla", "factor": "acaf_adj", "by_scheme_size": True},
        {"kind": "trend",       "product": "gla"},
    ],
    "rate_factors_sp_source": [
        # L1 = Yes: TT applies the GENDER SWAP even in the SP-data path. Verified
        # rand-perfect: gla-M@63F rate 15.872709 = TT W4, engine qx*(M/F)=0.019285342.
        # F members read M rate (up), M members read F rate (down); net risk
        # 15,309,251 -> 15,059,936. Uses existing mortality_gender_swap machinery.
        {"kind": "mortality_gender_swap", "product": "gla", "age_col": "age_nb"},
        {"kind": "salary_band", "product": "gla", "factor": "inc_adj"},
        {"kind": "salary_band", "product": "gla", "factor": "acaf_adj"},
        {"kind": "industry",    "product": "gla", "factor": "inc_adj",  "by_scheme_size": True},
        {"kind": "industry",    "product": "gla", "factor": "acaf_adj", "by_scheme_size": True},
        {"kind": "trend",       "product": "gla"},
    ],

    "aids_factors": [],
    "add_ons": ["co_premium_spouse"],
    "profit_margin_key_by_cover_type": {
    "Cover in member data": ("gla", "dc"),
    "_default":             ("gla", "standard"),
},
"profit_margin_basis": "total_annual",     # spouse GLA multiplies by total, not net risk
}


# ============================================================
# SPOUSE LSDB
# Uses spouse basis (not swapped), spouse_factors × DB_definition.
# BJ1 flag drives ONLY the member source. Everything else identical:
#   BJ1 = No  -> members from GLA sheet
#   BJ1 = Yes -> members from SP sheet
# Mortality is looked up on the spouse basis using whatever gender
# is on the sourced row (no swap in either mode).
# ============================================================
SPOUSE_LSDB = {
    "member_source":         "spouse_dynamic",   # resolved in engine from ctr.scheme.spouse_use_sp_sheet
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data",
    "cover_column":          "spouse_s_db",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",

    "cover_caps": [
        {"kind": "spouse_cover_cap", "prior": "gla",
         "max_multiple_key": ("spouse_lsdb", "max_multiple")},
        {"kind": "cap_by_assumption_limit",
         "product_key": "spouse_lsdb", "param_key": "max_cover"},
    ],

    "rate_factors": [
        {"kind": "mortality",   "product": "spouse", "age_col": "age_nb"},
        {"kind": "salary_band", "product": "spouse", "factor": "inc_adj"},
    ],

    "post_rate_adjust": [
        {"kind": "spouse_factor_multiplicative"},
        {"kind": "spouse_db_definition_multiplicative"},
    ],

    "aids_factors": [],
    "add_ons": [],
    "profit_margin_key_by_cover_type": {
    "Cover in member data": ("gla",  "dc"),        # 8% — Profit_Margin_GLA_DC
    "_default":             ("lsdb", "standard"),  # 7.5% — Profit_Margin_LSDB (for cover_type="Multiple")
},
    "profit_margin_basis": "total_annual",
}

# ============================================================
# CI
# Excel: dynamic mortality table selection + industry loading + optional reinstatement
# ============================================================
CI = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "multiple_or_data",
    "cover_column":          "ci",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",

    "cover_caps": [
        {"kind": "category_max_cover_field", "field": "maximum_cover_amount"},
        {"kind": "cap_by_prior_cover", "prior": "gla"},   # only if accelerator
    ],

    "rate_factors": [
    {"kind": "ci_mortality_dynamic"},        # AL step 1: base mortality (correct table + ALB/ANB + gender)
    {"kind": "ci_standalone_loading"},       # AL step 2: × 1.20 for Standalone + New (else no-op)
    {"kind": "ci_industry_loading"},         # AN: × class_loading (0.80 for Class B / Wholesale & Retail Trade)
],

    "aids_factors": [],

    # CI Excel col BC = BB (no post-adjust for accelerator new products)
    "add_ons": ["co_premium_ci"],

    # Note: CI uses LSDB profit margin per Excel col BL
    "profit_margin_key":   ("lsdb", "standard"),
    "profit_margin_basis": "net_risk",
}


# ============================================================
# FAMILY COVER (FC)
# BASIS: mostly GLA (mortality, salary_band, industry, trend).
# FC-specific: fc_rates (child rates), fc_demographics (family size),
#              fc_family_composition (parents/in-laws), fc_db_loading.
#
# Non-standard patterns vs other products:
#   1. Composite cover — NOT a single per-member cover column.
#      cover = benefit_primary
#            + pct_married × benefit_spouse × second_spouse_loading
#            + n_kids_0_13 × benefit_child_6_13
#            + n_kids_14+ × benefit_child_14_plus
#            + (n_parents + n_in_laws × pct_married) × benefit_parents_cover
#      Implemented via `special_premium` hook (like TERMINAL).
#
#   2. Composite premium — sums 4 sub-premiums (member, spouse, kids_0_13,
#      kids_14+) each with its own rate factor set. Also handled inside
#      the special_premium hook so we don't need N rate_factors passes.
#
#   3. DB status is a LOADING (BA4), not a zero-out. Handled via new
#      `db_loading` recipe key, not `zero_when_status_in`.
#
#   4. Second-spouse loading (AZ4 = 1 + scalar × (max_spouses - 1)) applied
#      via post_rate_adjust — reads SchemeRecord.fc_max_no_of_spouses.
#
#   5. PUP cost (BI4) routes on V/W/X per-category selections to one of
#      three product_limits scalars. Handled as an add_on.
#
#   6. Profit margin uses Profit_Margin_GLA (not FC-specific), basis is
#      net_risk (BN × margin), consistent with LSDB / CI convention.
# ============================================================
# FAMILY COVER (FC)
# ============================================================
FC = {
    "member_source":         "fc_sheet",
    "age_from":              "commencement",
    "cover_rule":            "fc_composite",
    "cover_column":          "fc_cover",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",

    "cover_caps": [],
    "rate_factors": [],
    "aids_factors": [],
    "post_rate_adjust": [],
    "add_ons": [],

    "skip_prb_premium": True,      # ← MOVED HERE (top-level recipe key)

    "special_premium": {
        "kind": "fc_composite",
        "namibia_rate_cut_global": "namibia_competitive_factor",
        "db_gate_global": "active_selection_db_load",
    },

    "profit_margin_key":   ("gla", "standard"),
    "profit_margin_basis": "net_risk",

    "zero_when_status_in": (),
}

# ============================================================
# GROUP INCOME PROTECTION (GIP)
# Composite premium: DF = DC(incidence) · DD(cover=BA) · DE(annuity=FS)
# + HCC stream (DB) + CO (DH) + reinsurance (FH-FJ).
# Two benefit ladders (core + extended/HCC), bilinear NRA×ESC annuity.
# Tax via cascade (2026-2027_gip + primary_rebate), NOT GLA gross-up.
# ============================================================
GIP = {
    "member_source":       "gip_sheet",
    "age_from":            "commencement",
    "cover_rule":          "gip_composite",
    "cover_column":        "gip_cover",
    "apply_tax_gross_up":  False,            # tax handled inside cascade
    "ceasing_source":      "nra_only",
    "nra_source":          "category_or_custom",
    "cover_caps":          [],
    "rate_factors":        [],               # incidence built inside composite hook
    "aids_factors":        [],
    "post_rate_adjust":    [],
    "add_ons":             [],
    "special_premium":     {"kind": "gip_composite"},
    "profit_margin_key":   ("gip", "standard"),
    "profit_margin_basis": "annuity_pv",     # NEW basis mode
    "skip_prb_premium":    True,
    "zero_when_status_in": (),
}

TIP = {
    "member_source":       "tip_sheet",
    "age_from":            "commencement",
    "cover_rule":          "tip_composite",
    "cover_column":        "tip_cover",
    "apply_tax_gross_up":  False,
    "ceasing_source":      "nra_only",
    "nra_source":          "category_or_custom",
    "cover_caps":          [],
    "rate_factors":        [],
    "aids_factors":        [],
    "post_rate_adjust":    [],
    "add_ons":             [],
    "special_premium":     {"kind": "tip_composite"},
    "profit_margin_key":   ("gip", "standard"),   # or ("gip","standard") if TIP shares
    "profit_margin_basis": "annuity_pv",
    "skip_prb_premium":    True,
    "zero_when_status_in": (),
}


# ============================================================
# EDUCATION GUARDIAN
# Rate chain = GLA's exact 6 factors (mortality, salary inc/acaf,
# industry inc/acaf, trend) -- confirmed via live TT "Education" sheet
# formula trace (col AC "GLA Basic" = V*W*X*Y*Z*AA, identical lookups
# to GLA itself). Cover = bespoke age(gender-adjusted) x salary-band
# table (education_guardian_cover / _salary_bands basis tables, Piece
# 3a), NOT a member-data column or simple multiple. Premium = cover x
# GLA rate chain (edu Basic Premium = AJ x AC), implemented via
# special_premium hook since cover_rule alone can't express the table
# lookup declaratively. Confirmed 2026-08-18.
# ============================================================
EDUCATION_GUARDIAN = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "education_guardian_composite",
    "cover_column":          "education_guardian_cover",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",
    "rate_factors": [
        {"kind": "mortality",   "product": "gla", "age_col": "age_nb"},
        {"kind": "salary_band", "product": "gla", "factor": "inc_adj"},
        {"kind": "salary_band", "product": "gla", "factor": "acaf_adj"},
        {"kind": "industry",    "product": "gla", "factor": "inc_adj",  "by_scheme_size": True},
        {"kind": "industry",    "product": "gla", "factor": "acaf_adj", "by_scheme_size": True},
        {"kind": "trend",       "product": "gla"},
    ],
    "aids_factors": [],
    "special_premium": {"kind": "education_guardian_composite"},
    "profit_margin_key": ("gla", "standard"),   # borrows GLA margins (no Guardian-specific margin table found)
}


# ============================================================
# EDUCATE A CHILD
# Rate chain = GLA's exact 6 factors (mortality, salary inc/acaf,
# industry inc/acaf, trend) -- same reuse as education_guardian,
# confirmed via live TT "Education" sheet formula trace (col AC "GLA
# Basic" = V*W*X*Y*Z*AA). Cover = MIN(Multiple x Annual Salary, Category
# Max Cover) -- confirmed 2026-08-19 via a live test CTR with this
# variant genuinely active (CatInput-Save col 133 = "Multiple", matching
# TT's AH formula's primary branch: IF(AE="Multiple", AF*salary, ...)).
# Premium = cover x GLA rate chain, same shape as education_guardian.
# ============================================================
EDUCATE_A_CHILD = {
    "member_source":         "gla_sheet",
    "age_from":              "commencement",
    "cover_rule":            "educate_a_child_composite",
    "cover_column":          "education_cover",
    "apply_tax_gross_up":    False,
    "ceasing_source":        "deferred_or_nra",
    "nra_source":            "category_or_custom",
    "rate_factors": [
        {"kind": "mortality",   "product": "gla", "age_col": "age_nb"},
        {"kind": "salary_band", "product": "gla", "factor": "inc_adj"},
        {"kind": "salary_band", "product": "gla", "factor": "acaf_adj"},
        {"kind": "industry",    "product": "gla", "factor": "inc_adj",  "by_scheme_size": True},
        {"kind": "industry",    "product": "gla", "factor": "acaf_adj", "by_scheme_size": True},
        {"kind": "trend",       "product": "gla"},
    ],
    "aids_factors": [],
    "special_premium": {"kind": "educate_a_child_composite"},
    "profit_margin_key": ("gla", "standard"),
}


RECIPES = {
    "gla":                 GLA,
    "lsdb":                LSDB,
    "accident_death":      ACCIDENT_DEATH,
    "accident_disability": ACCIDENT_DISABILITY,
    "dismemberment":       DISMEMBERMENT,
    "terminal":            TERMINAL,
    "spouse_gla":          SPOUSE_GLA,
    "spouse_lsdb":         SPOUSE_LSDB,
    "ci":                  CI,
    "fc":                  FC,
    "gip":                 GIP,
    "tip":                 TIP,
    "education_guardian":  EDUCATION_GUARDIAN,
    "educate_a_child":     EDUCATE_A_CHILD,
}