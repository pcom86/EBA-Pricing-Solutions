"""Pricing engine helpers — all primitives used by the generic engine."""
from __future__ import annotations
from datetime import date
from typing import Any
import math
import polars as pl
import calendar
import re

# Products registry lives in a sibling folder — path is set by test cell
try:
    from products_registry import resolve_ci_mortality_table
except ImportError:
    resolve_ci_mortality_table = None


# ============================================================
# 1. AGE
# ============================================================
def compute_age(df: pl.DataFrame, comm_date: date) -> pl.DataFrame:
    """Compute age columns for pricing.

    Returns:
      age    -> exact age (float, e.g. 37.048)
      age_lb -> Age Last Birthday (floor of exact age).  Used by CI "New" tables.
      age_nb -> Age Next Birthday (floor + 1).           Used by GLA, LSDB, ADB, etc.
    """
    days = (pl.lit(comm_date) - pl.col("date_of_birth")).dt.total_days()
    age_exact = days / 365.25
    age_floor = age_exact.floor().cast(pl.Int64)
    return df.with_columns([
        age_exact.alias("age"),
        age_floor.alias("age_lb"),
        age_floor.add(1).alias("age_nb"),
    ])


# ============================================================
# 2. CATEGORY ATTACHMENT
# ============================================================
def pivot_categories_wide(categories: pl.DataFrame, product_key: str) -> pl.DataFrame:
    sub = categories.filter(pl.col("product") == product_key)
    if sub.height == 0:
        return pl.DataFrame(schema={"category_number": pl.Int64})
    wide = sub.pivot(values="value", index="category_number", on="field")
    if "category_flag" in wide.columns:
        wide = wide.with_columns(
            pl.col("category_flag").cast(pl.Float64, strict=False).alias("category_flag_join")
        )
    return wide


def attach_category(df: pl.DataFrame, cats_wide: pl.DataFrame) -> pl.DataFrame:
    # Defensive guard: no category_flag_join column means cats_wide is
    # empty (0 rows) -- e.g. a product whose CatInput-Save block was never
    # extracted into categories_df because it wasn't yet in active_products
    # at parse time (education_guardian: its own bespoke reader populates
    # ctx.scheme.education_* fields directly rather than categories_df).
    # Fall back to deriving category_number directly from the member's own
    # category_flag using the CTR's scheme-wide numbering convention
    # (category_flag = 999 + category_number, i.e. Cat 1 -> 1000, Cat 2 ->
    # 1001, ...) -- confirmed 2026-08-18 against GLA's own extracted
    # categories_df AND raw Member Data - GLA category_flag values.
    if "category_flag_join" not in cats_wide.columns:
        if "category_flag" in df.columns and "category_number" not in df.columns:
            df = df.with_columns(
                (pl.col("category_flag").cast(pl.Float64, strict=False) - 999)
                .cast(pl.Int64, strict=False)
                .alias("category_number")
            )
        return df
    return df.join(cats_wide, left_on="category_flag",
                   right_on="category_flag_join", how="left", suffix="_cat")


# ============================================================
# 3. PRODUCT ACTIVE + NRA + CEASING
# ============================================================
def mark_product_active(df: pl.DataFrame,
                         scheme_rating: str | None,
                         active_categories: tuple[int, ...]) -> pl.DataFrame:
    scheme_on = scheme_rating is not None and scheme_rating.strip().lower() != "no"
    return df.with_columns(
        (pl.lit(scheme_on) &
         pl.col("category_number").is_in(list(active_categories))
        ).alias("product_active")
    )


def resolve_nra(df: pl.DataFrame,
                custom_col: str = "nra",
                category_col: str = "nra_cat") -> pl.DataFrame:
    have_cat = category_col in df.columns
    have_custom = custom_col in df.columns

    if not have_cat and not have_custom:
        return df.with_columns(pl.lit(65.0).alias("nra_final"))
    if not have_cat:
        return df.with_columns(
            pl.col(custom_col).cast(pl.Float64, strict=False)
              .fill_null(65.0).alias("nra_final")
        )
    nra_cat_str = pl.col(category_col).cast(pl.Utf8, strict=False)
    if have_custom:
        return df.with_columns(
            pl.when(nra_cat_str.str.starts_with("Custom"))
              .then(pl.col(custom_col).cast(pl.Float64, strict=False))
              .otherwise(pl.col(category_col).cast(pl.Float64, strict=False))
              .fill_null(65.0)
              .alias("nra_final")
        )
    return df.with_columns(
        pl.col(category_col).cast(pl.Float64, strict=False).fill_null(65.0).alias("nra_final")
    )


def compute_ceasing_age(df: pl.DataFrame, mode: str) -> pl.DataFrame:
    """Fall back to NRA when deferred fields are absent (accident products, TI, etc.)."""
    if mode == "nra_only":
        return df.with_columns(pl.col("nra_final").alias("ceasing_age"))

    if mode == "deferred_or_nra":
        has_deferred = "deferred_retirals" in df.columns
        has_deferred_age = "deferred_retirement_age" in df.columns
        if not has_deferred or not has_deferred_age:
            return df.with_columns(pl.col("nra_final").alias("ceasing_age"))
        deferred_on = pl.col("deferred_retirals").cast(pl.Utf8) == "Yes"
        return df.with_columns(
            pl.when(pl.col("status") == "DB").then(pl.col("nra_final"))
              .when(deferred_on)
              .then(pl.col("deferred_retirement_age").cast(pl.Float64, strict=False))
              .otherwise(pl.col("nra_final"))
              .alias("ceasing_age")
        )
    raise ValueError(f"Unknown ceasing mode: {mode}")


# ============================================================
# 4. RATE FACTOR ENGINE
# ============================================================
def apply_factor(df, factor, basis_tables, assump_tables, ctx, target="rate_basic"):
    kind = factor["kind"]
    if kind == "mortality":              return _apply_mortality(df, factor, basis_tables, target)
    if kind == "mortality_gender_swap":  return _apply_mortality_gender_swap(df, factor, basis_tables, target)
    if kind == "salary_band":            return _apply_salary_band(df, factor, basis_tables, target)
    if kind == "salary_factor":          return _apply_salary_factor(df, factor, basis_tables, target)
    if kind == "industry":               return _apply_industry(df, factor, basis_tables, ctx, target)
    if kind == "trend":                  return _apply_trend(df, factor, basis_tables, ctx, target)
    if kind == "waiting_pd":             return _apply_waiting_pd(df, factor, basis_tables, target)
    if kind == "baseline_yr":            return _apply_baseline_yr(df, factor, basis_tables, ctx, target)
    if kind == "product_type_adj":       return _apply_product_type_adj(df, factor, basis_tables, ctx, target)
    if kind == "ci_standalone_loading":  return _apply_ci_standalone_loading(df, factor, assump_tables, ctx, target)
    if kind == "ci_industry_loading":    return _apply_ci_industry_loading(df, factor, basis_tables, ctx, target)
    if kind == "ci_mortality_dynamic":
        enriched = {**factor, "_ctx_ci_rating": ctx.scheme.rating.get("ci", "")}
        return _apply_ci_mortality_dynamic(df, enriched, basis_tables, assump_tables, target)
    raise ValueError(f"Unknown factor kind: {kind}")


def _apply_mortality(df, factor, basis, target):
    product = factor["product"]
    age_col = factor.get("age_col", "age_nb")
    mort = basis["mortality"].filter(pl.col("product") == product)\
                              .select(["age", "gender", "rate"])\
                              .rename({"rate": f"__mort_{product}"})
    mort = mort.with_columns([
        pl.col("age").cast(pl.Int64),
        pl.col("gender").cast(pl.Utf8),
    ])
    df = df.with_columns([
        pl.col(age_col).cast(pl.Int64).alias(age_col),
        pl.col("gender").cast(pl.Utf8),
    ])
    df = df.join(mort, left_on=[age_col, "gender"],
                       right_on=["age", "gender"], how="left")
    df = df.with_columns(
        (pl.col(target).fill_null(1.0) *
         pl.col(f"__mort_{product}").fill_null(0.0)).alias(target)
    ).drop(f"__mort_{product}")
    return df


def _apply_ci_mortality_dynamic(df, factor, basis, assump, target):
    """CI dynamic mortality: table depends on product_option × variant."""
    if resolve_ci_mortality_table is None:
        raise RuntimeError("products_registry.resolve_ci_mortality_table not importable")

    ci_map_tbl = assump["ci_table_mapping"]
    ci_rating = factor.get("_ctx_ci_rating") or ""
    variant = ci_rating.strip().lower()
    if variant not in ("accelerator", "standalone"):
        raise ValueError(
            f"[ci_mortality_dynamic] cannot resolve variant from scheme rating "
            f"'{ci_rating!r}' — expected 'Accelerator' or 'Standalone'."
        )

    if "product_option" not in df.columns:
        return df.with_columns([
            (pl.col(target) * pl.lit(0.0)).alias(target),
            pl.lit("Existing").alias("__ci_variant_type"),
        ])

    unique_opts = df["product_option"].unique().drop_nulls().to_list()

    resolutions = {}
    for opt in unique_opts:
        try:
            resolutions[opt] = resolve_ci_mortality_table(ci_map_tbl, opt, variant)
        except KeyError:
            continue

    if not resolutions:
        return df.with_columns([
            (pl.col(target) * pl.lit(0.0)).alias(target),
            pl.lit("Existing").alias("__ci_variant_type"),
        ])

    res_df = pl.DataFrame([
        {
            "product_option": opt,
            "__ci_mort_product": r["table_key"],
            "__ci_age_def":      r["age_definition"],
            "__ci_variant_type": r["variant_type"],
        }
        for opt, r in resolutions.items()
    ])
    df = df.join(res_df, on="product_option", how="left")

    df = df.with_columns([
        pl.col("age").floor().cast(pl.Int64).alias("__age_lb"),
        pl.col("age_nb").cast(pl.Int64).alias("__age_nb_int"),
    ])
    df = df.with_columns(
        pl.when(pl.col("__ci_age_def") == "ALB")
          .then(pl.col("__age_lb"))
          .otherwise(pl.col("__age_nb_int"))
          .alias("__ci_lookup_age")
    )

    needed_products = list({r["table_key"] for r in resolutions.values()})
    mort = basis["mortality"].filter(pl.col("product").is_in(needed_products))\
                              .select(["product", "age", "gender", "rate"])\
                              .rename({"product": "__ci_mort_product", "rate": "__ci_mort_rate"})
    mort = mort.with_columns([
        pl.col("age").cast(pl.Int64),
        pl.col("gender").cast(pl.Utf8),
    ])

    df = df.with_columns([pl.col("gender").cast(pl.Utf8)])
    df = df.join(
        mort,
        left_on=["__ci_mort_product", "__ci_lookup_age", "gender"],
        right_on=["__ci_mort_product", "age", "gender"],
        how="left",
    )

    df = df.with_columns(
        (pl.col(target).fill_null(1.0) * pl.col("__ci_mort_rate").fill_null(0.0)).alias(target)
    )
    return df.drop(["__ci_mort_product", "__ci_age_def", "__age_lb", "__age_nb_int",
                    "__ci_lookup_age", "__ci_mort_rate"])


def _apply_mortality_gender_swap(df, factor, basis, target):
    """Mortality with gender swapped (spouse of M looks up F, and vice versa)."""
    product = factor["product"]
    age_col = factor.get("age_col", "age_nb")
    mort = basis["mortality"].filter(pl.col("product") == product)\
                              .select(["age", "gender", "rate"])\
                              .rename({"rate": f"__mort_{product}"})
    mort = mort.with_columns([
        pl.col("age").cast(pl.Int64),
        pl.col("gender").cast(pl.Utf8),
    ])
    df = df.with_columns([
        pl.col(age_col).cast(pl.Int64).alias(age_col),
        pl.col("gender").cast(pl.Utf8),
        pl.when(pl.col("gender") == "M").then(pl.lit("F"))
          .when(pl.col("gender") == "F").then(pl.lit("M"))
          .otherwise(pl.col("gender"))
          .alias("__swapped_gender"),
    ])
    df = df.join(
        mort,
        left_on=[age_col, "__swapped_gender"],
        right_on=["age", "gender"],
        how="left",
    )
    df = df.with_columns(
        (pl.col(target).fill_null(1.0) *
         pl.col(f"__mort_{product}").fill_null(0.0)).alias(target)
    ).drop([f"__mort_{product}", "__swapped_gender"])
    return df


def _apply_salary_band(df, factor, basis, target):
    product = factor["product"]
    which = factor["factor"]
    sb = basis["salary_band"].filter(pl.col("product") == product)

    genders_in_sb = set(sb["gender"].unique().to_list())
    use_both = genders_in_sb == {"both"}

    if which == "inc_adj":
        candidates = ["inc_adj", "inc_adj/Salary Factor", "Salary Factor"]
    elif which == "acaf_adj":
        candidates = ["acaf_adj"]
    else:
        candidates = [which]
    src_col = next((c for c in candidates if c in sb.columns), None)
    if src_col is None:
        raise ValueError(f"salary_band[{product}]: no value column for '{which}'. Cols: {sb.columns}")

    sb_clean = sb.select(["gender", "salary_from", src_col])\
                 .rename({src_col: f"__sb_{which}",
                          "salary_from": f"__sb_from_{which}"})
    sb_clean = sb_clean.with_columns([
        pl.col(f"__sb_from_{which}").cast(pl.Float64, strict=False),
        pl.col(f"__sb_{which}").cast(pl.Float64, strict=False),
    ]).drop_nulls(f"__sb_from_{which}").sort(["gender", f"__sb_from_{which}"])

    df = df.with_columns(pl.col("annual_salary").cast(pl.Float64, strict=False))

    if use_both:
        sb_g = sb_clean.filter(pl.col("gender") == "both").drop("gender")\
                       .sort(f"__sb_from_{which}")
        df = df.sort("annual_salary").join_asof(
            sb_g, left_on="annual_salary",
                  right_on=f"__sb_from_{which}", strategy="backward"
        )
    else:
        parts = []
        for g in ("M", "F"):
            sg = sb_clean.filter(pl.col("gender") == g).drop("gender")\
                         .sort(f"__sb_from_{which}")
            dg = df.filter(pl.col("gender") == g).sort("annual_salary")
            if sg.height and dg.height:
                dg = dg.join_asof(sg, left_on="annual_salary",
                                     right_on=f"__sb_from_{which}",
                                     strategy="backward")
            parts.append(dg)
        df = pl.concat(parts, how="diagonal_relaxed")

    df = df.with_columns(
        (pl.col(target).fill_null(1.0) *
         pl.col(f"__sb_{which}").fill_null(1.0)).alias(target)
    )
    drop_cols = [c for c in [f"__sb_{which}", f"__sb_from_{which}"] if c in df.columns]
    if drop_cols:
        df = df.drop(drop_cols)
    return df


def _apply_salary_factor(df, factor, basis, target):
    """Salary lookup for adb/accdb/dism."""
    product = factor["product"]
    sb = basis["salary_band"].filter(pl.col("product") == product)

    val_col = None
    for candidate in ("inc_adj", "inc_adj/Salary Factor", "Salary Factor"):
        if candidate in sb.columns:
            val_col = candidate
            break
    if val_col is None:
        raise ValueError(f"salary_factor: no value col in {product} salary_band. "
                         f"Cols: {sb.columns}")

    sb_clean = (
        sb.select(["gender", "salary_from", val_col])
          .rename({val_col: "__sf_val", "salary_from": "__sf_from"})
          .with_columns([
              pl.col("__sf_from").cast(pl.Float64, strict=False),
              pl.col("__sf_val").cast(pl.Float64, strict=False),
              pl.col("gender").cast(pl.Utf8),
          ])
          .drop_nulls("__sf_from")
    )

    df = df.with_columns(pl.col("annual_salary").cast(pl.Float64, strict=False))

    genders_in_sb = set(sb_clean["gender"].unique().to_list())
    use_both = genders_in_sb == {"both"}

    if use_both:
        sb_g = sb_clean.filter(pl.col("gender") == "both") \
                       .drop("gender") \
                       .sort("__sf_from")
        df = df.sort("annual_salary").join_asof(
            sb_g, left_on="annual_salary",
                  right_on="__sf_from", strategy="backward"
        )
    else:
        df = df.with_columns(pl.col("gender").cast(pl.Utf8))
        parts = []
        for g in ("M", "F"):
            sg = sb_clean.filter(pl.col("gender") == g) \
                         .drop("gender") \
                         .sort("__sf_from")
            dg = df.filter(pl.col("gender") == g).sort("annual_salary")
            if sg.height and dg.height:
                dg = dg.join_asof(sg, left_on="annual_salary",
                                     right_on="__sf_from",
                                     strategy="backward")
            parts.append(dg)
        df = pl.concat(parts, how="diagonal_relaxed")

    df = df.with_columns(
        (pl.col(target) * pl.col("__sf_val").fill_null(1.0)).alias(target)
    )
    drop_cols = [c for c in ["__sf_val", "__sf_from"] if c in df.columns]
    if drop_cols:
        df = df.drop(drop_cols)
    return df


def _apply_industry(df, factor, basis, ctx, target):
    product = factor["product"]
    which = factor["factor"]
    by_size = factor.get("by_scheme_size", True)
    match = factor.get("match", "secondary")

    ind = basis["industry"].filter(pl.col("product") == product)

    if match == "secondary":
        ind = ind.filter(pl.col("secondary") == ctx.secondary_industry)
    elif match == "primary":
        ind = ind.filter(pl.col("primary") == ctx.primary_industry)
        sec_match = ind.filter(pl.col("secondary") == ctx.secondary_industry)
        if sec_match.height:
            ind = sec_match
    else:
        raise ValueError(f"Unknown industry match: {match}")

    if by_size and "scheme_size" in ind.columns:
        ss_match = ind.filter(pl.col("scheme_size") == ctx.scheme_size.lower())
        if ss_match.height:
            ind = ss_match

    if ind.height == 0 or which not in ind.columns:
        val = 1.0
    else:
        raw = ind[which][0]
        val = float(raw) if raw is not None else 1.0

    return df.with_columns((pl.col(target) * pl.lit(val)).alias(target))


def _apply_ci_standalone_loading(df, factor, assump, ctx, target):
    """CI Standalone Loading — Excel formula AL."""
    ci_rating = (ctx.scheme.rating.get("ci") or "").strip()
    if ci_rating != "Standalone":
        return df

    loading = ctx.globals.get("ci_standalone_loading")
    if loading is None:
        raise KeyError(
            "[ci_standalone_loading] ctx.globals['ci_standalone_loading'] not found. "
            "Add row to Globals sheet of assumption_master and rebuild globals.parquet."
        )

    if "ci_table_mapping" not in assump:
        raise KeyError("[ci_standalone_loading] assump has no 'ci_table_mapping'")

    if "product_option" not in df.columns:
        raise KeyError("[ci_standalone_loading] df has no 'product_option' column")

    ci_map = assump["ci_table_mapping"]

    new_options = set(
        ci_map.filter(pl.col("variant_type") == "New")["product_option"].to_list()
    )
    if not new_options:
        return df

    factor_scale = 1.0 + float(loading)

    return df.with_columns(
        pl.when(pl.col("product_option").is_in(list(new_options)))
          .then(pl.col(target) * pl.lit(factor_scale))
          .otherwise(pl.col(target))
          .alias(target)
    )


def _apply_ci_industry_loading(df, factor, basis, ctx, target):
    """CI Industry Loading — Class-based multiplier."""
    ind = basis["industry"].filter(pl.col("product") == "ci")
    row = ind.filter(pl.col("grouping") == ctx.primary_industry)
    if row.height == 0:
        raise KeyError(
            f"[ci_industry_loading] no row for primary_industry "
            f"'{ctx.primary_industry}' in CI industry basis."
        )
    class_letter = row["class"][0]

    # TT-exact CI class loadings (Combined Tech Tool: CI Basis!CI_Industry_Adjustment,
    # O154:P158 — fractions of 15). Prior rounded A/C/D undershot CI premium; the
    # D=0.93->14/15 correction closes the 0.99643 CI net-risk/incidence gap.
    # B (12/15) and E (14.4/15) were already exact and are unchanged.
    CLASS_LOADINGS = {"A": 10/15, "B": 12/15, "C": 13/15, "D": 14/15, "E": 0.96}
    loading = CLASS_LOADINGS.get(class_letter)
    if loading is None:
        raise ValueError(
            f"[ci_industry_loading] unknown class letter '{class_letter}' "
            f"for industry '{ctx.primary_industry}'."
        )

    return df.with_columns(
        (pl.col(target) * pl.lit(loading)).alias(target)
    )


def _apply_trend(df, factor, basis, ctx, target):
    product = factor["product"]
    year = ctx.calc_date.year
    tr = basis["trend"].filter(
        (pl.col("product") == product) & (pl.col("year") == year)
    )
    if tr.height == 0:
        tr_all = basis["trend"].filter(pl.col("product") == product)
        year_max = tr_all["year"].max()
        tr = tr_all.filter(pl.col("year") == year_max)

    tr = tr.with_columns([
        pl.col("salary_from").cast(pl.Float64, strict=False).alias("__tr_from"),
        pl.col("factor").cast(pl.Float64, strict=False).alias("__trend"),
    ]).select(["gender", "__tr_from", "__trend"])

    df = df.with_columns(pl.col("annual_salary").cast(pl.Float64, strict=False))

    genders = set(tr["gender"].unique().to_list())
    if genders == {"both"}:
        tr_g = tr.filter(pl.col("gender") == "both").drop("gender").sort("__tr_from")
        df = df.sort("annual_salary").join_asof(
            tr_g, left_on="annual_salary",
                  right_on="__tr_from", strategy="backward"
        )
    else:
        parts = []
        for g in ("M", "F"):
            tg = tr.filter(pl.col("gender") == g).drop("gender").sort("__tr_from")
            dg = df.filter(pl.col("gender") == g).sort("annual_salary")
            if tg.height and dg.height:
                dg = dg.join_asof(tg, left_on="annual_salary",
                                     right_on="__tr_from", strategy="backward")
            parts.append(dg)
        df = pl.concat(parts, how="diagonal_relaxed")

    df = df.with_columns(
        (pl.col(target) * pl.col("__trend").fill_null(1.0)).alias(target)
    )
    drop_cols = [c for c in ["__trend", "__tr_from"] if c in df.columns]
    if drop_cols:
        df = df.drop(drop_cols)
    return df


def _apply_waiting_pd(df, factor, basis, target):
    wp = basis["waiting_periods"].filter(pl.col("product") == factor["product"])
    wp = wp.select(["wp_months", "inc_adj"]).with_columns([
        pl.col("wp_months").cast(pl.Float64, strict=False),
        pl.col("inc_adj").cast(pl.Float64, strict=False),
    ]).rename({"inc_adj": "__wp"})
    df = df.with_columns(
        pl.col("waiting_period").cast(pl.Float64, strict=False).alias("__wp_key")
    )
    df = df.join(wp, left_on="__wp_key", right_on="wp_months", how="left")
    df = df.with_columns(
        (pl.col(target) * pl.col("__wp").fill_null(1.0)).alias(target)
    ).drop(["__wp", "__wp_key"])
    return df


def _apply_baseline_yr(df, factor, basis, ctx, target):
    tr = basis["trend"].filter(
        (pl.col("product") == factor["product"]) & (pl.col("year") == ctx.calc_date.year)
    )
    val = float(tr["factor"][0]) if tr.height else 1.0
    return df.with_columns((pl.col(target) * pl.lit(val)).alias(target))


def _apply_product_type_adj(df, factor, basis, ctx, target):
    pta = basis["product_type_adj"].filter(pl.col("product") == factor["product"])
    variant_label = "Accelerator" if ctx.scheme.rating.get(factor["product"]) == "Accelerator" else "Standalone"
    row = pta.filter(pl.col("product_type") == variant_label)
    val = float(row["adj"][0]) if row.height else 1.0
    return df.with_columns((pl.col(target) * pl.lit(val)).alias(target))


# ============================================================
# 5. COVER
# ============================================================
def compute_cover(df: pl.DataFrame, recipe: dict) -> pl.DataFrame:
    rule = recipe["cover_rule"]
    cover_col = recipe["cover_column"]

    if cover_col not in df.columns:
        df = df.with_columns(pl.lit(0.0).alias(cover_col))
    else:
        df = df.with_columns(
            pl.col(cover_col).cast(pl.Float64, strict=False).fill_null(0.0).alias(cover_col)
        )

    if rule == "multiple_or_data":
        df = df.with_columns(
            pl.when(pl.col("cover_type").cast(pl.Utf8) == "Multiple")
              .then(pl.col("benefit_multiple").cast(pl.Float64, strict=False)
                       * pl.col("annual_salary"))
              .otherwise(pl.col(cover_col))
              .alias("pre_tax_cover")
        )
    elif rule == "multiple_or_data_or_gla":
        # Terminal: cover_type can be 'Multiple', 'Set equal to GLA Cover', or data
        df = df.with_columns(
            pl.when(pl.col("cover_type").cast(pl.Utf8) == "Multiple")
              .then(pl.col("benefit_multiple").cast(pl.Float64, strict=False)
                       * pl.col("annual_salary"))
              .when(pl.col("cover_type").cast(pl.Utf8) == "Set equal to GLA Cover")
              .then(pl.col("__gla_cover_for_ti").cast(pl.Float64, strict=False)
                       .fill_null(0.0))
              .otherwise(pl.col(cover_col))
              .alias("pre_tax_cover")
        )
    elif rule == "fc_composite":
        # FC's cover is the composite AG — computed inside _apply_fc_composite
        # (special_premium hook). Place a 0 stub so cover_caps / tax_gross_up /
        # finalise_cover flow safely.
        df = df.with_columns(pl.lit(0.0).alias("pre_tax_cover"))
    elif rule == "gip_composite":
        df = df.with_columns(pl.lit(0.0).alias("pre_tax_cover"))
    elif rule == "tip_composite":
        df = df.with_columns(pl.lit(0.0).alias("pre_tax_cover"))
    elif rule == "education_guardian_composite":
        # Real cover computed inside _apply_education_guardian_composite
        # (special_premium hook) -- table lookup can't be expressed here
        # declaratively. Stub so cover_caps/tax_gross_up/finalise_cover
        # flow safely (same pattern as fc/gip/tip_composite).
        df = df.with_columns(pl.lit(0.0).alias("pre_tax_cover"))
    elif rule == "educate_a_child_composite":
        # Real cover (MIN(Multiple x Salary, Category Cap)) computed inside
        # _apply_educate_a_child_composite (special_premium hook), since
        # the per-category Multiple/Cap come from ctx.scheme.education_*
        # (Piece 1), not a generic df column. Stub here for pipeline safety.
        df = df.with_columns(pl.lit(0.0).alias("pre_tax_cover"))
    else:
        raise ValueError(f"Unknown cover_rule: {rule}")
    return df


# ============================================================
# 5b. COVER CAPS
# ============================================================
def apply_cover_caps(df, recipe, ctx, assump_tables, prior_results):
    caps = recipe.get("cover_caps", [])
    if not caps:
        return df

    for cap in caps:
        kind = cap["kind"]

        if kind == "category_max_cover":
            if "maximum_cover_amount" in df.columns:
                df = df.with_columns(
                    pl.min_horizontal([
                        pl.col("pre_tax_cover"),
                        pl.col("maximum_cover_amount").cast(pl.Float64, strict=False)
                            .fill_null(pl.col("pre_tax_cover")),
                    ]).alias("pre_tax_cover")
                )

        elif kind == "category_max_cover_field":
            field_name = cap.get("field", "max_cover")
            if field_name in df.columns:
                df = df.with_columns(
                    pl.min_horizontal([
                        pl.col("pre_tax_cover"),
                        pl.col(field_name).cast(pl.Float64, strict=False)
                            .fill_null(pl.col("pre_tax_cover")),
                    ]).alias("pre_tax_cover")
                )

        elif kind == "gla_and_lsdb_max_multiple":
            variant_is_accel = (ctx.scheme.rating.get("lsdb") == "Accelerator")
            if not variant_is_accel:
                continue
            gla_df = prior_results.get("gla")
            if gla_df is None:
                continue
            gla_cover = gla_df.select(["member_no", "total_cover"])\
                              .rename({"total_cover": "__gla_cover"})
            df = df.join(gla_cover, on="member_no", how="left")

            limits = ctx.limits_for("lsdb")
            max_mul = float(limits.get("max_multiple", 5))

            df = df.with_columns(
                pl.min_horizontal([
                    pl.col("pre_tax_cover"),
                    pl.min_horizontal([
                        pl.col("__gla_cover").fill_null(pl.col("pre_tax_cover")),
                        pl.when(pl.col("annual_salary") > 0)
                          .then(pl.col("annual_salary") * pl.lit(max_mul))
                          .otherwise(pl.col("__gla_cover"))
                    ])
                ]).alias("pre_tax_cover")
            ).drop("__gla_cover")

        elif kind == "cap_by_prior_cover":
            prior_key = cap["prior"]
            prior_df = prior_results.get(prior_key)
            if prior_df is None:
                continue
            prior = prior_df.select(["member_no", "total_cover"])\
                            .rename({"total_cover": "__prior_cover"})
            df = df.join(prior, on="member_no", how="left")
            df = df.with_columns(
                pl.min_horizontal([
                    pl.col("pre_tax_cover"),
                    pl.col("__prior_cover").fill_null(pl.col("pre_tax_cover")),
                ]).alias("pre_tax_cover")
            ).drop("__prior_cover")

        elif kind == "cap_by_lsdb_or_gla":
            lsdb_df = prior_results.get("lsdb")
            gla_df = prior_results.get("gla")
            if lsdb_df is None and gla_df is None:
                continue
            ref_df = lsdb_df if lsdb_df is not None else gla_df
            ref = ref_df.select(["member_no", "total_cover"])\
                        .rename({"total_cover": "__ref_cover"})
            df = df.join(ref, on="member_no", how="left")
            df = df.with_columns(
                pl.min_horizontal([
                    pl.col("pre_tax_cover"),
                    pl.col("__ref_cover").fill_null(pl.col("pre_tax_cover")),
                ]).alias("pre_tax_cover")
            ).drop("__ref_cover")

        elif kind == "spouse_cover_cap":
            prior_df = prior_results.get(cap["prior"])
            if prior_df is None:
                continue
            prior = prior_df.select(["member_no", "total_cover"])\
                            .rename({"total_cover": "__main_gla_cover"})
            df = df.join(prior, on="member_no", how="left")

            prod_key, param_key = cap["max_multiple_key"]
            limits = ctx.limits_for(prod_key)
            max_mul = float(limits.get(param_key, 2))

            df = df.with_columns(
                pl.min_horizontal([
                    pl.col("pre_tax_cover"),
                    pl.min_horizontal([
                        pl.when(pl.col("annual_salary") > 0)
                          .then(pl.col("annual_salary") * pl.lit(max_mul))
                          .otherwise(pl.col("__main_gla_cover")),
                        pl.col("__main_gla_cover").fill_null(pl.col("pre_tax_cover")),
                    ])
                ]).alias("pre_tax_cover")
            ).drop("__main_gla_cover")

        elif kind == "cap_by_assumption_limit":
            prod_key = cap["product_key"]
            param_key = cap.get("param_key", "max_cover")
            limits = ctx.limits_for(prod_key)
            cap_val = limits.get(param_key)
            if cap_val is None:
                continue
            cap_val = float(cap_val)
            df = df.with_columns(
                pl.min_horizontal([
                    pl.col("pre_tax_cover"),
                    pl.lit(cap_val),
                ]).alias("pre_tax_cover")
            )

        else:
            raise ValueError(f"Unknown cover cap kind: {kind}")

    return df


# ============================================================
# 5c. CTR MAX COVER (per-product, per-category cap)
# ============================================================
def apply_ctr_max_cover(
    df: pl.DataFrame,
    ctx,
    product_key: str,
    assump_fallback_limits: dict | None = None,
    assump_fallback_key: str = "max_cover",
) -> pl.DataFrame:
    """Cap `pre_tax_cover` at the per-category Maximum Cover Amount."""
    ctr_caps: dict[int, float] = (
        getattr(ctx.scheme, "max_cover_per_category", {}).get(product_key) or {}
    )
    assump_cap = None
    if assump_fallback_limits is not None:
        raw = assump_fallback_limits.get(assump_fallback_key)
        if raw is not None:
            try:
                assump_cap = float(raw)
            except (TypeError, ValueError):
                assump_cap = None

    if not ctr_caps and assump_cap is None:
        return df

    if ctr_caps:
        cap_rows = []
        for cat_num, ctr_val in ctr_caps.items():
            eff = float(ctr_val) if ctr_val is not None else None
            cap_rows.append({"category_number": int(cat_num), "__eff_cap": eff})
        cap_df = pl.DataFrame(
            cap_rows,
            schema={"category_number": pl.Int64, "__eff_cap": pl.Float64},
        )

        df = df.with_columns(pl.col("category_number").cast(pl.Int64))
        df = df.join(cap_df, on="category_number", how="left")

        if assump_cap is not None:
            df = df.with_columns(
                pl.col("__eff_cap").fill_null(assump_cap).alias("__eff_cap")
            )
    else:
        df = df.with_columns(pl.lit(assump_cap).alias("__eff_cap"))

    df = df.with_columns(
        pl.when(pl.col("__eff_cap").is_not_null())
          .then(
              pl.min_horizontal(
                  pl.col("pre_tax_cover").cast(pl.Float64, strict=False),
                  pl.col("__eff_cap"),
              )
          )
          .otherwise(pl.col("pre_tax_cover"))
          .alias("pre_tax_cover")
    ).drop("__eff_cap")

    return df


# ============================================================
# 6. TAX GROSS-UP
# ============================================================
def tax_gross_up(df, tax_tables, country="SA"):
    bands_base = (
        tax_tables.filter(
            (pl.col("country") == country)
            & (~pl.col("tax_year").cast(pl.Utf8).str.contains("_gip"))
        )
                  .select(["band_from", "basic_amount", "margin"])
                  .with_columns([
                      pl.col("band_from").cast(pl.Float64, strict=False),
                      pl.col("basic_amount").cast(pl.Float64, strict=False),
                      pl.col("margin").cast(pl.Float64, strict=False),
                  ])
                  .drop_nulls("band_from")
    )
    bands_1 = bands_base.rename({"band_from": "band_from_1",
                                  "basic_amount": "basic_1",
                                  "margin": "margin_1"}).sort("band_from_1")
    bands_2 = bands_base.rename({"band_from": "band_from_2",
                                  "basic_amount": "basic_2",
                                  "margin": "margin_2"}).sort("band_from_2")

    df = df.with_columns(pl.col("pre_tax_cover").cast(pl.Float64, strict=False))
    df = df.sort("pre_tax_cover").join_asof(
        bands_1, left_on="pre_tax_cover", right_on="band_from_1", strategy="backward"
    )
    df = df.with_columns(
        (pl.col("basic_1") +
         (pl.col("pre_tax_cover") - pl.col("band_from_1")) * pl.col("margin_1")
        ).alias("tax_cover_required")
    )
    df = df.with_columns(
        (pl.col("pre_tax_cover") +
         pl.col("tax_cover_required") / (1 - pl.col("margin_1"))
        ).alias("required_cover_grossed")
    )
    df = df.sort("required_cover_grossed").join_asof(
        bands_2, left_on="required_cover_grossed", right_on="band_from_2", strategy="backward"
    )
    df = df.with_columns(
        (pl.col("band_from_2") > pl.col("band_from_1")).alias("new_band_breached")
    )
    df = df.with_columns(
        (
            (pl.col("band_from_2") - pl.col("pre_tax_cover")) *
                (1/(1 - pl.col("margin_1")) - 1) *
                (1 - pl.col("margin_1")) / (1 - pl.col("margin_2"))
          + (pl.col("band_from_2") - pl.col("pre_tax_cover"))
          + (pl.col("pre_tax_cover") + pl.col("tax_cover_required") - pl.col("band_from_2"))
              / (1 - pl.col("margin_2"))
        ).alias("tax_cover_if_new_band")
    )
    df = df.with_columns(
        (pl.col("pre_tax_cover") + pl.col("tax_cover_if_new_band"))
            .alias("required_cover_new_band")
    )
    df = df.with_columns(
        pl.when(pl.col("cover_net_of_tax").cast(pl.Utf8) != "Yes").then(0.0)
          .when(~pl.col("new_band_breached"))
              .then(pl.col("required_cover_grossed") - pl.col("pre_tax_cover"))
          .otherwise(pl.col("required_cover_new_band") - pl.col("pre_tax_cover"))
          .alias("tax_on_cover")
    )
    drop_cols = [c for c in [
        "band_from_1", "basic_1", "margin_1",
        "band_from_2", "basic_2", "margin_2",
        "tax_cover_required", "required_cover_grossed",
        "new_band_breached", "tax_cover_if_new_band",
        "required_cover_new_band",
    ] if c in df.columns]
    return df.drop(drop_cols)


# ============================================================
# 7. FINAL COVER
# ============================================================
def apply_income_taper(df: pl.DataFrame) -> pl.DataFrame:
    """LSDB income tapering. Reduces cover as member nears NRA.
    tapered = min(cover, salary * max(0, floor((NRA-age)*12) - reduction_period) / 12)
    Disabled (status=='DB') -> 0. No-op unless reduction_period == 'Income Tapering'."""
    if "reduction_period" not in df.columns:
        return df
    mask = pl.col("reduction_period").cast(pl.Utf8) == "Income Tapering"
    if df.filter(mask).height == 0:
        return df
    redmap = pl.col("nra_final")  # reduction period months come from ctr; see redmap col
    months_floor = ((pl.col("nra_final") - pl.col("age")) * 12).floor()
    # reduction_period months sourced from the CTR 'reduction_period_months' if present, else 6
    rp = (pl.col("reduction_period_months").cast(pl.Float64, strict=False)
          if "reduction_period_months" in df.columns else pl.lit(6.0))
    tapered = pl.min_horizontal(
        pl.col("pre_tax_cover"),
        pl.col("annual_salary") * pl.max_horizontal(pl.lit(0.0), months_floor - rp) / 12.0,
    )
    new_cover = (pl.when(pl.col("status") == "DB").then(pl.lit(0.0))
                   .when(mask).then(tapered)
                   .otherwise(pl.col("pre_tax_cover")))
    return df.with_columns(new_cover.alias("pre_tax_cover"))


def finalise_cover(df: pl.DataFrame, recipe: dict) -> pl.DataFrame:
    apply_tax = recipe.get("apply_tax_gross_up", False)
    if apply_tax:
        df = df.with_columns(
            pl.when(~pl.col("product_active")).then(0.0)
              .when((pl.col("status") == "P") | (pl.col("age") > pl.col("ceasing_age")))
                  .then(pl.col("reduced").cast(pl.Float64, strict=False).fill_null(0.0))
              .when(pl.col("tax_on_cover") < 0).then(pl.col("pre_tax_cover"))
              .otherwise(pl.col("pre_tax_cover") + pl.col("tax_on_cover"))
              .alias("total_cover")
        )
    else:
        df = df.with_columns(
            pl.when(~pl.col("product_active")).then(0.0)
              .when(pl.col("age") > pl.col("ceasing_age")).then(0.0)
              .otherwise(pl.col("pre_tax_cover"))
              .alias("total_cover")
        )
    return df


def zero_if_status(df: pl.DataFrame, statuses: tuple[str, ...]) -> pl.DataFrame:
    """Zero out all premium/margin columns for members whose status is in `statuses`."""
    if not statuses or "status" not in df.columns:
        return df

    is_zero = pl.col("status").cast(pl.Utf8).is_in(list(statuses))

    zero_cols = [
        "basic_technical_premium",
        "aids_technical_premium",
        "co_premium",
        "waiver_premium",
        "prb_premium",
        "ctc_premium",
        "reinstatement_premium",
        "total_annual_premium",
    ]
    present = [c for c in zero_cols if c in df.columns]
    return df.with_columns([
        pl.when(is_zero).then(0.0).otherwise(pl.col(c)).alias(c) for c in present
    ])


def deactivate_when_status(df: pl.DataFrame, statuses: tuple[str, ...]) -> pl.DataFrame:
    """Set product_active=False for members whose status is in the given list."""
    if not statuses:
        return df
    return df.with_columns(
        (pl.col("product_active") & ~pl.col("status").is_in(list(statuses)))
        .alias("product_active")
    )


# ============================================================
# 7b. SPECIAL PREMIUM  (for products that derive premium
#     from another product's premium — currently TI and FC)
# ============================================================
def apply_special_premium(df: pl.DataFrame,
                           spec: dict,
                           basis_tables: dict[str, pl.DataFrame],
                           prior_results: dict[str, pl.DataFrame],
                           assump_tables: dict | None = None,
                           ctx=None) -> pl.DataFrame:
    """Dispatch a special_premium hook.

    Signature extended (backward-compat) to accept assump_tables and ctx —
    fc_composite needs both. ti_scales_gla ignores them.
    """
    kind = spec["kind"]
    if kind == "ti_scales_gla":
        return _apply_ti_scales_gla(df, spec, basis_tables, prior_results)
    if kind == "fc_composite":
        return _apply_fc_composite(df, spec, basis_tables, assump_tables, ctx)
    if kind == "gip_composite":
        return _apply_gip_composite(df, spec, basis_tables, assump_tables, ctx)
    if kind == "tip_composite":
        return _apply_tip_composite(df, spec, basis_tables, assump_tables, ctx)
    if kind == "education_guardian_composite":
        return _apply_education_guardian_composite(df, spec, basis_tables, assump_tables, ctx)
    if kind == "educate_a_child_composite":
        return _apply_educate_a_child_composite(df, spec, basis_tables, assump_tables, ctx)
    raise ValueError(f"Unknown special_premium kind: {kind}")


def _apply_fc_composite(df: pl.DataFrame,
                         spec: dict,
                         basis_tables: dict[str, pl.DataFrame],
                         assump_tables: dict | None,
                         ctx) -> pl.DataFrame:
    """FC composite cover + premium — implements TT rows AG, BB..BJ.

    Self-sufficient: calls FC column-enrichment primitives inline rather
    than depending on post_rate_adjust (which runs AFTER special_premium
    in the engine pipeline). Also writes ctc_premium (BH) and waiver_premium
    (BI) directly rather than routing through the engine's _apply_addons
    dispatch, which is co_premium-target-locked.

    Writes:
      - total_cover                (overwrites finalise_cover's 0)
      - basic_technical_premium    (BB+BC+BD+BE = BF, × DB loading)
      - aids_technical_premium     (= 0 for FC)
      - rate_basic                 (derived qx × 1000 for reporting)
      - rate_aids                  (= 0)
      - ctc_premium                (BH — Cover to Continue cost)
      - waiver_premium             (BI — Paid Up Benefits cost)
    """
    # -------------------------------------------------------------------
    # 0. Attach FC prerequisite columns
    # -------------------------------------------------------------------
    df = _fc_demographics_join(df, basis_tables)
    df = _fc_family_composition_join(df, basis_tables, ctx)
    df = _fc_second_spouse_loading(df, assump_tables, ctx)
    df = _fc_db_loading(df, {"gate_global": spec.get("db_gate_global",
                                                     "active_selection_db_load")},
                        assump_tables, ctx)

    # -------------------------------------------------------------------
    # 1. Attach the 8 per-category benefit amounts from SchemeRecord
    # -------------------------------------------------------------------
    benefit_map = (
        getattr(ctx.scheme, "fc_benefit_amounts", {}) or {} if ctx else {}
    )
    ben_rows = []
    for cat, benefits in benefit_map.items():
        row = {"category_number": int(cat)}
        for k in ("primary_insured", "spouse", "child_14_plus", "child_6_13",
                  "child_1_5", "child_under_1", "stillborn", "parents_cover"):
            row[f"__fc_ben_{k}"] = float(benefits.get(k, 0.0))
        ben_rows.append(row)

    if ben_rows:
        ben_df = pl.DataFrame(ben_rows)
        df = df.with_columns(pl.col("category_number").cast(pl.Int64))
        df = df.join(ben_df, on="category_number", how="left")
    else:
        for k in ("primary_insured", "spouse", "child_14_plus", "child_6_13",
                  "child_1_5", "child_under_1", "stillborn", "parents_cover"):
            df = df.with_columns(pl.lit(0.0).alias(f"__fc_ben_{k}"))
    for k in ("primary_insured", "spouse", "child_14_plus", "child_6_13",
              "child_1_5", "child_under_1", "stillborn", "parents_cover"):
        df = df.with_columns(pl.col(f"__fc_ben_{k}").fill_null(0.0))

    # -------------------------------------------------------------------
    # 2. Composite cover AG
    # -------------------------------------------------------------------
    df = df.with_columns(
        (
            pl.col("__fc_ben_primary_insured")
            + pl.col("pct_married") * pl.col("__fc_ben_spouse")
              * pl.col("second_spouse_loading")
            + pl.col("n_children_0_13")  * pl.col("__fc_ben_child_6_13")
            + pl.col("n_children_14_plus") * pl.col("__fc_ben_child_14_plus")
            + (pl.col("n_parents")
               + pl.col("n_in_laws") * pl.col("pct_married"))
              * pl.col("__fc_ben_parents_cover")
        ).alias("__fc_ag_cover")
    )

    # -------------------------------------------------------------------
    # 3. Rate factors — GLA basis
    # -------------------------------------------------------------------
    tmp = df.with_columns(pl.lit(1.0).alias("__ar"))
    tmp = _apply_mortality(tmp, {"kind": "mortality", "product": "gla",
                                  "age_col": "age_nb"}, basis_tables, "__ar")

    tmp = tmp.with_columns(pl.lit(1.0).alias("__av"))
    tmp = _apply_mortality_gender_swap(tmp, {"kind": "mortality_gender_swap",
                                              "product": "gla", "age_col": "age_nb"},
                                        basis_tables, "__av")

    tmp = tmp.with_columns(pl.lit(1.0).alias("__as"))
    tmp = _apply_salary_band(tmp, {"kind": "salary_band", "product": "gla",
                                    "factor": "inc_adj"}, basis_tables, "__as")
    

    tmp = tmp.with_columns(pl.lit(1.0).alias("__at"))
    tmp = _apply_industry(tmp, {"kind": "industry", "product": "gla",
                                 "factor": "inc_adj", "by_scheme_size": True},
                          basis_tables, ctx, "__at")
    

    tmp = tmp.with_columns(pl.lit(1.0).alias("__au"))
    tmp = _apply_trend(tmp, {"kind": "trend", "product": "gla"},
                       basis_tables, ctx, "__au")

    df = tmp

    # -------------------------------------------------------------------
    # 4. FC-specific children rates from fc_rates
    # -------------------------------------------------------------------
    fc_rates_basic_0  = 0.0
    fc_rates_basic_14 = 0.0
    fc_rates_aids_14  = 0.0
    if basis_tables is not None and "fc_rates" in basis_tables:
        fr = basis_tables["fc_rates"]
        r0 = fr.filter(pl.col("age_from") == 0)
        r14 = fr.filter(pl.col("age_from") == 14)
        if r0.height:
            fc_rates_basic_0 = float(r0["basic_rate"][0] or 0.0)
        if r14.height:
            fc_rates_basic_14 = float(r14["basic_rate"][0] or 0.0)
            fc_rates_aids_14  = float(r14["aids_rate"][0] or 0.0)

    # -------------------------------------------------------------------
    # 5. Component premiums BB..BE and total BF
    # -------------------------------------------------------------------
    df = df.with_columns([
        (pl.col("__ar") / 1000.0 * pl.col("__as") * pl.col("__at")
         * pl.col("__au") * pl.col("__fc_ben_primary_insured")).alias("__bb"),

        (pl.col("__av") / 1000.0 * pl.col("__as") * pl.col("__at")
         * pl.col("__au") * pl.col("__fc_ben_spouse")
         * pl.col("second_spouse_loading") * pl.col("pct_married")).alias("__bc"),

        (pl.lit(fc_rates_basic_0) * pl.col("n_children_0_13") / 1000.0
         * pl.col("__as") * pl.col("__at")
         * pl.col("__fc_ben_child_6_13")).alias("__bd"),

        ((pl.lit(fc_rates_basic_14) + pl.lit(fc_rates_aids_14))
         * pl.col("n_children_14_plus") / 1000.0
         * pl.col("__as") * pl.col("__at")
         * pl.col("__fc_ben_child_14_plus")).alias("__be"),
    ])
    df = df.with_columns(
        (pl.col("__bb") + pl.col("__bc") + pl.col("__bd") + pl.col("__be"))
        .alias("basic_technical_premium")
    )


    df = df.with_columns([
        pl.lit(0.0).alias("aids_technical_premium"),
        pl.lit(0.0).alias("rate_aids"),
    ])

    # -------------------------------------------------------------------
    # 6. Overwrite total_cover with composite AG; zero for inactive/aged-out
    # -------------------------------------------------------------------
    df = df.with_columns(
        pl.when(~pl.col("product_active")).then(0.0)
          .when(pl.col("age") > pl.col("ceasing_age")).then(0.0)
          .otherwise(pl.col("__fc_ag_cover"))
          .alias("total_cover")
    )
    df = df.with_columns(
        pl.when(~pl.col("product_active") | (pl.col("age") > pl.col("ceasing_age")))
          .then(0.0)
          .otherwise(pl.col("basic_technical_premium"))
          .alias("basic_technical_premium")
    )

    # -------------------------------------------------------------------
    # 7. Namibia rate cut
    # -------------------------------------------------------------------
    nam_cut_key = spec.get("namibia_rate_cut_global", "namibia_competitive_factor")
    country = str(getattr(ctx.scheme, "country_scale", "") or "").strip().lower()
    if country in ("namibia", "nam", "2") and ctx is not None:
        nam_cut = ctx.globals.get(nam_cut_key)
        if nam_cut is not None:
            try:
                nam_cut = float(nam_cut)
                df = df.with_columns(
                    (pl.col("basic_technical_premium") * (1.0 + nam_cut))
                    .alias("basic_technical_premium")
                )
            except (TypeError, ValueError):
                pass

    # -------------------------------------------------------------------
    # 8. rate_basic — derived for reporting parity
    # -------------------------------------------------------------------
    df = df.with_columns(
        pl.when(pl.col("total_cover") > 0)
          .then(pl.col("basic_technical_premium") / pl.col("total_cover") * 1000)
          .otherwise(0.0)
          .alias("rate_basic")
    )

    # -------------------------------------------------------------------
    # 9. FC add-ons written directly (self-sufficient — bypasses engine
    #    _apply_addons dispatch which is co_premium-target-locked).
    # -------------------------------------------------------------------
    base = (pl.col("basic_technical_premium").fill_null(0.0)
            + pl.col("aids_technical_premium").fill_null(0.0))
    cat_expr = pl.col("category_number").cast(pl.Int64)

    # CTC (BH) — (BF+BG) × ctc_cost scalar, gated by fc_include_ctc[cat]="Yes"
    ctc_scalar = 0.0
    if assump_tables is not None and "product_limits" in assump_tables:
        row = assump_tables["product_limits"].filter(
            (pl.col("product") == "fc") & (pl.col("param_name") == "ctc_cost")
        )
        if row.height:
            try:
                ctc_scalar = float(row["param_value"][0])
            except (TypeError, ValueError):
                ctc_scalar = 0.0

    include_map = getattr(ctx.scheme, "fc_include_ctc", {}) or {}
    ctc_yes_cats = [int(c) for c, v in include_map.items()
                     if isinstance(v, str) and v.strip().lower() == "yes"]

    if ctc_scalar > 0 and ctc_yes_cats:
        df = df.with_columns(
            pl.when(cat_expr.is_in(ctc_yes_cats))
              .then(base * pl.lit(ctc_scalar))
              .otherwise(0.0)
              .alias("ctc_premium")
        )
    else:
        df = df.with_columns(pl.lit(0.0).alias("ctc_premium"))

    # PUP (BI) — router on fc_pup_death / fc_pup_lsdb / fc_pup_death_lsdb per cat
    def _pl_scalar(param_name: str) -> float:
        if assump_tables is None or "product_limits" not in assump_tables:
            return 0.0
        r = assump_tables["product_limits"].filter(
            (pl.col("product") == "fc") & (pl.col("param_name") == param_name)
        )
        if r.height:
            try:
                return float(r["param_value"][0])
            except (TypeError, ValueError):
                return 0.0
        return 0.0

    pup_death      = _pl_scalar("pup_cost_death")
    pup_lsdb       = _pl_scalar("pup_cost_lsdb")
    pup_death_lsdb = _pl_scalar("pup_cost_death_lsdb")

    def _yes_cats(field_name: str) -> list[int]:
        m = getattr(ctx.scheme, field_name, {}) or {}
        return [int(c) for c, v in m.items()
                if isinstance(v, str) and v.strip().lower() == "yes"]

    death_cats      = _yes_cats("fc_pup_death")
    lsdb_cats       = _yes_cats("fc_pup_lsdb")
    death_lsdb_cats = _yes_cats("fc_pup_death_lsdb")

    df = df.with_columns(
        pl.when(cat_expr.is_in(death_cats)).then(base * pl.lit(pup_death))
          .when(cat_expr.is_in(lsdb_cats)).then(base * pl.lit(pup_lsdb))
          .when(cat_expr.is_in(death_lsdb_cats)).then(base * pl.lit(pup_death_lsdb))
          .otherwise(0.0)
          .alias("waiver_premium")
    )

    # PRB (BJ) — FC's PRB base is (BF + BG) only (excludes CTC and PUP).
    # This differs from GLA convention (BF + BK, i.e. basic + CTC + waiver
    # excluding CO). Written inline here to bypass the engine's downstream
    # apply_prb_premium call which uses the GLA convention.
    prb_map = getattr(ctx.scheme, "profit_refund_loading_by_product", {}) or {}
    fc_prb_rate = 0.0
    if prb_map.get("fc") is not None:
        try:
            fc_prb_rate = float(prb_map["fc"])
        except (TypeError, ValueError):
            fc_prb_rate = 0.0

    if fc_prb_rate > 0:
        # base = basic + aids (aids = 0 for FC, so effectively basic only)
        prb_base = (pl.col("basic_technical_premium").fill_null(0.0)
                    + pl.col("aids_technical_premium").fill_null(0.0))
        df = df.with_columns(
            pl.when(pl.col("product_active") & (pl.col("age") <= pl.col("ceasing_age")))
              .then(prb_base * pl.lit(fc_prb_rate))
              .otherwise(0.0)
              .alias("prb_premium")
        )
    else:
        df = df.with_columns(pl.lit(0.0).alias("prb_premium"))
    # -------------------------------------------------------------------
    # 10. Cleanup intermediates
    # -------------------------------------------------------------------
    drop_cols = [c for c in ["__bb", "__bc", "__bd", "__be",
                              "__ar", "__av", "__as", "__at", "__au",
                              "__fc_ag_cover",
                              "__fc_ben_primary_insured", "__fc_ben_spouse",
                              "__fc_ben_child_14_plus", "__fc_ben_child_6_13",
                              "__fc_ben_child_1_5", "__fc_ben_child_under_1",
                              "__fc_ben_stillborn", "__fc_ben_parents_cover"]
                 if c in df.columns]
    return df.drop(drop_cols)

# ============================================================================
# GIP COMPOSITE — paste this whole block into helpers.py
# right after _apply_fc_composite (they are sibling special_premium hooks).
#
# Add at top of helpers.py if missing:
#     import calendar
#     import re
#
# Register in apply_special_premium (already done):
#     if kind == "gip_composite":
#         return _apply_gip_composite(df, spec, basis_tables, assump_tables, ctx)
#
# FC-shaped: enriches df with total_cover / basic_technical_premium /
# aids_technical_premium / co_premium / total_annual_premium / rate_basic
# and RETURNS the full df (keeps member_no, product_active, category_number,
# gender, age, etc. for downstream compute_qx / apply_profit_margin / aggregation).
#
# VERIFIED landmines (rand-perfect vs TT on Amazon, Δ=0.00):
#   * FR  <- annuity_nra_interpolation.linear_scaler  (NOT nra_in_table)
#   * HCC annuity leg hardcodes 6% (NOT gip_pricing_interest_pa=0.07)
#   * tax cascade uses tax_year == "2026-2027_gip"; primary_rebate from that row
#   * annuity_factors.key = "age/gender/wp/ip/nra/esc/size" (int fmt, esc string)
#   * BX (sal_tier 1/2/3) selects sal_1 / sal_2 / sal_3 column
#   * backdating loading reads WP6 sub-table only (scheme_wp == 6)
#   * val3_2 "Waiver Included?" not in Save block -> guarded default "No"
# ============================================================================


# ---------------------------------------------------------------------------
# GIP scalar / lookup helpers (module-level)
# ---------------------------------------------------------------------------
def _gipf(x):
    return 0.0 if x is None else float(x)


def _gip_key_part(x):
    """Integer-ish -> no '.0'; strings pass through (matches annuity_factors.key)."""
    if x is None:
        return ""
    if isinstance(x, (int, float)) and float(x).is_integer():
        return str(int(x))
    return str(x)


def _gip_asof(rows, key_col, val_col, x):
    """VLOOKUP(...,TRUE): last row where key_col <= x. rows pre-sorted asc."""
    hit = None
    for r in rows:
        if r[key_col] <= x:
            hit = r[val_col]
        else:
            break
    return hit


def _gip_wp_months(wp_str):
    """'6 months' -> 6 (int)."""
    if not wp_str:
        return None
    import re
    m = re.search(r"(\d+)", str(wp_str))
    return int(m.group(1)) if m else None


def _gip_esc_key(esc_pct):
    """0.05 -> '5'; 0.0 -> '0'. (Uncapped handled by esc-loading table.)"""
    if esc_pct is None:
        return "0"
    return str(int(round(float(esc_pct) * 100)))


def _gip_eomonth(y, m):
    import calendar
    return date(y, m, calendar.monthrange(y, m)[1])


def _gip_yearfrac_30_360(d0, d1):
    """Excel YEARFRAC basis 0 (US 30/360)."""
    dd0 = 30 if d0.day == 31 else d0.day
    dd1 = 30 if (d1.day == 31 and dd0 == 30) else d1.day
    return ((d1.year - d0.year) * 360 + (d1.month - d0.month) * 30 + (dd1 - dd0)) / 360.0


def _gip_backdating_loading(basis, backdating_label):
    """(1+BL) uplift. TT reads WP6 sub-table only. 'none'/blank -> 0."""
    if not backdating_label or str(backdating_label).strip().lower() == "none":
        return 0.0
    bd = basis["backdating_loading"].filter(
        (pl.col("product") == "gip") & (pl.col("scheme_wp") == 6) &
        (pl.col("backdating_option") == backdating_label))
    return float(bd["loading"][0]) if bd.height else 0.0


def _gip_annuity_fs_fast(FO, FR, af_map, sal_col, BL, esc_map, esc_pct,
                         size, E, K, BY, BT, FK, FL):
    "FS with esc_row pre-resolved from esc_map (no per-call pl.filter). "
    "Math byte-identical to _gip_annuity_fs; verified rand-perfect 2026-08-06."
    if FO is None:
        return 0.0
    esc_row = esc_map.get(esc_pct)
    if esc_row is None:
        try: esc_row = esc_map.get(int(round(float(esc_pct)*100))/100.0)
        except (TypeError, ValueError): esc_row = None
    if esc_row is None:
        return FO
    lower_key, upper_key = esc_row["map_lower_key"], esc_row["map_upper_key"]
    GD = _gipf(esc_row["interp_weight"])
    GE = _gipf(esc_row["progression_loading"])
    def _ann(nra, esc_k):
        k = "/".join([_gip_key_part(E), _gip_key_part(K), _gip_key_part(BY),
                      _gip_key_part(BT), _gip_key_part(nra), _gip_key_part(esc_k), size])
        r = af_map.get(k)
        return _gipf(r[sal_col]) * (1 + BL) if r else None
    BS = _gip_esc_key(esc_pct)
    FP = _ann(FL, BS)
    FQ = (FP - FO) if FP is not None else 0.0
    GB = _ann(FK, lower_key)
    GC = _ann(FK, upper_key)
    GF = ((GC - GB) * GD) if (GB is not None and GC is not None) else 0.0
    return (FO + FR * FQ + GF) * (1 + GE)


def _gip_annuity_fs(FO, FR, af_map, sal_col, BL, basis, esc_pct,
                    size, E, K, BY, BT, FK, FL):
    """FS = (FO + FR*FQ + GF)*(1+GE)   [scaffold Stage D4, rand-perfect].
    Canonical NRA (FR=0) + exact-esc (interp_weight=0) -> FS reduces to FO.
    """
    if FO is None:
        return 0.0
    esc = basis["annuity_esc_loading"].filter(pl.col("product") == "gip")
    erow = esc.filter(pl.col("esc_pct") == esc_pct)
    if erow.height == 0:
        return FO
    e = erow.row(0, named=True)
    lower_key, upper_key = e["map_lower_key"], e["map_upper_key"]
    GD = _gipf(e["interp_weight"])
    GE = _gipf(e["progression_loading"])

    def _ann(nra, esc_k):
        k = "/".join([_gip_key_part(E), _gip_key_part(K), _gip_key_part(BY),
                      _gip_key_part(BT), _gip_key_part(nra), _gip_key_part(esc_k), size])
        r = af_map.get(k)
        return _gipf(r[sal_col]) * (1 + BL) if r else None

    BS = _gip_esc_key(esc_pct)
    FP = _ann(FL, BS)
    FQ = (FP - FO) if FP is not None else 0.0
    GB = _ann(FK, lower_key)
    GC = _ann(FK, upper_key)
    GF = ((GC - GB) * GD) if (GB is not None and GC is not None) else 0.0
    return (FO + FR * FQ + GF) * (1 + GE)


# ---------------------------------------------------------------------------
# main hook
# ---------------------------------------------------------------------------
def _apply_gip_composite(df: pl.DataFrame,
                         spec: dict,
                         basis_tables: dict,
                         assump_tables: dict,
                         ctx) -> pl.DataFrame:
    """GIP composite premium (basic DF + HCC DB + CO DH). FC-shaped: enriches
    and returns df. Computes per-member in Python (lookups are keyed dict
    accesses), then writes results back via a member_no join so df keeps all
    its existing columns."""
    scheme = ctx.scheme
    g = scheme
    size = ctx.scheme_size.lower()          # "small"/"large"  (basis filter)
    size_title = ctx.scheme_size            # "Small"/"Large"  (annuity key)
    comm = ctx.calc_date
    sec_ind = scheme.secondary
    pear = float(scheme.pear_tgp_pct) if scheme.pear_tgp_pct else 1.0

    B = basis_tables

    # ---- pre-index annuity esc-loading once (was 2x pl.filter per member) ----
    _esc_tbl = B["annuity_esc_loading"].filter(pl.col("product") == "gip")
    esc_map = {}
    for _er in _esc_tbl.iter_rows(named=True):
        if _er["esc_pct"] not in esc_map:
            esc_map[_er["esc_pct"]] = _er
    # between-grid esc% (e.g. 0.075) must resolve to the same grid key
    # _gip_esc_key uses for the FO lookup (round -> 0.08), so GE applies.
    def _esc_grid(_e):
        try: return int(round(float(_e) * 100)) / 100.0
        except (TypeError, ValueError): return _e
    for _er in _esc_tbl.iter_rows(named=True):
        _gk = _esc_grid(_er["esc_pct"])
        esc_map.setdefault(_gk, _er)

    # ---- pre-index basis/assumption tables ----
    mort_map = {(int(r["age"]), r["gender"]): r["rate"]
                for r in B["mortality"].filter(pl.col("product") == "gip").iter_rows(named=True)}

    sb_rows = (B["salary_band"].filter(pl.col("product") == "gip")
               .select(["gender", "salary_from", "inc_adj", "acaf_adj"])
               .sort(["gender", "salary_from"]).to_dicts())
    sb_by_g = {gd: [r for r in sb_rows if r["gender"] == gd] for gd in ("M", "F")}

    ind = B["industry"].filter((pl.col("product") == "gip") & (pl.col("scheme_size") == size))
    ind_row = ind.filter(pl.col("secondary") == sec_ind)
    if ind_row.height == 0:
        raise KeyError(f"[gip] industry '{sec_ind}' not found for size={size}")
    BO_val = float(ind_row["inc_adj"][0])
    BP_val = float(ind_row["acaf_adj"][0])

    rr_rows  = (B["rr_loading"].filter(pl.col("product") == "gip")
                .select(["rr_from", "loading"]).sort("rr_from").to_dicts())
    asb_rows = (B["annuity_salary_bands"].filter(pl.col("product") == "gip")
                .select(["salary_from", "sal_tier"]).sort("salary_from").to_dicts())
    wp_rows  = (B["wp_loading"].filter((pl.col("product") == "gip") & (pl.col("scheme_size") == size))
                .select(["age_band_from", "wp_months", "factor"])
                .sort(["wp_months", "age_band_from"]).to_dicts())
    ip = B["ip_loading"].filter(pl.col("product") == "gip")
    ip_adj = {r["ip_label"]: r["adjustment"] for r in ip.iter_rows(named=True)}
    ip_mm  = {r["ip_label"]: r["mapped_months"] for r in ip.iter_rows(named=True)}
    db_map = {r["combined_key"]: r["loading"]
              for r in B["db_loading"].filter(pl.col("product") == "gip").iter_rows(named=True)}
    wpann  = {int(r["wp_raw"]): int(r["wp_annuity"])
              for r in B["wp_annuity_mapping"].filter(pl.col("product") == "gip").iter_rows(named=True)}
    nra_map = {int(r["nra"]): r
               for r in B["annuity_nra_interpolation"].filter(pl.col("product") == "gip").iter_rows(named=True)}
    af_map = {r["key"]: r
              for r in B["annuity_factors"].filter(pl.col("product") == "gip").iter_rows(named=True)}
    hcc = {r["param_name"]: float(r["param_value"])
           for r in B["gip_hcc_basis"].filter(pl.col("product") == "gip").iter_rows(named=True)}
    HCC_RATE = hcc["hcc_pricing_rate"]       # 0.0096
    J5 = hcc["hcc_reduction_factor"]         # 1.0

    # tax bands (2026-2027_gip), cast to float
    tx = (assump_tables["tax_tables"]
          .filter(pl.col("tax_year") == "2026-2027_gip")
          .select(["band_from", "margin", "basic_amount", "primary_rebate"])
          .with_columns([pl.col(c).cast(pl.Float64, strict=False)
                         for c in ["band_from", "margin", "basic_amount", "primary_rebate"]])
          .drop_nulls("band_from").sort("band_from"))
    bands = tx.to_dicts()
    rebate = bands[0]["primary_rebate"] if bands else 0.0

    # scalars
    plim = {r["param_name"]: r["param_value"]
            for r in assump_tables["product_limits"].filter(pl.col("product") == "gip").iter_rows(named=True)}
    co_cost = float(assump_tables["conversion_option"]
                    .filter(pl.col("product") == "gip")["rate"][0])
    f451 = float(plim.get("max_co_age", 65))
    f452 = float(plim.get("withdrawal_only_pre_nra_cap_years", 5))

    waiver_incl_map = getattr(g, "gip_waiver_included", {}) or {}

    # ---- per-member compute ----
    results = []
    _gip_excluded = set()          # G="none" gate failures
    for row in df.iter_rows(named=True):
        cat = int(row["category_number"]) if row.get("category_number") is not None else None
        active = bool(row.get("product_active"))
        member_no = row.get("member_no")

        if cat is None or not active:
            results.append({
                "member_no": member_no,
                "__gip_cover": 0.0,
                "__gip_basic": 0.0,
                "__gip_co": 0.0,
                "__gip_total": 0.0,
                "__gip_hcc": 0.0,
                "__gip_basic_excl_esc": 0.0,
                "__gip_reporting_incidence": 0.0,
                "__gip_reporting_incidence_x_cover": 0.0,
                "__gip_reporting_over_cease": False,
            })
            continue

        # ---- G="none" exclusion gate (age<16 / over-cease / time-to-NRD<WP) ----
        _g_age = _gipf(row.get("age"))
        _g_cease = _gipf(row.get("ceasing_age") if row.get("ceasing_age") is not None
                         else row.get("nra_final"))
        _g_wpm = _gip_wp_months(g.gip_waiting_period.get(cat))
        _g_wpm = _g_wpm if _g_wpm is not None else 0.0
        _g_m2nrd = (_g_cease - _g_age) * 12.0
        _g_over_cease = _g_age > _g_cease

        if not (_g_age >= 16 and _g_age <= _g_cease and _g_m2nrd >= _g_wpm):
            _gip_excluded.add(member_no)
            results.append({
                "member_no": member_no,
                "__gip_cover": 0.0,
                "__gip_basic": 0.0,
                "__gip_co": 0.0,
                "__gip_hcc": 0.0,
                "__gip_basic_excl_esc": 0.0,
                "__gip_reporting_incidence": 0.0,
                "__gip_reporting_incidence_x_cover": 0.0,
                "__gip_reporting_over_cease": _g_over_cease,
            })
            continue

        E = int(row["age_next"]) if row.get("age_next") is not None else int(_gipf(row.get("age_nb")))
        K = row.get("gender")
        I = _gipf(row.get("annual_salary"))
        J = _gipf(row.get("monthly_salary")) or (I / 12.0)
        M = int(round(_gipf(row.get("nra_final") if row.get("nra_final") is not None else row.get("nra"))))
        L = _gipf(row.get("waiver"))
        member_hcc = row.get("hcc_waiver")
        dob = row.get("date_of_birth")

        # category inputs (reader)
        core_perc  = g.gip_core_benefit_perc.get(cat, [0, 0, 0, 0])
        core_layer = g.gip_core_benefit_layer.get(cat, [0, 0, 0, 0])
        add_perc   = _gipf(g.gip_core_benefit_perc_additional.get(cat))
        add_layer  = _gipf(g.gip_core_benefit_layer_additional.get(cat))
        AC         = _gipf(g.gip_core_overall_maximum.get(cat))
        emp_waiver = _gipf(g.gip_employer_waiver.get(cat))
        waiver_spec = g.gip_waiver_pct_specified.get(cat, "N/A")     # val16_2

        # val3_2 "Waiver Included?" — Load-only field; guarded default.
        val3_2 = waiver_incl_map.get(cat, "No")
        assert val3_2 == "No", (
            f"[gip] cat {cat}: 'Waiver Included?'={val3_2!r} — engine verified only "
            f"for 'No'. Wire CatInput-Load AE source before pricing 'Yes' schemes.")

        core_def = g.gip_core_disability_definition.get(cat)
        ext_def  = g.gip_hcc_disability_definition.get(cat)
        init_pd  = g.gip_initial_period.get(cat)
        wp_str   = g.gip_waiting_period.get(cat)
        esc_pct  = _gipf(g.gip_escalation_pct.get(cat))
        tax_opt  = g.gip_tax_options.get(cat)
        backdating = g.gip_backdating.get(cat)

        # HCC (ext)
        AQ = g.gip_include_hcc_waiver.get(cat, "No")
        AR = _gipf(g.gip_hcc_payment_period.get(cat))
        AS = g.gip_hcc_payment_type.get(cat)
        AT_nom = _gipf(g.gip_hcc_nominal_amount.get(cat))
        AV = _gipf(g.gip_hcc_escalation_pct.get(cat))
        AY = g.gip_include_conversion_option.get(cat, "No")

        # ---- waiver LET: resolve S/U/W/Y ----
        def _resolve(base):
            if waiver_spec == "N/A":
                return base
            if waiver_spec == "As Per Data":
                add = L if val3_2 == "No" else 0.0
            elif waiver_spec == "Same For All":
                add = emp_waiver if val3_2 == "No" else 0.0
            else:
                add = 0.0
            return base + add
        S = _resolve(_gipf(core_perc[0]))
        U = _resolve(_gipf(core_perc[1]))
        W = _resolve(_gipf(core_perc[2]))
        Y = _resolve(_gipf(core_perc[3]))
        T, V, X, Z = (_gipf(core_layer[0]), _gipf(core_layer[1]),
                      _gipf(core_layer[2]), _gipf(core_layer[3]))

        # BE employer waiver pm
        BE = (L * J) if (val3_2 == "No" and waiver_spec == "As Per Data") else (emp_waiver * J)

        # ---- ladder CO/CP/CQ ----
        CO = (S * min(J, T)
              + U * max(0, min(V, J - T))
              + W * max(0, min(X, J - T - V))
              + Y * max(0, min(Z, J - T - V - X)))
        CP = max(0, add_perc * min(J, add_layer))
        CQ = min(CO + CP, AC)

        # ---- tax cascade -> CV -> CW ----
        CT = J / pear
        CU = CT - BE
        b = _gip_asof(bands, "band_from", None, CU * 12) if False else None
        # inline band find (need whole row)
        bandrow = None
        for br in bands:
            if br["band_from"] <= CU * 12:
                bandrow = br
            else:
                break
        tax = 0.0 if bandrow is None else max(
            bandrow["basic_amount"] + (CU * 12 - bandrow["band_from"]) * bandrow["margin"] - rebate, 0.0)
        CV = (CT * 12 - tax) / 12
        CW = min(CQ, CV)

        # ---- CK: Tax Replicator initial benefit (TT GIP col CK) ----
        # CF = ladder gross of tax (== engine CO); CI = CF - employer waiver (BE).
        # CK = (CF*12 - tax(CI*12)) / 12.  No AC cap (TT CK4 has no MIN(...,max)).
        # Verified rand-perfect vs TT 2026-08-04: member 1 (tax=0) and
        # member 8364 (tax_ci=5027.50, CK=11488.278158).
        _CF = CO
        _CI = _CF - BE
        _br_ci = None
        for _br in bands:
            if _br['band_from'] <= _CI * 12:
                _br_ci = _br
            else:
                break
        _tax_ci = 0.0 if _br_ci is None else max(
            _br_ci['basic_amount'] + (_CI * 12 - _br_ci['band_from']) * _br_ci['margin'] - rebate, 0.0)
        CK = (_CF * 12 - _tax_ci) / 12

        # ---- BA ----
        if tax_opt == "Apply net-of-tax maximum":
            BA = CW
        elif tax_opt == "Tax Replicator":
            BA = CK
        else:
            BA = CQ

        # ---- incidence DC ----
        BH = mort_map.get((E, K), 0.0)
        BJ = _gip_wp_months(wp_str)
        BK = None
        if BJ is not None:
            sub = [r for r in wp_rows if int(r["wp_months"]) == int(BJ) and r["age_band_from"] <= E]
            BK = sub[-1]["factor"] if sub else None
        BM = _gip_asof(sb_by_g.get(K, []), "salary_from", "inc_adj", I)
        BN = _gip_asof(sb_by_g.get(K, []), "salary_from", "acaf_adj", I)
        BX = int(_gip_asof(asb_rows, "salary_from", "sal_tier", I))
        BQ = BA / J if J > 0 else 0.0
        BR = _gip_asof(rr_rows, "rr_from", "loading", BQ)
        BU = ip_adj.get(init_pd)
        BT = ip_mm.get(init_pd)
        BV = (core_def or "") + (ext_def or "")
        BW = db_map.get(BV)
        BL = _gip_backdating_loading(B, backdating)

        DC = (_gipf(BH) / 1000 * _gipf(BK) * _gipf(BM) * _gipf(BN)
              * BO_val * BP_val * _gipf(BR) * _gipf(BU) * _gipf(BW))

        # ---- annuity DE ----
        nr = nra_map.get(M, {})
        FK = nr.get("age_lookup")
        FL = nr.get("age_interp")
        FR = _gipf(nr.get("linear_scaler"))
        BY = wpann.get(BJ)
        FM = "/".join([_gip_key_part(E), _gip_key_part(K), _gip_key_part(BY),
                       _gip_key_part(BT), _gip_key_part(FK), _gip_esc_key(esc_pct),
                       size_title])
        af_row = af_map.get(FM)
        sal_col = {1: "sal_1", 2: "sal_2", 3: "sal_3"}[BX]
        FO = (_gipf(af_row[sal_col]) * (1 + BL)) if af_row else None
        FS = _gip_annuity_fs_fast(FO, FR, af_map, sal_col, BL, esc_map, esc_pct,
                             size_title, E, K, BY, BT, FK, FL)

        DF = DC * BA * _gipf(FS)

        # --- no-escalation net premium (TT GIP!DI = DC*DD*CC) ---
        FM0 = "/".join([_gip_key_part(E), _gip_key_part(K), _gip_key_part(BY),
                        _gip_key_part(BT), _gip_key_part(FK), _gip_esc_key(0.0),
                        size_title])
        af_row0 = af_map.get(FM0)
        FO0 = (_gipf(af_row0[sal_col]) * (1 + BL)) if af_row0 else None
        FS0 = _gip_annuity_fs_fast(FO0, FR, af_map, sal_col, BL, esc_map, 0.0,
                              size_title, E, K, BY, BT, FK, FL)
        # calc FY = IFERROR(FV+FX*FR, GH): when the no-esc FL-interp key
        # is missing (calc FW=#N/A), FY falls back to GH = with-esc base FO.
        # Affects age-64 esc>0 members; keeps DF exact, closes DI/DJ split.
        _fl0 = "/".join([_gip_key_part(E), _gip_key_part(K), _gip_key_part(BY),
                         _gip_key_part(BT), _gip_key_part(FL), _gip_esc_key(0.0),
                         size_title])
        if af_map.get(_fl0) is None and FO is not None:
            FS0 = FO
        DF0 = DC * BA * _gipf(FS0)

        # ---- HCC DB ----
        if AQ != "Yes":
            DB = 0.0
        else:
            AT = AT_nom if AS == "Nominal Amount" else _gipf(member_hcc)
            dob_d = dob if isinstance(dob, date) else dob
            ret = _gip_eomonth(dob_d.year + M, dob_d.month)
            mtr = round(12 * _gip_yearfrac_30_360(comm, ret))
            esc_f = (1 + AV) ** max((AR - 12) / 12, 0)
            annuity6 = (1 - (1.06) ** (-max(min(AR - _gipf(BJ), mtr), 0) / 12)) / 0.06
            DB = (AT * 12) * DC * annuity6 * J5 * esc_f

        # ---- CO DH ----
        gate = (AY == "Yes") and (E <= min(M - f452, f451))
        DH = (co_cost if gate else 0.0) * DF

        results.append({
            "member_no": member_no,
            "__gip_cover": BA,
            "__gip_basic": DF,
            "__gip_co": DH,
            "__gip_hcc": DB,          # ← was folded into __gip_total; now separate
            "__gip_basic_excl_esc": DF0,
            "__gip_reporting_incidence": DC,
            "__gip_reporting_incidence_x_cover": DC * BA,
            "__gip_reporting_over_cease": False,
        })

    # ---- write results back onto df ----
    res = pl.DataFrame(results)
    df = df.join(res, on="member_no", how="left")
    if _gip_excluded:
        df = df.with_columns(
            pl.when(pl.col("member_no").is_in(list(_gip_excluded)))
              .then(pl.lit(False)).otherwise(pl.col("product_active"))
              .alias("product_active"))
    df = df.with_columns([
        pl.col("__gip_cover").fill_null(0.0).alias("total_cover"),
        pl.col("__gip_basic").fill_null(0.0).alias("basic_technical_premium"),
        pl.lit(0.0).alias("aids_technical_premium"),
        pl.col("__gip_co").fill_null(0.0).alias("co_premium"),
        pl.col("__gip_hcc").fill_null(0.0).alias("waiver_premium"),   # HCC (DB) → summed by engine
        pl.col("__gip_basic_excl_esc").fill_null(0.0).alias("basic_excl_esc"),
        pl.col("__gip_reporting_incidence")
          .fill_null(0.0)
          .alias("reporting_incidence"),
        pl.col("__gip_reporting_incidence_x_cover")
          .fill_null(0.0)
          .alias("reporting_incidence_x_cover"),
        pl.col("__gip_reporting_over_cease")
          .fill_null(False)
          .alias("reporting_over_cease"),
    ])
    df = df.with_columns(
        pl.when(pl.col("total_cover") > 0)
          .then(pl.col("basic_technical_premium") / pl.col("total_cover") * 1000)
          .otherwise(0.0).alias("rate_basic")
    )
    df = df.with_columns(pl.lit(0.0).alias("rate_aids"))
    return df.drop([
        "__gip_cover",
        "__gip_basic",
        "__gip_co",
        "__gip_hcc",
        "__gip_basic_excl_esc",
        "__gip_reporting_incidence",
        "__gip_reporting_incidence_x_cover",
        "__gip_reporting_over_cease",
    ])

# ============================================================================
# TIP COMPOSITE — paste into helpers.py after _apply_gip_composite.
# Register in apply_special_premium:
#     if kind == "tip_composite":
#         return _apply_tip_composite(df, spec, basis_tables, assump_tables, ctx)
# Add to compute_cover: elif rule == "tip_composite": pre_tax_cover = 0 stub
#
# TIP premium = TV = TS · TT · TU   (basic technical only)
#   TS (incidence) = BD/1000·BG·BH·BI·BJ·BK·BM·BW   (8 factors — NO ip_loading)
#   TT (cover)     = AX (tax cascade, shares GIP TaxTable + Primary_Rebate_GIP)
#   TU (annuity)   = XC (TRILINEAR: age × maxPP × ESC, own TIP tables, NO (1+BL))
# No HCC premium, no CO, no waiver premium.  Reuses GIP incidence basis (truth).
# TIP-specific: tip_db_loading (core-def only), tip_esc_loading, tip annuity + interp.
# ============================================================================


def _tip_esc_str(v):
    """annuity esc key part: '5.0'->'5', keep 'Uncapped'."""
    if v is None:
        return "0"
    if isinstance(v, str) and v.strip().lower() == "uncapped":
        return "Uncapped"
    try:
        return str(int(float(v)))
    except (TypeError, ValueError):
        return str(v)


def _tip_annuity_fs(af_map, sal_col, E, K, WC, BO, size,
                    age_row, pp_row, esc_row, WB):
    """XC = (WK+WS+XB)*(1+WW); Excel error-propagation: if WK/WS/XB touch a
    missing annuity key (#N/A), the whole primary errors -> XF fallback.
    XF key hardcodes SMALL (calc XE = 40/F/3/12/{WU}/SMALL/{WB}). WB=0 -> 0."""
    if WB == 0:
        return 0.0
    WD = age_row["closest_age"]; WE = age_row["interp_age"]; WF = _gipf(age_row["age_factor"])
    WL = pp_row["closest_pp"];   WM = pp_row["interp_pp"];   WN = _gipf(pp_row["pp_factor"])
    WT = _tip_esc_str(esc_row["map_lower"]); WU = _tip_esc_str(esc_row["map_upper"])
    WV = _gipf(esc_row["interp_adj"]);        WW = _gipf(esc_row["progression_loading"])

    def ann(age, esc, maxpp):
        key = "/".join([_gip_key_part(age), K, _gip_key_part(WC),
                        _gip_key_part(BO), esc, size, _gip_key_part(maxpp)])
        r = af_map.get(key.lower())
        return float(r[sal_col]) if r else None

    def _xf():
        fk = "/".join(["40", "F", "3", "12", WU, "Small", _gip_key_part(WB)])
        r = af_map.get(fk.lower())
        return float(r[sal_col]) if r is not None else 0.0

    WI = ann(WD, WT, WL); WJ = ann(WE, WT, WL)
    if WI is None or WJ is None:
        return _xf()
    WK = WI + (WJ - WI) * WF

    WQ = ann(WD, WT, WL); WR = ann(WD, WT, WM)
    if WQ is None or WR is None:
        return _xf()
    WS = (WR - WQ) * WN

    WZ = ann(WD, WT, WL); XA = ann(WD, WU, WL)
    if WZ is None or XA is None:
        return _xf()
    XB = (XA - WZ) * WV

    return (WK + WS + XB) * (1 + WW)

def _apply_tip_composite(df, spec, basis_tables, assump_tables, ctx):
    """TIP composite: TV = TS·TT·TU. FC-shaped (enrich + return df)."""
    scheme = ctx.scheme
    g = scheme
    size  = ctx.scheme_size.lower()      # basis filter
    size_t = ctx.scheme_size             # annuity key ("Small"/"Large")
    comm  = ctx.calc_date
    sec_ind = scheme.secondary
    pear = float(scheme.pear_tgp_pct) if scheme.pear_tgp_pct else 1.0
    B = basis_tables

    # ---- shared GIP incidence basis (truth) ----
    mort_map = {(int(r["age"]), r["gender"]): r["rate"]
                for r in B["mortality"].filter(pl.col("product") == "gip").iter_rows(named=True)}
    sb_rows = (B["salary_band"].filter(pl.col("product") == "gip")
               .select(["gender", "salary_from", "inc_adj", "acaf_adj"])
               .sort(["gender", "salary_from"]).to_dicts())
    sb_by_g = {gd: [r for r in sb_rows if r["gender"] == gd] for gd in ("M", "F")}
    ind = B["industry"].filter((pl.col("product") == "gip") & (pl.col("scheme_size") == size))
    ind_row = ind.filter(pl.col("secondary") == sec_ind)
    if ind_row.height == 0:
        raise KeyError(f"[tip] industry '{sec_ind}' not found size={size}")
    BJ_val = float(ind_row["inc_adj"][0]); BK_val = float(ind_row["acaf_adj"][0])
    rr_rows = (B["rr_loading"].filter(pl.col("product") == "gip")
               .select(["rr_from", "loading"]).sort("rr_from").to_dicts())
    wp_rows = (B["wp_loading"].filter((pl.col("product") == "gip") & (pl.col("scheme_size") == size))
               .select(["age_band_from", "wp_months", "factor"])
               .sort(["wp_months", "age_band_from"]).to_dicts())
    asb_rows = (B["annuity_salary_bands"].filter(pl.col("product") == "gip")
                .select(["salary_from", "sal_tier"]).sort("salary_from").to_dicts())
    ip = B["ip_loading"].filter(pl.col("product") == "gip")
    ip_mm = {r["ip_label"]: r["mapped_months"] for r in ip.iter_rows(named=True)}

    # ---- TIP-specific basis ----
    tip_db = {r["db_def"]: r["loading"]
              for r in B["tip_db_loading"].filter(pl.col("product") == "tip").iter_rows(named=True)}
    af_map = {r["key"].lower(): r
              for r in B["tip_annuity_factors"].filter(pl.col("product") == "tip").iter_rows(named=True)}    
    age_map = {int(r["age"]): r
               for r in B["tip_age_interp"].filter(pl.col("product") == "tip").iter_rows(named=True)}
    pp_map = {int(r["pp_key"]): r
              for r in B["tip_payment_period_map"].filter(pl.col("product") == "tip").iter_rows(named=True)}
    ppl_map = {r["pp_label"]: int(r["pp_months"])
               for r in B["tip_payment_period_map"].filter(pl.col("product") == "tip").iter_rows(named=True)}
    esc_rows = B["tip_esc_loading"].filter(pl.col("product") == "tip")
    esc_map = {}
    for r in esc_rows.iter_rows(named=True):
        k = "Uncapped" if r["esc_pct"] is None else round(float(r["esc_pct"]), 2)
        esc_map[k] = r
    wpann = {int(r["wp_raw"]): int(r["wp_annuity"])
             for r in B["tip_wp_ann_map"].filter(pl.col("product") == "tip").iter_rows(named=True)}

    # ---- shared tax bands (gip) ----
    tx = (assump_tables["tax_tables"].filter(pl.col("tax_year") == "2026-2027_gip")
          .select(["band_from", "margin", "basic_amount", "primary_rebate"])
          .with_columns([pl.col(c).cast(pl.Float64, strict=False)
                         for c in ["band_from", "margin", "basic_amount", "primary_rebate"]])
          .drop_nulls("band_from").sort("band_from"))
    bands = tx.to_dicts()
    rebate = bands[0]["primary_rebate"] if bands else 0.0

    waiver_incl = getattr(g, "tip_waiver_included", {}) or {}

    results = []
    _tip_excluded = set()
    for row in df.iter_rows(named=True):
        cat = int(row["category_number"]) if row.get("category_number") is not None else None
        mno = row.get("member_no")
        if cat is None or not bool(row.get("product_active")):
            results.append({
                "member_no": mno,
                "__c": 0.0,
                "__b": 0.0,
                "__b0": 0.0,
                "__tip_reporting_incidence": 0.0,
                "__tip_reporting_incidence_x_cover": 0.0,
                "__tip_reporting_over_cease": False,
            })
            continue

        _g_age = _gipf(row.get("age"))
        _g_cease = _gipf(row.get("ceasing_age") if row.get("ceasing_age") is not None else row.get("nra_final"))
        _g_wpm = _gip_wp_months(g.tip_waiting_period.get(cat))
        _g_wpm = _g_wpm if _g_wpm is not None else 0.0
        _g_over_cease = _g_age > _g_cease

        if not (_g_age >= 16 and _g_age <= _g_cease and (_g_cease - _g_age) * 12.0 >= _g_wpm):
            _tip_excluded.add(mno)
            results.append({
                "member_no": mno,
                "__c": 0.0,
                "__b": 0.0,
                "__b0": 0.0,
                "__tip_reporting_incidence": 0.0,
                "__tip_reporting_incidence_x_cover": 0.0,
                "__tip_reporting_over_cease": _g_over_cease,
            })
            continue

        E = int(row["age_next"]) if row.get("age_next") is not None else int(_gipf(row.get("age_nb")))
        K = row.get("gender")
        I = _gipf(row.get("annual_salary"))
        J = _gipf(row.get("monthly_salary")) or (I / 12.0)
        M = int(round(_gipf(row.get("nra_final") if row.get("nra_final") is not None else row.get("nra"))))
        L = _gipf(row.get("waiver"))

        # category inputs
        cp = g.tip_core_benefit_perc.get(cat, [0, 0, 0, 0])
        cl = g.tip_core_benefit_layer.get(cat, [0, 0, 0, 0])
        add_p = _gipf(g.tip_core_benefit_perc_additional.get(cat))
        add_l = _gipf(g.tip_core_benefit_layer_additional.get(cat))
        AB = _gipf(g.tip_core_overall_maximum.get(cat))
        emp_w = _gipf(g.tip_employer_waiver.get(cat))
        wspec = g.tip_waiver_pct_specified.get(cat, "N/A")
        val3_2 = waiver_incl.get(cat, "No")
        assert val3_2 == "No", (f"[tip] cat {cat}: 'Waiver Included?'={val3_2!r} — "
                                f"engine verified only for 'No'.")
        core_def = g.tip_core_disability_definition.get(cat)
        init_pd = g.tip_initial_period.get(cat)
        wp_str = g.tip_waiting_period.get(cat)
        esc_pct = _gipf(g.tip_escalation_pct.get(cat))
        tax_opt = g.tip_tax_options.get(cat)
        pp_label = g.tip_payment_period.get(cat)       # trailing col 240

        # waiver LET
        def _res(base):
            if wspec == "N/A":
                return base
            if wspec == "As Per Data":
                add = L if val3_2 == "No" else 0.0
            elif wspec == "Same For All":
                add = emp_w if val3_2 == "No" else 0.0
            else:
                add = 0.0
            return base + add
        R = _res(_gipf(cp[0])); T = _res(_gipf(cp[1])); Vp = _res(_gipf(cp[2])); Xp = _res(_gipf(cp[3]))
        S, U, W, Yl = _gipf(cl[0]), _gipf(cl[1]), _gipf(cl[2]), _gipf(cl[3])
        BAw = (L * J) if (val3_2 == "No" and wspec == "As Per Data") else (emp_w * J)

        # ---- cover ladder + tax cascade -> AX ----
        TH = (R*min(J, S) + T*max(0, min(U, J-S)) + Vp*max(0, min(W, J-S-U))
              + Xp*max(0, min(Yl, J-S-U-W)))
        TI = max(0, add_p*min(J, add_l))
        TJ = min(TH + TI, AB)
        TM = J / pear
        TN = TM - BAw
        br = None
        for b in bands:
            if b["band_from"] <= TN*12: br = b
            else: break
        tax = 0.0 if br is None else max(br["basic_amount"] + (TN*12-br["band_from"])*br["margin"] - rebate, 0.0)
        TO = (TM*12 - tax) / 12
        if tax_opt == "Apply net-of-tax maximum":
            AX = min(TJ, TO)
        elif tax_opt == "Tax Replicator":
            # ---- TD: TIP Tax Replicator initial benefit (TT col TD; TF=min(TD,AB)) ----
            # SY = ladder gross (== engine TH); TB = SY - employer waiver (BAw).
            # TD = (SY*12 - tax(TB*12))/12;  AX = min(TD, AB) = TT TF4 (scheme-max capped).
            # Verified rand-perfect vs TT 2026-08-04: member 8364 (tax=5027.50, TF=11488.278158)
            # + member 8497 (tax=0, TF=8964.473684).  Extended (TG/AZ) not emitted, consistent
            # with the other two tax branches (initial-only).
            _SY = TH
            _TB = _SY - BAw
            _br_tb = None
            for _b in bands:
                if _b['band_from'] <= _TB * 12:
                    _br_tb = _b
                else:
                    break
            _tax_tb = 0.0 if _br_tb is None else max(
                _br_tb['basic_amount'] + (_TB * 12 - _br_tb['band_from']) * _br_tb['margin'] - rebate, 0.0)
            _TD = (_SY * 12 - _tax_tb) / 12
            AX = min(_TD, AB)
        else:
            AX = TJ

        # ---- incidence TS (8 factors, no ip_loading) ----
        BD = mort_map.get((E, K), 0.0)
        BF = _gip_wp_months(wp_str)          # WP months
        BG = None
        if BF is not None:
            sub = [r for r in wp_rows if int(r["wp_months"]) == int(BF) and r["age_band_from"] <= E]
            BG = sub[-1]["factor"] if sub else None
        BH = _gip_asof(sb_by_g.get(K, []), "salary_from", "inc_adj", I)
        BI = _gip_asof(sb_by_g.get(K, []), "salary_from", "acaf_adj", I)
        BL = AX / J if J > 0 else 0.0        # replacement ratio
        BM = _gip_asof(rr_rows, "rr_from", "loading", BL)
        BW = tip_db.get(core_def)            # TIP db keyed on CORE def only
        TS = (_gipf(BD)/1000 * _gipf(BG) * _gipf(BH) * _gipf(BI)
              * BJ_val * BK_val * _gipf(BM) * _gipf(BW))

        # ---- annuity TU = XC (trilinear) ----
        BO = ip_mm.get(init_pd)              # IP mapped months (annuity key)
        BP = int(_gip_asof(asb_rows, "salary_from", "sal_tier", I))
        sal_col = {1: "sal_1", 2: "sal_2", 3: "sal_3"}[BP]
        WC = wpann.get(BF)                   # WP -> annuity WP
        WA = ppl_map.get(pp_label)           # pp label -> months
        WB = max(0, min(WA, (M - E)*12 - BF + 1)) if WA is not None else 0
        age_row = age_map.get(E)
        pp_row  = pp_map.get(int(WB)) if WB in pp_map else pp_map.get(WB)
        esc_row = esc_map.get(round(esc_pct, 2))
        if age_row is None or pp_row is None or esc_row is None:
            TU = 0.0
        else:
            TU = _tip_annuity_fs(af_map, sal_col, E, K, WC, BO, size_t,
                                 age_row, pp_row, esc_row, WB)

        # --- no-escalation annuity (TT TIP!XQ = fs at esc=0) ---
        esc_row0 = esc_map.get(0.0)
        if age_row is None or pp_row is None or esc_row0 is None:
            TU0 = 0.0
        else:
            TU0 = _tip_annuity_fs(af_map, sal_col, E, K, WC, BO, size_t,
                                  age_row, pp_row, esc_row0, WB)
        TV0 = TS * AX * _gipf(TU0)

        TV = TS * AX * _gipf(TU)
        results.append({
            "member_no": mno,
            "__c": AX,
            "__b": TV,
            "__b0": TV0,
            "__tip_reporting_incidence": TS,
            "__tip_reporting_incidence_x_cover": TS * AX,
            "__tip_reporting_over_cease": False,
        })

    res = pl.DataFrame(results)
    df = df.join(res, on="member_no", how="left")
    if _tip_excluded:
        df = df.with_columns(
            pl.when(pl.col("member_no").is_in(list(_tip_excluded)))
              .then(pl.lit(False)).otherwise(pl.col("product_active"))
              .alias("product_active"))
    df = df.with_columns([
        pl.col("__c").fill_null(0.0).alias("total_cover"),
        pl.col("__b").fill_null(0.0).alias("basic_technical_premium"),
        pl.lit(0.0).alias("aids_technical_premium"),
        pl.lit(0.0).alias("co_premium"),
        pl.lit(0.0).alias("waiver_premium"),
        pl.col("__b0").fill_null(0.0).alias("basic_excl_esc"),
        pl.col("__tip_reporting_incidence")
          .fill_null(0.0)
          .alias("reporting_incidence"),
        pl.col("__tip_reporting_incidence_x_cover")
          .fill_null(0.0)
          .alias("reporting_incidence_x_cover"),
        pl.col("__tip_reporting_over_cease")
          .fill_null(False)
          .alias("reporting_over_cease"),
    ])
    df = df.with_columns(
        pl.when(pl.col("total_cover") > 0)
          .then(pl.col("basic_technical_premium") / pl.col("total_cover") * 1000)
          .otherwise(0.0).alias("rate_basic"))
    df = df.with_columns(pl.lit(0.0).alias("rate_aids"))
    return df.drop([
        "__c",
        "__b",
        "__b0",
        "__tip_reporting_incidence",
        "__tip_reporting_incidence_x_cover",
        "__tip_reporting_over_cease",
    ])


def _apply_ti_scales_gla(df, spec, basis, prior):
    """Terminal premium = GLA_basic × TI_factor × TI_cover / GLA_cover."""
    ti = basis["ti_factors"]
    if ti is None or ti.height == 0:
        return df.with_columns(pl.lit(0.0).alias("basic_technical_premium"))

    df = df.with_columns([
        pl.when(
            (pl.col("first_year_of_cover").cast(pl.Utf8) == "Yes") &
            (pl.col("spread_initial_year_cost").cast(pl.Utf8) != "Yes")
        ).then(pl.lit("first_year"))
         .when(pl.col("spread_initial_year_cost").cast(pl.Utf8) == "Yes")
             .then(pl.lit("uniform"))
         .otherwise(pl.lit("ongoing"))
         .alias("__ti_cost_basis")
    ])

    ti_long_m = ti.select(["cost_basis", "age",
                            pl.col("non_aids_m").alias("__ti_basic"),
                            pl.col("aids_m").alias("__ti_aids")])\
                   .with_columns(pl.lit("M").alias("gender"))
    ti_long_f = ti.select(["cost_basis", "age",
                            pl.col("non_aids_f").alias("__ti_basic"),
                            pl.col("aids_f").alias("__ti_aids")])\
                   .with_columns(pl.lit("F").alias("gender"))
    ti_long = pl.concat([ti_long_m, ti_long_f])

    df = df.with_columns([
        pl.col("age_nb").cast(pl.Int64),
        pl.col("gender").cast(pl.Utf8),
    ])
    ti_long = ti_long.with_columns([
        pl.col("age").cast(pl.Int64),
        pl.col("gender").cast(pl.Utf8),
        pl.col("cost_basis").cast(pl.Utf8),
    ])
    df = df.join(
        ti_long,
        left_on=["__ti_cost_basis", "age_nb", "gender"],
        right_on=["cost_basis", "age", "gender"],
        how="left",
    )

    gla = prior.get("gla")
    if gla is None:
        return df.with_columns([
            pl.lit(0.0).alias("basic_technical_premium"),
            pl.lit(0.0).alias("aids_technical_premium"),
        ])

    gla_cols = gla.select([
        "member_no",
        pl.col("basic_technical_premium").alias("__gla_basic"),
        pl.col("aids_technical_premium").alias("__gla_aids"),
        pl.col("total_cover").alias("__gla_cover"),
    ])
    df = df.join(gla_cols, on="member_no", how="left")

    df = df.with_columns([
        pl.when(pl.col("__gla_cover") > 0)
          .then(pl.col("__gla_basic") * pl.col("__ti_basic").fill_null(0.0) *
                pl.col("total_cover") / pl.col("__gla_cover"))
          .otherwise(0.0).alias("basic_technical_premium"),
        pl.when(pl.col("__gla_cover") > 0)
          .then(pl.col("__gla_aids") * pl.col("__ti_aids").fill_null(0.0) *
                pl.col("total_cover") / pl.col("__gla_cover"))
          .otherwise(0.0).alias("aids_technical_premium"),
    ])

    df = df.with_columns(
        pl.when(pl.col("total_cover") > 0)
          .then(pl.col("basic_technical_premium") / pl.col("total_cover") * 1000)
          .otherwise(0.0).alias("rate_basic")
    )
    df = df.with_columns(pl.lit(0.0).alias("rate_aids"))

    return df.drop(["__ti_cost_basis", "__ti_basic", "__ti_aids",
                    "__gla_basic", "__gla_aids", "__gla_cover"])


def attach_gla_cover_for_ti(df, prior_results):
    """Attach GLA total_cover as '__gla_cover_for_ti' for cover_type='Set equal to GLA Cover'."""
    gla = prior_results.get("gla")
    if gla is None:
        return df.with_columns(pl.lit(0.0).alias("__gla_cover_for_ti"))
    return df.join(
        gla.select(["member_no", pl.col("total_cover").alias("__gla_cover_for_ti")]),
        on="member_no", how="left"
    )


# ============================================================
# 8. ADD-ONS  (CO premiums for existing 9 products)
# ============================================================
# All CO helpers share the same eligibility gate to match TT's Standard
# Margins row 39 convention.
# ============================================================
def _co_eligibility_mask(df: pl.DataFrame,
                          ineligible_statuses: tuple[str, ...] = ()) -> pl.Expr:
    mask = pl.col("product_active") & (pl.col("age") <= pl.col("ceasing_age"))
    if ineligible_statuses and "status" in df.columns:
        mask = mask & ~pl.col("status").cast(pl.Utf8).is_in(list(ineligible_statuses))
    return mask


def co_premium_gla(df, cats_wide, assump_tables, ctx, target="co_premium"):
    co_tbl = assump_tables["conversion_option"].filter(pl.col("product") == "gla")
    rate_le65_rw = _co_rate(co_tbl, "<=65", "retirement_and_withdrawal")
    rate_gt65_rw = _co_rate(co_tbl, ">65",  "retirement_and_withdrawal")
    rate_le65_wo = _co_rate(co_tbl, "<=65", "withdrawal_only")
    rate_gt65_wo = _co_rate(co_tbl, ">65",  "withdrawal_only")
    code_rw = int(_co_rate(co_tbl, "code_map", "retirement_and_withdrawal"))
    code_wo = int(_co_rate(co_tbl, "code_map", "withdrawal_only"))

    limits = ctx.limits_for("gla")
    max_co_age = limits.get("max_co_age", 80)
    pre_nra_cap = limits.get("withdrawal_only_pre_nra_cap", 0)

    df = df.with_columns([
        pl.when(pl.col("conversion_option_structure") == "Retirement and Withdrawal")
          .then(pl.lit(code_rw))
          .when(pl.col("conversion_option_structure") == "Withdrawal only")
          .then(pl.lit(code_wo))
          .otherwise(pl.lit(0))
          .alias("__co_code")
    ])
    df = df.with_columns([
        pl.when(pl.col("nra_final") <= 65)
          .then(pl.when(pl.col("__co_code") == code_rw).then(pl.lit(rate_le65_rw))
                  .when(pl.col("__co_code") == code_wo).then(pl.lit(rate_le65_wo))
                  .otherwise(0.0))
          .otherwise(pl.when(pl.col("__co_code") == code_rw).then(pl.lit(rate_gt65_rw))
                       .when(pl.col("__co_code") == code_wo).then(pl.lit(rate_gt65_wo))
                       .otherwise(0.0))
          .alias("__co_pct_base")
    ])
    df = df.with_columns([
        pl.when(pl.col("age") > max_co_age).then(0.0)
          .when(pl.col("age") <= (pl.col("nra_final") - pre_nra_cap * (pl.col("__co_code") - 1)))
              .then(pl.col("__co_pct_base"))
          .when((pl.col("age") > pl.col("nra_final")) & (pl.col("age") <= pl.col("ceasing_age")))
              .then((2 - pl.col("__co_code")) * pl.col("__co_pct_base"))
          .otherwise(0.0)
          .alias("co_pct")
    ])
    df = df.with_columns([
        pl.when(pl.col("include_conversion_option").cast(pl.Utf8) == "Yes")
          .then(pl.col("co_pct") * pl.col("basic_technical_premium"))
          .otherwise(0.0).alias(target)
    ]).drop(["__co_code", "__co_pct_base"])
    return df


def co_premium_lsdb(df, cats_wide, assump_tables, ctx, target="co_premium",
                     ineligible_statuses: tuple[str, ...] = ()):
    co_tbl = assump_tables["conversion_option"].filter(pl.col("product") == "lsdb")
    rate_le65 = _co_rate(co_tbl, "<=65", "all")
    rate_gt65 = _co_rate(co_tbl, ">65",  "all")

    limits = ctx.limits_for("lsdb")
    max_co_age  = limits.get("max_co_age", 65)
    pre_nra_cap = limits.get("co_pre_nra_cap", 5)

    df = df.with_columns([
        pl.when(pl.col("nra_final") <= 65).then(pl.lit(rate_le65))
          .otherwise(pl.lit(rate_gt65)).alias("__co_rate")
    ])

    df = df.with_columns([
        pl.when(
            pl.col("age") < pl.min_horizontal([
                pl.col("nra_final") - pl.lit(pre_nra_cap),
                pl.lit(max_co_age),
            ])
        )
        .then(pl.col("__co_rate"))
        .otherwise(0.0)
        .alias("co_pct")
    ])

    elig = _co_eligibility_mask(df, ineligible_statuses)
    df = df.with_columns([
        pl.when(
            (pl.col("include_conversion_option").cast(pl.Utf8) == "Yes") & elig
        )
        .then(pl.col("co_pct") * pl.col("basic_technical_premium"))
        .otherwise(0.0)
        .alias(target)
    ]).drop("__co_rate")
    return df


def co_premium_spouse(df, cats_wide, assump_tables, ctx, target="co_premium"):
    """Spouse GLA CO."""
    co_tbl = assump_tables["conversion_option"].filter(pl.col("product") == "spouse")
    rate_le65 = _co_rate(co_tbl, "<=65", "all")
    rate_gt65 = _co_rate(co_tbl, ">65",  "all")

    df = df.with_columns([
        pl.when(pl.col("age") < 65)
          .then(pl.when(pl.col("nra_final") <= 65).then(pl.lit(rate_le65))
                  .otherwise(pl.lit(rate_gt65)))
          .otherwise(0.0)
          .alias("co_pct")
    ])
    df = df.with_columns([
        pl.when(pl.col("include_conversion_option").cast(pl.Utf8) == "Yes")
          .then(pl.col("co_pct") * pl.col("basic_technical_premium"))
          .otherwise(0.0).alias(target)
    ])
    return df


def co_premium_ci(df, cats_wide, assump_tables, ctx, target="co_premium"):
    """CI CO premium."""
    co_tbl = assump_tables["conversion_option"].filter(pl.col("product") == "ci")
    co_rate = _co_rate(co_tbl, "<=65", "all")

    limits = ctx.limits_for("ci")
    max_co_age = limits.get("max_co_age", 65)
    pre_nra_cap = limits.get("withdrawal_only_pre_nra_cap", 5)

    df = df.with_columns([
        pl.min_horizontal([
            pl.col("nra_final") - pl.lit(pre_nra_cap),
            pl.lit(max_co_age),
        ]).alias("__co_cutoff")
    ])
    df = df.with_columns([
        pl.when((pl.col("age") < pl.col("__co_cutoff")) & (pl.col("status") == "A"))
          .then(pl.lit(co_rate))
          .otherwise(0.0).alias("co_pct")
    ])
    df = df.with_columns([
        pl.when(pl.col("include_conversion_option").cast(pl.Utf8) == "Yes")
          .then(pl.col("co_pct") * pl.col("basic_technical_premium"))
          .otherwise(0.0).alias(target)
    ]).drop("__co_cutoff")
    return df


def _co_rate(co_tbl, age_condition, co_type) -> float:
    row = co_tbl.filter(
        (pl.col("age_condition") == age_condition) & (pl.col("co_type") == co_type)
    )
    if row.height == 0:
        return 0.0
    return float(row["rate"][0])


def zero_addon(df, ctx, target: str) -> pl.DataFrame:
    return df.with_columns(pl.lit(0.0).alias(target))


def _as_yes(value) -> bool:
    """Normalise CTR yes/no style values."""
    if value is None:
        return False
    s = str(value).strip().lower()
    return s in {"yes", "y", "true", "1", "active"}


def _normalise_percent(value):
    """CTR may store 5% as 0.05, 5, or '5%'. Return decimal form."""
    if value is None:
        return None
    if isinstance(value, str):
        s = value.strip().replace("%", "")
        if not s:
            return None
        try:
            v = float(s)
        except ValueError:
            return None
    else:
        try:
            v = float(value)
        except (TypeError, ValueError):
            return None
    if v > 1:
        v = v / 100.0
    return v


def _cell_value(ws, row_idx: int, col_idx: int):
    """Safe cell reader for zero-based row/column indexing."""
    try:
        return ws[row_idx][col_idx]
    except Exception:
        return None


# ============================================================
# 8b. POST-RATE ADJUSTMENTS
# ============================================================
def apply_post_rate_adjust(df, adj, assump_tables, basis_tables=None, ctx=None):
    """Dispatch a post-rate adjustment.

    Signature extended (backward-compat via defaults) to accept basis_tables
    and ctx — FC-specific kinds reach into ctx.scheme.fc_* fields, ctx.globals,
    and basis_tables['fc_demographics' | 'fc_family_composition']. Existing
    kinds (spouse_*, db_definition_*) ignore the new args.

    Note: FC's composite handler now enriches columns inline (self-sufficient),
    so FC recipes don't need to declare these post_rate_adjust kinds. They're
    kept here for direct-call flexibility.
    """
    kind = adj["kind"]

    # --- existing kinds (unchanged) ---------------------------------------
    if kind == "db_definition_multiplicative":
        feats = assump_tables.get("lsdb_features")
        if feats is None:
            return df
        db_defs = feats.filter(pl.col("feature") == "db_definitions")\
                       .filter(pl.col("cost_basis") == "basic")\
                       .select(["key", "value"])\
                       .with_columns(pl.col("value").cast(pl.Float64, strict=False))
        df = df.with_columns(
            pl.col("definition_of_disability").cast(pl.Utf8)
              .str.to_lowercase()
              .str.replace_all(" ", "_")
              .str.replace_all("[^a-z_]", "")
              .alias("__db_key")
        )
        df = df.join(
            db_defs.rename({"key": "__db_key", "value": "__db_factor"}),
            on="__db_key", how="left"
        )
        df = df.with_columns(
            (pl.col("basic_technical_premium") *
             (1 + pl.col("__db_factor").fill_null(0.0))
            ).alias("basic_technical_premium")
        ).drop(["__db_key", "__db_factor"])
        return df

    if kind == "spouse_factor_multiplicative":
        sf = assump_tables.get("spouse_factors")
        if sf is None:
            return df
        rows = sf.filter(
            (pl.col("factor_type") == "basic_spouses_factor") &
            (pl.col("cost_basis") == "basic")
        ).select(["gender", "value"])\
         .with_columns(pl.col("value").cast(pl.Float64, strict=False))

        m_val = 0.0
        f_val = 0.0
        m_row = rows.filter(pl.col("gender") == "M")
        f_row = rows.filter(pl.col("gender") == "F")
        if m_row.height: m_val = float(m_row["value"][0] or 0.0)
        if f_row.height: f_val = float(f_row["value"][0] or 0.0)

        df = df.with_columns(
            pl.when(pl.col("gender") == "M").then(pl.lit(m_val))
              .when(pl.col("gender") == "F").then(pl.lit(f_val))
              .otherwise(0.0)
              .alias("__spouse_factor")
        )
        df = df.with_columns(
            (pl.col("basic_technical_premium") *
             (1 + pl.col("__spouse_factor"))
            ).alias("basic_technical_premium")
        ).drop("__spouse_factor")
        return df

    if kind == "spouse_db_definition_multiplicative":
        sf = assump_tables.get("spouse_factors")
        if sf is None:
            return df
        row = sf.filter(
            (pl.col("factor_type") == "db_definition_factor") &
            (pl.col("cost_basis") == "basic")
        )
        val = 0.0
        if row.height:
            v = row["value"][0]
            if v is not None:
                val = float(v)
        return df.with_columns(
            (pl.col("basic_technical_premium") * (1 + pl.lit(val)))
                .alias("basic_technical_premium")
        )

    # --- FC-specific kinds (kept for direct-call flexibility) --------------
    if kind == "fc_demographics_join":
        return _fc_demographics_join(df, basis_tables)

    if kind == "fc_family_composition_join":
        return _fc_family_composition_join(df, basis_tables, ctx)

    if kind == "fc_second_spouse_loading":
        return _fc_second_spouse_loading(df, assump_tables, ctx)

    if kind == "fc_db_loading":
        return _fc_db_loading(df, adj, assump_tables, ctx)

    raise ValueError(f"Unknown post_rate_adjust: {kind}")


# ============================================================
# 8c. FC (Family Cover) column-enrichment primitives
# ============================================================
# Attach the FC-specific demographic / composition / loading columns onto
# the member DF. All are join-based or scalar multipliers — no premium math
# here. The composite premium (_apply_fc_composite) calls these inline.
# ============================================================

def _fc_demographics_join(df: pl.DataFrame, basis_tables: dict | None) -> pl.DataFrame:
    """FC row-4 cols AB, AC, AD.

    Joins fc_demographics on age_nb → attaches:
        pct_married          (AB)
        n_children_0_13      (AC)
        n_children_14_plus   (AD)
    """
    if basis_tables is None or "fc_demographics" not in basis_tables:
        return df.with_columns([
            pl.lit(0.0).alias("pct_married"),
            pl.lit(0.0).alias("n_children_0_13"),
            pl.lit(0.0).alias("n_children_14_plus"),
        ])

    demo = basis_tables["fc_demographics"].select([
        "age",
        pl.col("pct_married").cast(pl.Float64, strict=False),
        pl.col("n_children_0_13").cast(pl.Float64, strict=False),
        pl.col("n_children_14_plus").cast(pl.Float64, strict=False),
    ]).with_columns(pl.col("age").cast(pl.Int64))

    df = df.with_columns(pl.col("age_nb").cast(pl.Int64))
    df = df.join(demo, left_on="age_nb", right_on="age", how="left")
    return df.with_columns([
        pl.col("pct_married").fill_null(0.0),
        pl.col("n_children_0_13").fill_null(0.0),
        pl.col("n_children_14_plus").fill_null(0.0),
    ])


def _fc_family_composition_join(df: pl.DataFrame,
                                 basis_tables: dict | None,
                                 ctx) -> pl.DataFrame:
    """FC row-4 cols AE, AF — step-lookup + per-cat gate."""
    if basis_tables is None or "fc_family_composition" not in basis_tables:
        return df.with_columns([
            pl.lit(0.0).alias("n_parents"),
            pl.lit(0.0).alias("n_in_laws"),
        ])

    fam = basis_tables["fc_family_composition"].select([
        pl.col("age_from").cast(pl.Float64, strict=False).alias("__fam_from"),
        pl.col("n_parents").cast(pl.Float64, strict=False),
        pl.col("n_in_laws").cast(pl.Float64, strict=False),
    ]).drop_nulls("__fam_from").sort("__fam_from")

    df = df.with_columns(pl.col("age_nb").cast(pl.Float64, strict=False))
    df = df.sort("age_nb").join_asof(
        fam, left_on="age_nb", right_on="__fam_from", strategy="backward"
    )
    df = df.with_columns([
        pl.col("n_parents").fill_null(0.0),
        pl.col("n_in_laws").fill_null(0.0),
    ]).drop("__fam_from")

    parents_map = getattr(ctx.scheme, "fc_parents_included", {}) or {} if ctx else {}
    in_laws_map = getattr(ctx.scheme, "fc_parents_in_law_included", {}) or {} if ctx else {}

    parents_yes_cats = [int(c) for c, v in parents_map.items()
                        if isinstance(v, str) and v.strip().lower() == "yes"]
    in_laws_yes_cats = [int(c) for c, v in in_laws_map.items()
                        if isinstance(v, str) and v.strip().lower() == "yes"]

    df = df.with_columns([
        pl.when(pl.col("category_number").cast(pl.Int64).is_in(parents_yes_cats))
          .then(pl.col("n_parents"))
          .otherwise(0.0)
          .alias("n_parents"),
        pl.when(pl.col("category_number").cast(pl.Int64).is_in(in_laws_yes_cats))
          .then(pl.col("n_in_laws"))
          .otherwise(0.0)
          .alias("n_in_laws"),
    ])
    return df


def _fc_second_spouse_loading(df: pl.DataFrame,
                               assump_tables: dict | None,
                               ctx) -> pl.DataFrame:
    """FC row-4 col AZ.

        AZ = IF(max_spouses = 1, 1, 1 + second_spouse_loading × (max_spouses - 1))
    """
    loading_scalar = 0.0
    if assump_tables is not None and "product_limits" in assump_tables:
        pl_tbl = assump_tables["product_limits"].filter(
            (pl.col("product") == "fc") &
            (pl.col("param_name") == "second_spouse_loading")
        )
        if pl_tbl.height:
            raw = pl_tbl["param_value"][0]
            try:
                loading_scalar = float(raw)
            except (TypeError, ValueError):
                loading_scalar = 0.0

    max_spouses_map = (
        getattr(ctx.scheme, "fc_max_no_of_spouses", {}) or {} if ctx else {}
    )
    if max_spouses_map:
        ms_df = pl.DataFrame(
            [{"category_number": int(c), "__max_spouses": float(v)}
             for c, v in max_spouses_map.items()],
            schema={"category_number": pl.Int64, "__max_spouses": pl.Float64},
        )
        df = df.with_columns(pl.col("category_number").cast(pl.Int64))
        df = df.join(ms_df, on="category_number", how="left")
    else:
        df = df.with_columns(pl.lit(1.0).alias("__max_spouses"))

    df = df.with_columns(
        pl.col("__max_spouses").fill_null(1.0).alias("__max_spouses")
    )
    df = df.with_columns(
        pl.when(pl.col("__max_spouses") <= 1)
          .then(pl.lit(1.0))
          .otherwise(1.0 + pl.lit(loading_scalar) * (pl.col("__max_spouses") - 1.0))
          .alias("second_spouse_loading")
    ).drop("__max_spouses")
    return df


def _fc_db_loading(df: pl.DataFrame, adj: dict,
                    assump_tables: dict | None, ctx) -> pl.DataFrame:
    """FC row-4 col BA — Disability Benefits Loading.

    Attaches column 'db_loading' (default 1.0). The composite premium hook
    multiplies basic_technical_premium by db_loading after BB..BF are computed.

    Gated by a scheme-level global (active_selection_db_load = 1). If the
    global is missing or falsy, BA collapses to 1.0 for every row.
    """
    gate_global = adj.get("gate_global", "active_selection_db_load")
    gate_on = False
    if ctx is not None:
        gate_raw = (ctx.globals or {}).get(gate_global)
        if isinstance(gate_raw, bool):
            gate_on = gate_raw
        else:
            try:
                gate_on = float(gate_raw) == 1.0
            except (TypeError, ValueError):
                gate_on = False

    if not gate_on or assump_tables is None or "fc_db_loading" not in assump_tables:
        return df.with_columns(pl.lit(1.0).alias("db_loading"))

    tbl = assump_tables["fc_db_loading"].select([
        pl.col("years_disabled").cast(pl.Int64),
        pl.col("loading_factor").cast(pl.Float64, strict=False),
    ]).sort("years_disabled")

    if "date_of_disability" not in df.columns or ctx is None:
        return df.with_columns(pl.lit(1.0).alias("db_loading"))

    comm_date = ctx.calc_date
    df = df.with_columns([
        pl.when(pl.col("date_of_disability").is_not_null())
          .then(
              ((pl.lit(comm_date) - pl.col("date_of_disability"))
                 .dt.total_days() / 365.25).floor().cast(pl.Int64) + 1
          )
          .otherwise(pl.lit(None, dtype=pl.Int64))
          .alias("__years_disabled")
    ])
    df = df.with_columns(
        pl.min_horizontal([pl.col("__years_disabled"), pl.lit(5)])
          .alias("__years_disabled_capped")
    )

    df = df.join(
        tbl.rename({"years_disabled": "__years_disabled_capped",
                    "loading_factor": "__db_loading_raw"}),
        on="__years_disabled_capped", how="left",
    )
    df = df.with_columns(
        pl.when(pl.col("status").cast(pl.Utf8) == "DB")
          .then(pl.col("__db_loading_raw").fill_null(1.0))
          .otherwise(1.0)
          .alias("db_loading")
    ).drop(["__years_disabled", "__years_disabled_capped", "__db_loading_raw"])
    return df


def _lookup_spouse_factor(df, key: str) -> float:
    """Look up a spouse factor by key ('m' / 'f') from spouse_factors DF."""
    row = df.filter(pl.col("key").cast(pl.Utf8).str.to_lowercase() == key.lower())
    if row.height:
        return float(row["value"][0])
    return 0.0


# ============================================================
# 9. QX + PROFIT MARGIN
# ============================================================
def compute_qx(df: pl.DataFrame) -> pl.DataFrame:
    return df.with_columns(
        pl.when(pl.col("total_cover") > 0)
          .then((pl.col("basic_technical_premium") + pl.col("aids_technical_premium"))
                / pl.col("total_cover"))
          .otherwise(0.0).alias("qx")
    )


def apply_profit_margin(df, recipe, assump_tables):
    """Apply profit margin per member.

    Supports two dispatch modes:
      1. Static key: recipe["profit_margin_key"] = ("lsdb", "standard")
      2. Per-member by cover_type: recipe["profit_margin_key_by_cover_type"] = {...}
    """
    
    basis_mode = recipe.get("profit_margin_basis", "net_risk")

    if basis_mode == "total_annual":
        base_col = "total_annual_premium"
    else:
        base_col = None

    mapping = recipe.get("profit_margin_key_by_cover_type")
    if mapping:
        if "cover_type" not in df.columns:
            raise KeyError(
                "[apply_profit_margin] recipe uses profit_margin_key_by_cover_type "
                "but df has no 'cover_type' column (attach_category must run first)"
            )

        default_key = mapping.get("_default")
        margin_by_type: dict[str, float] = {}
        for ct, key in mapping.items():
            if ct == "_default":
                continue
            prod, mtype = key
            margin_by_type[ct] = _lookup_margin(assump_tables, prod, mtype)

        default_margin = 0.0
        if default_key is not None:
            prod, mtype = default_key
            default_margin = _lookup_margin(assump_tables, prod, mtype)

        df = df.with_columns(
            pl.col("cover_type")
              .cast(pl.Utf8)
              .replace_strict(margin_by_type, default=default_margin,
                              return_dtype=pl.Float64)
              .alias("__margin_rate")
        )
    else:
        prod, mtype = recipe["profit_margin_key"]
        rate = _lookup_margin(assump_tables, prod, mtype)
        df = df.with_columns(pl.lit(rate).alias("__margin_rate"))

    if base_col == "total_annual_premium":
        df = df.with_columns(
            (pl.col("total_annual_premium") * pl.col("__margin_rate"))
            .alias("profit_margin_amount")
        )
    else:
        df = df.with_columns(
            ((pl.col("basic_technical_premium") + pl.col("aids_technical_premium"))
             * pl.col("__margin_rate"))
            .alias("profit_margin_amount")
        )

   
    if basis_mode == "total_annual":
        base = pl.col("total_annual_premium")
    elif basis_mode == "annuity_pv":
        # Profit base = net risk INCLUDING the HCC waiver stream (GIP composite: DB).
        # TT GIP base 429,004.40 = basic+aids (420,398.60) + waiver_premium (8,605.80).
        # TIP waiver_premium = 0.00, so this is a no-op for TIP (verified).
        base = (
            pl.col("basic_technical_premium")
            + pl.col("aids_technical_premium")
            + pl.col("waiver_premium").fill_null(0.0)
        )
    else:  # net_risk
        base = pl.col("basic_technical_premium") + pl.col("aids_technical_premium")
 
    df = df.with_columns((base * pl.col("__margin_rate")).alias("profit_margin_amount"))
    return df.drop("__margin_rate")

def _lookup_margin(assump_tables, product: str, margin_type: str) -> float:
    """Look up margin rate in profit_margins table. Returns 0.0 if missing."""
    tbl = assump_tables.get("profit_margins")
    if tbl is None:
        return 0.0
    row = tbl.filter(
        (pl.col("product") == product) & (pl.col("margin_type") == margin_type)
    )
    if row.height == 0:
        return 0.0
    raw = row["margin"][0]
    try:
        return float(raw)
    except (TypeError, ValueError):
        return 0.0


# ============================================================
# 9b. PRB / Profit Refund Premium
# ============================================================
def apply_prb_premium(df: pl.DataFrame, ctx, product_key: str) -> pl.DataFrame:
    """PRB / PRO premium — Standard Margins row 41.

        prb_premium = pro_loading × (total_annual_premium − co_premium)
                    = pro_loading × (basic + aids + ctc + waiver)
    """
    scheme = getattr(ctx, "scheme", None)
    if scheme is None:
        return df.with_columns(pl.lit(0.0).alias("prb_premium"))

    prb_by_product = getattr(scheme, "profit_refund_loading_by_product", {}) or {}

    try:
        pro_loading = float(prb_by_product.get(product_key, 0.0) or 0.0)
    except (TypeError, ValueError):
        pro_loading = 0.0

    if pro_loading == 0.0:
        return df.with_columns(pl.lit(0.0).alias("prb_premium"))

    co = pl.col("co_premium").fill_null(0.0) if "co_premium" in df.columns else pl.lit(0.0)
    tot = pl.col("total_annual_premium").fill_null(0.0) if "total_annual_premium" in df.columns else pl.lit(0.0)

    prb_base = tot - co

    return df.with_columns(
        pl.when(
            pl.col("product_active")
            & (pl.col("age") <= pl.col("ceasing_age"))
        )
        .then(prb_base * pl.lit(pro_loading))
        .otherwise(0.0)
        .alias("prb_premium")
    )


# ============================================================================
# EDUCATION GUARDIAN COMPOSITE
# ============================================================================
# Confirmed 2026-08-18 via live TT "Education" sheet formula trace (see chat
# record for full derivation). Rate chain (rate_basic) is ALREADY populated
# by price()'s standard STEP 5 rate_factors loop (GLA's 6-factor chain) by
# the time this hook runs -- we do NOT recompute it here (unlike FC, which
# resolves its own rate chain inline because FC has no rate_factors list).
#
# Cover (AG) = LET(Sal_Ind=MATCH(salary, salary_bands, 1),
#                   Age_Ind=MATCH(age - male_offset, cover_grid.age, 1),
#                   INDEX(cover_grid, Age_Ind, Sal_Ind))
# Premium (AM/AN) = rate_basic/1000 * total_cover  (+ AIDS leg, same shape)
# Total Member Cover (AJ) zeroing: status='P' or age>ceasing_age -> 0;
# deferred != 'Yes' -> 0 (mirrors AJ4's outer IF layers).
# ============================================================================

def _edu_guardian_salary_tier(salary: float, bands: list[tuple[float, int]]) -> int:
    "Floor-match (VLOOKUP TRUE semantics): last band where salary_from <= salary."
    tier = bands[0][1]
    for salary_from, t in bands:
        if salary_from <= salary:
            tier = t
        else:
            break
    return tier


def _apply_education_guardian_composite(df: pl.DataFrame,
                                         spec: dict,
                                         basis_tables: dict[str, pl.DataFrame],
                                         assump_tables: dict | None,
                                         ctx) -> pl.DataFrame:
    """Education Guardian composite cover + premium. rate_basic/rate_aids are
    already populated by the standard GLA-chain rate_factors loop in price()
    before this hook runs -- we only compute cover and derive premium from it."""

    # --- Male age-offset scalar (product_limits, Piece 3b) ---
    male_offset = 0.0
    if assump_tables is not None and "product_limits" in assump_tables:
        row = assump_tables["product_limits"].filter(
            (pl.col("product") == "education_guardian") &
            (pl.col("param_name") == "male_age_offset")
        )
        if row.height:
            try:
                male_offset = float(row["param_value"][0])
            except (TypeError, ValueError):
                male_offset = 0.0

    # --- Salary-band tiers (education_guardian_salary_bands, Piece 3a) ---
    sal_bands_df = basis_tables.get("education_guardian_salary_bands") if basis_tables else None
    if sal_bands_df is None or sal_bands_df.height == 0:
        # No table -- cover is 0 for everyone (fail-safe, not silent wrong numbers)
        return df.with_columns([
            pl.lit(0.0).alias("total_cover"),
            pl.lit(0.0).alias("basic_technical_premium"),
            pl.lit(0.0).alias("aids_technical_premium"),
        ])
    bands_sorted = sorted(
        zip(sal_bands_df["salary_from"].to_list(), sal_bands_df["sal_tier"].to_list())
    )
    sal_col_map = {1: "sal_1", 2: "sal_2", 3: "sal_3", 4: "sal_4", 5: "sal_5"}

    # --- Age x salary-band cover grid (education_guardian_cover, Piece 3a) ---
    cover_df = basis_tables.get("education_guardian_cover") if basis_tables else None
    if cover_df is None or cover_df.height == 0:
        return df.with_columns([
            pl.lit(0.0).alias("total_cover"),
            pl.lit(0.0).alias("basic_technical_premium"),
            pl.lit(0.0).alias("aids_technical_premium"),
        ])
    # age -> {sal_tier: cover_value} dict, for O(1) per-member lookup
    cover_by_age: dict[int, dict[int, float]] = {}
    for row in cover_df.iter_rows(named=True):
        age_key = int(row["age"])
        cover_by_age[age_key] = {
            tier: float(row[col]) for tier, col in sal_col_map.items() if col in row
        }
    grid_ages_sorted = sorted(cover_by_age.keys())
    min_age, max_age = grid_ages_sorted[0], grid_ages_sorted[-1]

    def _asof_age(target_age: int) -> int | None:
        "Floor-match (VLOOKUP/MATCH TRUE semantics) against the grid's ages."
        if target_age < min_age:
            return None
        hit = min_age
        for a in grid_ages_sorted:
            if a <= target_age:
                hit = a
            else:
                break
        return hit

    # --- Per-member cover computation (Python dict lookups, same pattern
    #     as FC/GIP/TIP's per-member composite logic) ---
    genders = df["gender"].to_list()
    # Confirmed 2026-08-18: TT's Guardian cover lookup (Education!col AG,
    # LET Age_Ind=MATCH($H-offset,...)) uses column H = decimal "Age", NOT
    # "Age Next Birthday" (age_nb). This is intentionally different from
    # the GLA rate-chain factors (mortality etc.) applied earlier in
    # price(), which correctly use age_nb per GLA's own recipe -- the two
    # age conventions are NOT interchangeable and must not be unified.
    ages_raw = df["age"].to_list()
    salaries = df["annual_salary"].to_list()

    covers = []
    for gender, age_val, salary in zip(genders, ages_raw, salaries):
        if age_val is None or salary is None:
            covers.append(0.0)
            continue
        offset = male_offset if str(gender).strip().upper() == "M" else 0.0
        lookup_age = int(age_val - offset)
        matched_age = _asof_age(lookup_age)
        if matched_age is None:
            covers.append(0.0)
            continue
        tier = _edu_guardian_salary_tier(float(salary), bands_sorted)
        cover_val = cover_by_age.get(matched_age, {}).get(tier, 0.0)
        covers.append(cover_val)

    df = df.with_columns(pl.Series("__edu_guardian_ag_cover", covers))

    # --- AJ (Total Member Cover) zeroing logic ---
    # TT formula: AJ4 = IF(OR(J4="P", AL4=TRUE), 0, IF(L4="Yes",
    #   IF(AE4=CoverTypeMatch, AG4, AH4), 0))
    # VERIFIED 2026-08-19 via direct Excel column-letter trace on the live
    # "Education" sheet: L="Product Active" (matches our product_active
    # check exactly); AL4 (Above Ceasing Age) = IF(Deferred="Yes",
    # age>Ceasing_age_col_P, age>NRA) -- this is EXACTLY what
    # compute_ceasing_age's "deferred_or_nra" mode already resolves
    # upstream (ceasing_age = deferred_retirement_age if deferred=="Yes"
    # else nra_final), so our age>ceasing_age check below is mathematically
    # equivalent to checking AL4=TRUE directly. Confirmed correct via the
    # 57-member validation, which included deferred-retirement edge cases
    # (12 members) and matched TT rand-perfect. No approximation -- this
    # gating is proven exact, not conservative.
    df = df.with_columns(
        pl.when(~pl.col("product_active")).then(0.0)
          .when(pl.col("status") == "P").then(0.0)
          .when(pl.col("age") > pl.col("ceasing_age")).then(0.0)
          .otherwise(pl.col("__edu_guardian_ag_cover"))
          .alias("total_cover")
    )

    # --- Premium: rate_basic/rate_aids already populated by price()'s
    #     standard rate_factors loop (GLA's 6-factor chain) ---
    df = df.with_columns([
        (pl.col("rate_basic").fill_null(0.0) / 1000.0 * pl.col("total_cover"))
            .alias("basic_technical_premium"),
        (pl.col("rate_aids").fill_null(0.0) / 1000.0 * pl.col("total_cover"))
            .alias("aids_technical_premium"),
    ])

    return df.drop(["__edu_guardian_ag_cover"])


# ============================================================================
# EDUCATE A CHILD COMPOSITE
# ============================================================================
# Confirmed 2026-08-19 via live TT "Education" sheet formula trace on a
# genuine Educate-a-Child-active test CTR (see chat record). Rate chain
# (rate_basic/rate_aids) is ALREADY populated by price()'s standard STEP 5
# rate_factors loop (GLA's 6-factor chain) by the time this hook runs --
# same as education_guardian, we do NOT recompute it here.
#
# Cover (AH) = MIN(Multiple x Annual Salary, Category Max Cover)
# Premium (AM/AN) = rate_basic/1000 * total_cover  (+ AIDS leg)
# Total Member Cover (AJ) zeroing: status='P' or age>ceasing_age -> 0;
# same gating as education_guardian (handled generically via the
# education_deferred/education_nra attachment already wired into
# engine.py's price() -- see Piece 4c-i notes).
# ============================================================================
def _apply_educate_a_child_composite(df: pl.DataFrame,
                                      spec: dict,
                                      basis_tables: dict[str, pl.DataFrame],
                                      assump_tables: dict | None,
                                      ctx) -> pl.DataFrame:
    "Educate a Child composite cover + premium. rate_basic/rate_aids are "
    "already populated by the standard GLA-chain rate_factors loop in "
    "price() before this hook runs -- we only compute cover and derive "
    "premium from it."
    scheme = ctx.scheme if ctx is not None else None
    edu_multiple = getattr(scheme, "education_multiple", {}) or {}
    edu_max_cover = getattr(scheme, "education_max_cover", {}) or {}

    if "category_number" not in df.columns:
        return df.with_columns([
            pl.lit(0.0).alias("total_cover"),
            pl.lit(0.0).alias("basic_technical_premium"),
            pl.lit(0.0).alias("aids_technical_premium"),
        ])

    cat_numbers = df["category_number"].to_list()
    salaries = df["annual_salary"].to_list()

    covers = []
    for cat, salary in zip(cat_numbers, salaries):
        if cat is None or salary is None:
            covers.append(0.0)
            continue
        multiple = float(edu_multiple.get(int(cat), 0.0) or 0.0)
        raw_cover = multiple * float(salary)
        cap = edu_max_cover.get(int(cat))
        if cap is not None:
            raw_cover = min(raw_cover, float(cap))
        covers.append(raw_cover)

    df = df.with_columns(pl.Series("__eac_ah_cover", covers))

    # AJ (Total Member Cover) zeroing -- same convention as
    # education_guardian: status='P' or above ceasing_age -> 0.
    df = df.with_columns(
        pl.when(~pl.col("product_active")).then(0.0)
          .when(pl.col("status") == "P").then(0.0)
          .when(pl.col("age") > pl.col("ceasing_age")).then(0.0)
          .otherwise(pl.col("__eac_ah_cover"))
          .alias("total_cover")
    )

    df = df.with_columns([
        (pl.col("rate_basic").fill_null(0.0) / 1000.0 * pl.col("total_cover"))
            .alias("basic_technical_premium"),
        (pl.col("rate_aids").fill_null(0.0) / 1000.0 * pl.col("total_cover"))
            .alias("aids_technical_premium"),
    ])

    return df.drop(["__eac_ah_cover"])
