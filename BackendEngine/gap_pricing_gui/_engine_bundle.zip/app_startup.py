r"""
app_startup.py -- one-call launch sequence for the GAP Pricing Engine.

Author: Mohamed Hussein Gadiwala
Date  : 2026-07-29 (Johannesburg)

Collapses the whole launch into a single idempotent call so quotes 2..N reuse
in-memory DataFrames (no re-read, no re-unzip):

    1. neutralise stale Downloads\*.py shadow copies  (import-shadowing landmine, HANDOVER 6)
    2. ensure_on_path()                                (ctr_loader to front; J: first, UNC fallback)
    3. refresh_bundles (only-if-stale)                 (~14ms/snapshot unless a snapshot changed -- Delta A)
    4. warm get_basis / get_assumptions ONCE           (1 read + unzip in RAM, then memoised)
    5. per quote -> get_basis(ctx.basis_dir) is 0.00s  (served from the lru_cache)

Design notes
------------
* Non-destructive: Downloads shadows are RENAMED to *.py.OLD_ignore, never deleted.
* If a bundle was rebuilt this launch, the matching get_* lru_cache is cleared
  BEFORE warming, so a mid-session snapshot swap can never serve stale RAM.
* Each loader stays self-sufficient; this module only orchestrates.

Usage (notebook / engine entry point)
-------------------------------------
    from app_startup import startup
    ctx = startup()                 # first call: ~2s cold, then cached
    basis        = ctx.basis        # BasisBundle
    assumptions  = ctx.assumptions  # AssumptionsBundle

    # per quote afterwards (instant, same process):
    from basis_loader import get_basis
    tables = get_basis(ctx.basis_dir).tables
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# --- bootstrap: this folder (ctr_loader) onto sys.path so engine_paths imports.
#     After that, engine_paths.ensure_on_path() is the authoritative fixer. -----
try:
    _HERE = Path(__file__).resolve().parent
except NameError:  # pragma: no cover - only when pasted into a raw cell
    _HERE = Path.cwd()
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from engine_paths import ensure_on_path, snapshot_dir  # noqa: E402
import refresh_bundles       # noqa: E402
import basis_loader          # noqa: E402
import assumption_loader     # noqa: E402


# Engine .py modules that must NEVER be shadowed from ~/Downloads.
# (HANDOVER 6 list + engine_paths.py, which now also lives in ctr_loader.)
_DOWNLOAD_SHADOWS = [
    "basis_loader.py",
    "assumption_loader.py",
    "products_registry.py",
    "basis_loader_new.py",
    "assumption_loader_new.py",
    "engine_paths.py",
]


@dataclass(frozen=True)
class StartupContext:
    """Everything a caller needs after launch. Hold onto this for the session."""
    basis_dir: str
    assumption_dir: str
    basis: "basis_loader.BasisBundle"
    assumptions: "assumption_loader.AssumptionsBundle"
    rebuilt: dict


def neutralise_downloads(dry_run: bool = False) -> list[str]:
    """Rename any engine .py shadowing us from ~/Downloads to *.py.OLD_ignore.

    Authoritative logic from HANDOVER 6 (non-destructive rename, not delete).
    dry_run=True lists what WOULD be neutralised without touching anything.
    Returns the list of shadow paths found.
    """
    found: list[str] = []
    dl = Path.home() / "Downloads"
    for name in _DOWNLOAD_SHADOWS:
        p = dl / name
        if not p.exists():
            continue
        found.append(str(p))
        if dry_run:
            print(f"[downloads] would neutralise {p}")
        else:
            target = p.with_suffix(".py.OLD_ignore")
            p.rename(target)
            print(f"[downloads] neutralised {p.name} -> {target.name}")
    if not found:
        print("[downloads] clean -- no engine shadows found")
    return found


def startup(
    basis_name: Optional[str] = None,
    assumption_name: Optional[str] = None,
    clean_downloads: bool = True,
    max_workers: int = 32,
) -> StartupContext:
    """Idempotent launch. Cheap to call again in the same process.

    basis_name / assumption_name : pin a specific snapshot; None -> newest.
    clean_downloads              : neutralise Downloads shadows first (default True).
    max_workers                  : threaded-fallback width if a bundle is stale.
    """
    # 1. kill the Downloads import-shadowing landmine (non-destructive).
    if clean_downloads:
        neutralise_downloads(dry_run=False)

    # 2. authoritative path fix: ctr_loader to front (J: first, UNC fallback).
    ensure_on_path()

    # 3. resolve snapshots (newest unless pinned), refresh bundles only if stale.
    basis_dir = snapshot_dir("basis", name=basis_name)
    assumption_dir = snapshot_dir("assumption", name=assumption_name)
    summary = refresh_bundles.refresh_all(
        basis_folder=basis_dir,
        assumption_folder=assumption_dir,
    )

    # 3b. if we just rebuilt a bundle, drop any stale in-RAM cache for that dir
    #     BEFORE warming -- never serve a superseded snapshot from memory.
    if summary.get("basis_rebuilt"):
        basis_loader.get_basis.cache_clear()
    if summary.get("assumption_rebuilt"):
        assumption_loader.get_assumptions.cache_clear()

    # 4. warm the session cache ONCE (1 read + unzip in RAM, then memoised).
    basis = basis_loader.get_basis(str(basis_dir), max_workers=max_workers)
    assumptions = assumption_loader.get_assumptions(str(assumption_dir), max_workers=max_workers)

    print(
        f"[startup] ready | basis={Path(basis_dir).name} "
        f"({len(basis.tables)} tables) | "
        f"assumption={Path(assumption_dir).name} ({len(assumptions.tables)} tables)"
    )

    return StartupContext(
        basis_dir=str(basis_dir),
        assumption_dir=str(assumption_dir),
        basis=basis,
        assumptions=assumptions,
        rebuilt={
            "basis": bool(summary.get("basis_rebuilt")),
            "assumption": bool(summary.get("assumption_rebuilt")),
        },
    )


if __name__ == "__main__":
    startup()
