r"""Single source of truth for GAP Pricing Engine paths.

Author: Mohamed Hussein Gadiwala
Date: 2026-07-29

WHY THIS EXISTS
    Every module that needs the engine root, a snapshot folder, or a loader
    should import it FROM HERE -- never hardcode a path, never rely on cwd /
    Downloads / sys.path accidents (which caused a stale-loader shadowing bug).

RESOLUTION ORDER (centralised on the J: share)
    1. J:\...  -> preferred when the J: drive is mapped (normal engine runtime)
    2. \\omsmds000\eb3\...  -> UNC fallback when J: is NOT mounted (e.g. Jupyter
       kernels, service accounts). Same physical location, different mount.
    An explicit env var GAP_ENGINE_ROOT overrides both if ever needed.

USAGE
    from engine_paths import ENGINE_ROOT, snapshot_dir, ensure_on_path
    ensure_on_path()                       # puts ctr_loader on sys.path, once
    basis = snapshot_dir("basis")          # newest basis snapshot folder
    assumption = snapshot_dir("assumption")
"""
from __future__ import annotations
import os
import sys
from pathlib import Path

# Relative tail is identical under both mounts; only the prefix differs.
_TAIL = Path(
    "Group_Assurance/Product & Client Solutions/Toolbox/Calculators"
    "/Business Tools/Tender Summary/GAP Pricing Engine"
)
_J_ROOT   = Path("J:/") / _TAIL
_UNC_ROOT = Path(r"\\omsmds000\eb3") / _TAIL


def _resolve_root() -> Path:
    """J: first (centralised runtime), UNC fallback, env-var override."""
    override = os.environ.get("GAP_ENGINE_ROOT")
    if override:
        p = Path(override)
        if p.exists():
            return p
    if _J_ROOT.exists():
        return _J_ROOT
    if _UNC_ROOT.exists():
        return _UNC_ROOT
    # Neither resolves: still return J: root so errors point at the canonical
    # centralised location rather than some local accident.
    return _J_ROOT


ENGINE_ROOT: Path = _resolve_root()
CTR_LOADER:  Path = ENGINE_ROOT / "ctr_loader"

# Map a family label -> its snapshots parent + filename prefix convention.
_SNAPSHOT_FAMILIES = {
    "basis":      ("basis_snapshots",      "basis_"),
    "assumption": ("assumption_snapshots", "assumption_"),
}


def snapshot_dir(family: str, name: str | None = None) -> Path:
    """Return a snapshot folder ON THE CENTRAL SHARE.

    family: 'basis' or 'assumption'.
    name:   specific snapshot folder name (e.g. 'basis_v2026_08'); if None,
            returns the NEWEST subfolder that actually contains .parquet files.
    """
    if family not in _SNAPSHOT_FAMILIES:
        raise KeyError(f"unknown snapshot family {family!r}; "
                       f"expected one of {list(_SNAPSHOT_FAMILIES)}")
    parent_name, _prefix = _SNAPSHOT_FAMILIES[family]
    parent = ENGINE_ROOT / parent_name
    if name is not None:
        return parent / name
    if not parent.exists():
        raise FileNotFoundError(f"snapshot parent missing: {parent}")
    subs = [d for d in parent.iterdir() if d.is_dir() and any(d.glob("*.parquet"))]
    if not subs:
        raise FileNotFoundError(f"no snapshot folders with .parquet under {parent}")
    return max(subs, key=lambda d: d.stat().st_mtime)


def ensure_on_path() -> None:
    """Put ctr_loader FIRST on sys.path so engine module imports always resolve
    to the central share -- never a stale Downloads / cwd copy. Idempotent."""
    p = str(CTR_LOADER)
    # Remove any prior occurrence, then insert at front so it wins over cwd.
    while p in sys.path:
        sys.path.remove(p)
    sys.path.insert(0, p)


if __name__ == "__main__":
    print(f"GAP_ENGINE_ROOT override : {os.environ.get('GAP_ENGINE_ROOT', '(unset)')}")
    print(f"J: root exists           : {_J_ROOT.exists()}")
    print(f"UNC root exists          : {_UNC_ROOT.exists()}")
    print(f"RESOLVED ENGINE_ROOT     : {ENGINE_ROOT}")
    print(f"CTR_LOADER               : {CTR_LOADER}  (exists={CTR_LOADER.exists()})")
    for fam in _SNAPSHOT_FAMILIES:
        try:
            d = snapshot_dir(fam)
            n = len(list(d.glob('*.parquet')))
            print(f"newest {fam:11s}      : {d}  (parquet={n})")
        except Exception as e:
            print(f"newest {fam:11s}      : {type(e).__name__}: {e}")
