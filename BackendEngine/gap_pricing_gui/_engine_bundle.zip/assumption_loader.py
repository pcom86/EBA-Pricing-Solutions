"""Assumption loader — auto-discovers all .parquet files in a snapshot folder.

Author: Mohamed Hussein Gadiwala
Change (2026-07-29): Model B fast-load (+ Sol 5.6 deltas).
    Root cause of slow loads was per-file network open latency on the J:/UNC
    share (~0.48s fixed tax per open; diagnostic showed local reads 64-94x
    faster, threading 5x faster, single-open zip ~17x faster).

    Load strategy (all artifacts stay on J:, loose parquet remains source of truth):
      1. If a fresh `_snapshot_bundle.zip` exists -> ONE network open, unzip in
         RAM. (~0.16s for the 14-file assumption snapshot.)
      2. Otherwise -> threaded parallel reads of the loose parquets (fallback,
         still ~0.5s), so a missing/stale bundle NEVER blocks or serves stale data.

    Freshness guard: the bundle embeds `_bundle_meta.json` = {name: [size, mtime_ns]}.
    On load we stat() the live folder (~4ms) and compare name-set + size + mtime.
    ANY mismatch => bundle is treated as stale => threaded fallback. A stale zip
    is never silently trusted.

    Deltas from Sol 5.6 review:
      * reads use rechunk=False (skip re-chunk pass on tiny tables).
      * OPT-IN process-level memory cache via get_assumptions() (see bottom). NOT
        applied to load_assumptions() itself, because caching there would bypass the
        freshness guard on repeat calls and could silently serve a stale bundle. Use
        get_assumptions() only where the snapshot is pinned for the process lifetime.

    Re-zip after any snapshot rebuild with `rezip_snapshot(folder)`.
    Only the read path changed; for_product() logic is untouched.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache, partial
from typing import Any
import io
import json
import zipfile
from types import MappingProxyType
import polars as pl
from products_registry import PRODUCT_REGISTRY

BUNDLE_NAME = "_snapshot_bundle.zip"
_META_NAME = "_bundle_meta.json"

# read_parquet with rechunk disabled (tiny tables -> skip the re-chunk pass)
_read_parquet = partial(pl.read_parquet, rechunk=False)


@dataclass(frozen=True)
class AssumptionsBundle:
    built_at: str
    source_sha256: str
    tables: dict[str, pl.DataFrame]
    globals: dict[str, Any]

    def for_product(self, product_key: str) -> dict[str, pl.DataFrame]:
        spec = PRODUCT_REGISTRY[product_key]
        out: dict[str, pl.DataFrame] = {}

        def _filter(sheet: str, alias: tuple[str, ...]) -> pl.DataFrame | None:
            if not alias or sheet not in self.tables:
                return None
            df = self.tables[sheet]
            if "product" not in df.columns:
                return None
            sub = df.filter(pl.col("product").is_in(list(alias)))
            return sub if sub.height > 0 else None

        for sheet, alias in [
            ("product_limits",    spec.assumption_limits),
            ("profit_margins",    spec.assumption_margins),
            ("conversion_option", spec.assumption_co),
        ]:
            sub = _filter(sheet, alias)
            if sub is not None:
                out[sheet] = sub

        for flag, sheet in [
            (spec.uses_lsdb_features,    "lsdb_features"),
            (spec.uses_spouse_factors,   "spouse_factors"),
            (spec.uses_ci_table_mapping, "ci_table_mapping"),
            (spec.uses_ci_reinstatement, "ci_reinstatement"),
            (spec.uses_ctc_options,      "ctc_options"),
            (spec.uses_tax_tables,       "tax_tables"),
            (spec.uses_fc_db_loading,    "fc_db_loading"),
            # --- GIP ---
            (spec.uses_gip_fee_table, "gip_fee_table"),
            (spec.uses_wp_categories, "wp_categories"),
        ]:
            if flag and sheet in self.tables:
                out[sheet] = self.tables[sheet]
        return out


def _coerce_global(param_value, param_type):
    if param_value is None:
        return None
    if param_type == "float":
        try: return float(param_value)
        except (ValueError, TypeError): return None
    if param_type == "int":
        try: return int(float(param_value))
        except (ValueError, TypeError): return None
    if param_type == "bool":
        return str(param_value).strip().lower() in ("true", "1", "yes", "y")
    return str(param_value)


# --------------------------------------------------------------------------- #
# Snapshot fast-load helpers (self-contained; no shared module)               #
# --------------------------------------------------------------------------- #
def _live_stat_map(files: list[Path]) -> dict[str, list[int]]:
    """{filename: [size_bytes, mtime_ns]} for the loose parquets. stat() only."""
    out: dict[str, list[int]] = {}
    for p in files:
        st = p.stat()
        out[p.name] = [st.st_size, st.st_mtime_ns]
    return out


def _bundle_is_fresh(zpath: Path, files: list[Path]) -> bool:
    """True only if the bundle's embedded meta matches the live folder exactly."""
    if not zpath.exists():
        return False
    try:
        with zipfile.ZipFile(zpath) as zf:
            if _META_NAME not in zf.namelist():
                return False
            recorded = json.loads(zf.read(_META_NAME))
    except (zipfile.BadZipFile, json.JSONDecodeError, KeyError):
        return False  # corrupt/partial bundle -> treat as stale
    return recorded == _live_stat_map(files)


def _read_from_bundle(zpath: Path) -> dict[str, pl.DataFrame]:
    """ONE network open: pull the whole zip, unpack parquets from RAM."""
    raw = zpath.read_bytes()
    tables: dict[str, pl.DataFrame] = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        for nm in zf.namelist():
            if nm.endswith(".parquet"):
                tables[Path(nm).stem] = _read_parquet(io.BytesIO(zf.read(nm)))
    return tables


def _read_threaded(files: list[Path], max_workers: int) -> dict[str, pl.DataFrame]:
    """Fallback: parallel reads of loose parquets. Order preserved via zip()."""
    workers = max(1, min(max_workers, len(files)))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        frames = list(ex.map(_read_parquet, files))
    return {p.stem: df for p, df in zip(files, frames)}


def rezip_snapshot(folder: str | Path) -> Path:
    """(Re)build the fast-load bundle for a snapshot folder. Call after any rebuild.

    Writes `_snapshot_bundle.zip` (ZIP_STORED, no compression) containing every
    loose parquet plus `_bundle_meta.json` (size+mtime of each). Atomic: writes
    to a temp name then replaces, so a load can never see a half-written bundle.
    """
    folder = Path(folder)
    files = sorted(folder.glob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No .parquet files to bundle in {folder}")
    meta = _live_stat_map(files)
    zpath = folder / BUNDLE_NAME
    tmp = folder / f"{BUNDLE_NAME}.tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as zf:
        for p in files:
            zf.write(p, p.name)
        zf.writestr(_META_NAME, json.dumps(meta, sort_keys=True))
    tmp.replace(zpath)  # atomic on same filesystem
    return zpath


def _read_meta(folder: Path) -> dict:
    meta = {"built_at": "", "source_sha256": ""}
    mpath = folder / "manifest.json"
    if mpath.exists():
        m = json.loads(mpath.read_text())
        meta["built_at"]      = m.get("built_at", "")
        meta["source_sha256"] = m.get("source_sha256", "")
        return meta
    log = folder / "build_log.csv"
    if log.exists():
        try:
            df = pl.read_csv(log)
            last = df.tail(1)
            for k in ("built_at", "source_sha256"):
                if k in last.columns and last[k][0] is not None:
                    meta[k] = str(last[k][0])
        except Exception:
            pass
    return meta


def load_assumptions(folder: str | Path, max_workers: int = 32,
                     use_bundle: bool = True) -> AssumptionsBundle:
    folder = Path(folder)
    if not folder.exists():
        raise FileNotFoundError(f"Assumption snapshot folder not found: {folder}")

    files = sorted(folder.glob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No .parquet files found in {folder}")

    # Fast path: fresh bundle -> single network open. Else threaded fallback.
    zpath = folder / BUNDLE_NAME
    if use_bundle and _bundle_is_fresh(zpath, files):
        tables = _read_from_bundle(zpath)
    else:
        tables = _read_threaded(files, max_workers)

    globals_dict: dict[str, Any] = {}
    if "globals" in tables:
        g = tables["globals"]
        if {"param_name", "param_value", "param_type"}.issubset(g.columns):
            for row in g.iter_rows(named=True):
                globals_dict[row["param_name"]] = _coerce_global(
                    row["param_value"], row.get("param_type")
                )

    meta = _read_meta(folder)
    return AssumptionsBundle(
        built_at=meta["built_at"],
        source_sha256=meta["source_sha256"],
        tables=tables,
        globals=globals_dict,
    )


# --------------------------------------------------------------------------- #
# OPT-IN process-level singleton (Sol 5.6 "memory cache").                     #
# Use ONLY where the snapshot is pinned for the process lifetime. This caches  #
# the bundle by folder path and does NOT re-check freshness on repeat calls.   #
# Call get_assumptions.cache_clear() after promoting a new snapshot in a       #
# long-lived process. For anything that may see a mid-session snapshot swap,   #
# use load_assumptions() directly (freshness-guarded every call).              #
# --------------------------------------------------------------------------- #
@lru_cache(maxsize=8)
def _get_assumptions_cached(folder: str, max_workers: int, use_bundle: bool) -> AssumptionsBundle:
    a = load_assumptions(folder, max_workers=max_workers, use_bundle=use_bundle)
    # Session cache: read-only view of BOTH tables and globals.
    return replace(a,
                   tables=MappingProxyType(dict(a.tables)),
                   globals=MappingProxyType(dict(a.globals)))


def get_assumptions(folder, max_workers: int = 32, use_bundle: bool = True) -> AssumptionsBundle:
    # Canonicalise args -> one lru_cache key regardless of call form.
    return _get_assumptions_cached(str(folder), int(max_workers), bool(use_bundle))


get_assumptions.cache_clear = _get_assumptions_cached.cache_clear
get_assumptions.cache_info = _get_assumptions_cached.cache_info
