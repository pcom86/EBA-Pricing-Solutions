"""CTR local session cache -- fingerprint-keyed, race-safe, non-destructive.

Diagnosis (2026-07-30): CTR load cost is 100% UNC transfer of the ~12 MB .xls
at a TOTAL-LINK-capped ~0.7 MB/s. Parse is ~1s. Parallel range-reads do NOT
scale. Only wins: serve a local copy on repeat loads + prefetch to overlap the
wait with UI time. NOTHING on the source share is written.

Concurrency (fix 2026-07-30b): prefetch thread and the on-Price load can race
for the same file. Two guards:
  * per-target lock -> the second caller WAITS for the in-flight copy and then
    gets a cache HIT, instead of starting a duplicate transfer.
  * per-caller unique .part.<pid>.<tid> temp -> parallel copies never collide.
prefetch_async wraps its body in try/except: prefetch is best-effort, a failure
never disturbs the app (load_ctr still does a correct normal load).
"""
from __future__ import annotations
import shutil, threading, hashlib, os
from pathlib import Path

DEFAULT_CACHE_DIR = Path(r"C:\Temp\GAP_CTR_Cache")

# per-target locks so prefetch + load never copy the same file twice
_locks_guard = threading.Lock()
_locks: dict = {}


def _lock_for(key: str) -> threading.Lock:
    with _locks_guard:
        lk = _locks.get(key)
        if lk is None:
            lk = threading.Lock()
            _locks[key] = lk
        return lk


def _fingerprint(src: Path) -> str:
    st = src.stat()  # cheap UNC metadata round-trip (~ms), NOT a full read
    key = f"{src.name}|{st.st_mtime_ns}|{st.st_size}"
    return hashlib.sha256(key.encode()).hexdigest()[:16]


def _cache_target(src: Path, cache_dir: Path) -> Path:
    return cache_dir / f"{src.stem}__{_fingerprint(src)}{src.suffix}"


def local_ctr_path(src, cache_dir=None, on_log=None) -> Path:
    """Return a LOCAL path to the CTR, copying it down only on miss/staleness.
    Race-safe: concurrent callers for the same file serialise on a per-target
    lock; the loser gets a HIT rather than a duplicate copy.
    """
    src = Path(src)
    cache_dir = Path(cache_dir) if cache_dir else DEFAULT_CACHE_DIR
    log = on_log or (lambda m: None)

    # local source -> no benefit, use as-is
    if not str(src).startswith("\\\\"):
        return src

    cache_dir.mkdir(parents=True, exist_ok=True)
    target = _cache_target(src, cache_dir)

    # fast path (no lock): already cached
    if target.exists() and target.stat().st_size == src.stat().st_size:
        log(f"[ctr_cache] HIT  {target.name}")
        return target

    with _lock_for(str(target)):
        # re-check inside lock: an in-flight prefetch may have just finished
        if target.exists() and target.stat().st_size == src.stat().st_size:
            log(f"[ctr_cache] HIT (waited on prefetch)  {target.name}")
            return target

        # prune older fingerprints of same stem (avoid disk bloat)
        for old in cache_dir.glob(f"{src.stem}__*{src.suffix}"):
            if old != target:
                try:
                    old.unlink()
                except OSError:
                    pass

        log(f"[ctr_cache] MISS -> copying {src.name} ({src.stat().st_size/1e6:.1f} MB) ...")
        # unique temp per process+thread so parallel copies never share a .part
        tmp = target.with_suffix(target.suffix + f".part.{os.getpid()}.{threading.get_ident()}")
        try:
            shutil.copy2(src, tmp)      # single sequential stream (best on a capped link)
            os.replace(tmp, target)     # atomic publish
        finally:
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass
        log(f"[ctr_cache] cached -> {target}")
        return target


def prefetch_async(src, cache_dir=None, on_log=None) -> threading.Thread:
    """Fire-and-forget warm of the cache (call the moment a CTR is picked).
    Best-effort: any failure is swallowed so the GUI is never disturbed.
    """
    def _run():
        try:
            local_ctr_path(src, cache_dir, on_log)
        except Exception:
            pass  # prefetch is optimization only; load_ctr remains correct
    t = threading.Thread(target=_run, daemon=True, name="ctr_prefetch")
    t.start()
    return t
