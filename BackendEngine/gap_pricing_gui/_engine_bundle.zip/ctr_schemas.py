"""Typed containers for a parsed CTR."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any
import polars as pl


@dataclass(frozen=True)
class SchemeRecord:
    # --- Identity ---
    quote_type: str | None = None
    quote_group: str | None = None
    quote_number: int | None = None
    doer: str | None = None
    checker: str | None = None
    scheme_name: str | None = None
    scheme_codes: dict[str, str | None] = field(default_factory=dict)

    # --- Dates ---
    effective_date: date | None = None
    calculation_date: date | None = None
    commencement_date: date | None = None

    # --- Broker / commercial ---
    intermediary: str | None = None
    broker_name: str | None = None
    client_manager: str | None = None
    branch: str | None = None
    alexander_forbes_scheme: str | None = None
    country_scale: str | None = None

    # --- Commission ---
    pct_comm_applied: float | None = None
    initial_commission: str | None = None
    collection_commission: str | None = None
    collection_fee_pct: float | None = None
    include_vat_commission: str | None = None
    namibian_stamp_duty: str | None = None
    premium_frequency: str | None = None

    # --- Fee structure ---
    fee_structure: str | None = None
    annual_fee_gla: float | None = None
    admin_fee_pct_gla: float | None = None
    annual_fee_gip: float | None = None
    admin_fee_pct_gip: float | None = None
    annual_fee_fc: float | None = None
    admin_fee_pct_fc: float | None = None
    annual_fee_tip: float | None = None
    admin_fee_pct_tip: float | None = None

    # --- Regions ---
    primary: str | None = None
    secondary: str | None = None
    region: str | None = None
    regions: dict[str, float] = field(default_factory=dict)

    # --- Basis-level params ---
    salary_definition: str | None = None
    pear_tgp_pct: float | None = None
    profit_refund_loading_by_product: dict[str, float] = field(default_factory=dict)
    rate_basis_by_product: dict[str, float] = field(default_factory=dict)   # ← NEW
    # --- Priced Margins overrides (user-entered in PySide6 PO viewer) ---
    # priced_margin_overrides[pkey][field_key] = override value (float).
    # Absent key (product or field) -> falls back to Standard/mirrored value,
    # matching TT's own IF(cell="", default, override) behaviour exactly.
    # Field keys per product family are defined in reporting/inputs.py's
    # PRICED_MARGIN_FIELD_SPEC (added alongside this).
    priced_margin_overrides: dict[str, dict[str, float]] = field(default_factory=dict)   # ← NEW

    # --- Per-product product-repeating dicts ---
    rating: dict[str, str] = field(default_factory=dict)          # {"gla": "Yes", ...}
    pricing_basis: dict[str, float] = field(default_factory=dict) # {"gla": 1.0, ...}
    fees_priced: dict[str, float] = field(default_factory=dict)   # {"gla": 0.06, ...}
    basic_fees: dict[str, float] = field(default_factory=dict)    # {"gla": 0.125, ...}

    # --- Misc ---
    eswatini: float | None = None

    # --- Spouse data-source flag (CatInput-Save, cell BJ1) ---
    # True  = spouse products (GLA & LSDB) source members from "Member Data - SP"
    # False = spouse products source members from "Member Data - GLA" (default)
    # When False for Spouse GLA, mortality is looked up gender-swapped
    # (main member's data proxies the spouse).
    spouse_use_sp_sheet: bool = False

    # --- Per-product options (CatInput-Save, AJ26:AK34) ---
    # express_over_gla[product] = True  -> premium rates expressed against GLA salary bill
    #                             False -> expressed against the product's own salary bill
    # category_split[product]   = "Sum Assured" | "Number of Lives" | ... (Tech Tool string)
    express_over_gla: dict[str, bool] = field(default_factory=dict)
    category_split: dict[str, str] = field(default_factory=dict)
    # --- Per-product per-category Maximum Cover Amount (CatInput-Save) ---
    # max_cover_per_category[product_key][category_number] = cap_value_zar
    # Only populated for products that have a CTR-side cap column
    # (lsdb, ci, spouse_gla, accident_death, accident_disability, dismemberment).
    max_cover_per_category: dict[str, dict[int, float]] = field(default_factory=dict)
    # --- FC per-category options (CatInput-Save EF:EX = cols 135..153) ---
    # Keyed by category_number.
    fc_max_no_of_spouses: dict[int, float] = field(default_factory=dict)
    fc_parents_included: dict[int, str] = field(default_factory=dict)
    fc_parents_in_law_included: dict[int, str] = field(default_factory=dict)
    fc_include_ctc: dict[int, str] = field(default_factory=dict)
    fc_paid_up_benefits_active: dict[int, str] = field(default_factory=dict)
    fc_pup_death: dict[int, str] = field(default_factory=dict)
    fc_pup_lsdb: dict[int, str] = field(default_factory=dict)
    fc_pup_death_lsdb: dict[int, str] = field(default_factory=dict)

    # fc_benefit_amounts[category_number][benefit_type] = amount
    # benefit_type keys:
    #   primary_insured, spouse, child_14_plus, child_6_13,
    #   child_1_5, child_under_1, stillborn, parents_cover
    fc_benefit_amounts: dict[int, dict[str, float]] = field(default_factory=dict)

    # --- GIP per-category fields (CatInput-Save 156..196 + 239) ---
    # Keyed by ORDINAL category_number (1..20) — matches FC (confirmed).
    gip_nra: dict[int, object] = field(default_factory=dict)                        # 156 mixed
    gip_cover_type: dict[int, str] = field(default_factory=dict)                    # 157
    gip_tax_options: dict[int, str] = field(default_factory=dict)                   # 158
    gip_escalation_type: dict[int, str] = field(default_factory=dict)              # 159
    gip_escalation_pct: dict[int, float] = field(default_factory=dict)             # 160
    gip_waiting_period: dict[int, str] = field(default_factory=dict)               # 161
    gip_backdating: dict[int, str] = field(default_factory=dict)                   # 162
    gip_include_conversion_option: dict[int, str] = field(default_factory=dict)    # 163
    gip_pre_ex_before: dict[int, str] = field(default_factory=dict)                # 164
    gip_pre_ex_after: dict[int, str] = field(default_factory=dict)                 # 165
    gip_initial_period: dict[int, str] = field(default_factory=dict)               # 167
    gip_core_disability_definition: dict[int, str] = field(default_factory=dict)      # 166
    gip_core_benefit_perc: dict[int, list] = field(default_factory=dict)              # 168,170,172,174
    gip_core_benefit_layer: dict[int, list] = field(default_factory=dict)             # 169,171,173,175
    gip_core_benefit_perc_additional: dict[int, float] = field(default_factory=dict)  # 176
    gip_core_benefit_layer_additional: dict[int, float] = field(default_factory=dict) # 177
    gip_core_overall_maximum: dict[int, float] = field(default_factory=dict)          # 178
    gip_employer_waiver: dict[int, float] = field(default_factory=dict)               # 179
    gip_employee_waiver: dict[int, float] = field(default_factory=dict)               # 180
    gip_hcc_disability_definition: dict[int, str] = field(default_factory=dict)       # 181
    gip_hcc_benefit_perc: dict[int, list] = field(default_factory=dict)               # 182,184,186,188
    gip_hcc_benefit_layer: dict[int, list] = field(default_factory=dict)              # 183,185,187,189
    gip_hcc_overall_maximum: dict[int, float] = field(default_factory=dict)           # 190
    gip_include_hcc_waiver: dict[int, str] = field(default_factory=dict)              # 191
    gip_hcc_payment_period: dict[int, float] = field(default_factory=dict)            # 192
    gip_hcc_payment_type: dict[int, str] = field(default_factory=dict)               # 193
    gip_hcc_nominal_amount: dict[int, float] = field(default_factory=dict)            # 194
    gip_hcc_escalation_type: dict[int, str] = field(default_factory=dict)            # 195
    gip_hcc_escalation_pct: dict[int, float] = field(default_factory=dict)           # 196
    gip_waiver_pct_specified: dict[int, str] = field(default_factory=dict)           # 239

    # --- TIP per-category fields (CatInput-Save 199..238 + 240,241) ---
    tip_nra: dict[int, object] = field(default_factory=dict)                         # 199
    tip_cover_type: dict[int, str] = field(default_factory=dict)                     # 200
    tip_tax_options: dict[int, str] = field(default_factory=dict)                    # 201
    tip_escalation_type: dict[int, str] = field(default_factory=dict)               # 202
    tip_escalation_pct: dict[int, float] = field(default_factory=dict)              # 203
    tip_waiting_period: dict[int, str] = field(default_factory=dict)                # 204
    tip_backdating: dict[int, str] = field(default_factory=dict)                    # 205
    tip_pre_ex_before: dict[int, str] = field(default_factory=dict)                 # 206
    tip_pre_ex_after: dict[int, str] = field(default_factory=dict)                  # 207
    tip_initial_period: dict[int, str] = field(default_factory=dict)                # 209
    tip_core_disability_definition: dict[int, str] = field(default_factory=dict)       # 208
    tip_core_benefit_perc: dict[int, list] = field(default_factory=dict)               # 210,212,214,216
    tip_core_benefit_layer: dict[int, list] = field(default_factory=dict)              # 211,213,215,217
    tip_core_benefit_perc_additional: dict[int, float] = field(default_factory=dict)   # 218
    tip_core_benefit_layer_additional: dict[int, float] = field(default_factory=dict)  # 219
    tip_core_overall_maximum: dict[int, float] = field(default_factory=dict)           # 220
    tip_employer_waiver: dict[int, float] = field(default_factory=dict)                # 221
    tip_employee_waiver: dict[int, float] = field(default_factory=dict)                # 222
    tip_hcc_disability_definition: dict[int, str] = field(default_factory=dict)        # 223
    tip_hcc_benefit_perc: dict[int, list] = field(default_factory=dict)                # 224,226,228,230
    tip_hcc_benefit_layer: dict[int, list] = field(default_factory=dict)               # 225,227,229,231
    tip_hcc_overall_maximum: dict[int, float] = field(default_factory=dict)            # 232
    tip_include_hcc_waiver: dict[int, str] = field(default_factory=dict)               # 233
    tip_hcc_payment_period: dict[int, float] = field(default_factory=dict)             # 234
    tip_hcc_payment_type: dict[int, str] = field(default_factory=dict)                # 235
    tip_hcc_nominal_amount: dict[int, float] = field(default_factory=dict)             # 236
    tip_hcc_escalation_type: dict[int, str] = field(default_factory=dict)             # 237
    tip_hcc_escalation_pct: dict[int, float] = field(default_factory=dict)            # 238
    tip_payment_period: dict[int, str] = field(default_factory=dict)                  # 240 (trailing)
    tip_waiver_pct_specified: dict[int, str] = field(default_factory=dict)            # 241
    tip_waiver_included: dict[int, str] = field(default_factory=dict)                 # Load-only, guarded

    # --- Education (Educate a Child / Education Guardian) ----------------
    # CatInput-Save cols 131-134 (Block A, rows 3-22 = Cat 1-20) +
    # cols 13 / 25-27 / 31 (Block B, rows 26-45 = Cat 1-20).
    # Confirmed 2026-08-18 via raw CTR dump + live TT "Education" sheet
    # formula trace. Cover Type (col 133) is a SCHEME-WIDE selector
    # broadcast identically across all 20 category rows -- NOT per-category.
    education_product: str | None = None                        # "education_guardian" | "educate_a_child" | None
    education_active: dict[int, bool] = field(default_factory=dict)         # col 15, Cat 1..20
    education_include_ctc: dict[int, str] = field(default_factory=dict)     # col 134, Cat 1..20
    education_max_cover: dict[int, float] = field(default_factory=dict)     # col 13 (Block B), Cat 1..20
    education_nra: dict[int, object] = field(default_factory=dict)         # col 25 (Block B), mixed
    education_deferred: dict[int, str] = field(default_factory=dict)       # col 26 (Block B), Yes/No
    education_deferred_age: dict[int, float] = field(default_factory=dict)  # col 27 (Block B), Cat 1..20
    education_multiple: dict[int, float] = field(default_factory=dict)     # col 31 (Block B), Cat 1..20


@dataclass(frozen=True)
class CTRBundle:
    ctr_path: Path
    ctr_fingerprint: str
    loaded_at: str
    scheme: SchemeRecord
    categories: pl.DataFrame                # long: [product, category_number, field, value]
    members: dict[str, pl.DataFrame]        # keyed by sheet role: "gla_sheet", "sp_sheet"
    active_products: tuple[str, ...]
    active_categories: dict[str, tuple[int, ...]]
    warnings: list[str] = field(default_factory=list)