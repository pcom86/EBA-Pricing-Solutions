r"""
refresh_bundles.py -- publication-time bundle refresher for the GAP Pricing Engine.

Author: Mohamed Hussein Gadiwala
Change (2026-07-29): Delta A -- only-if-stale check.

Rebuilds _snapshot_bundle.zip for the basis and assumption snapshots ONLY when
the live loose parquet files no longer match the bundle's embedded meta.

Freshness is NOT re-implemented here. Each product's own loader is the single
source of truth for its staleness rule, bundle name, and rebuild routine
(basis_loader._bundle_is_fresh / .BUNDLE_NAME / .rezip_snapshot, and the
assumption_loader equivalents). This module only orchestrates -- no cross-product
coupling, no duplicated freshness logic.

Launch cost when nothing changed : ~14ms per snapshot (one stat() sweep).
Rebuild cost when a snapshot changed: ~4-9s one-off (ZIP_STORED, atomic write).

Usage
-----
# as a script (refresh the newest basis + assumption snapshots if stale):
    python refresh_bundles.py

# from another module (e.g. app_startup):
    from refresh_bundles import refresh_all, refresh_if_stale
    summary = refresh_all()                      # newest snapshots
    summary = refresh_all(basis_folder=..., assumption_folder=...)  # pinned
"""
from __future__ import annotations

import sys
from pathlib import Path

# --- bootstrap: put THIS folder (ctr_loader) on sys.path so the sibling engine
#     modules import cleanly no matter what the caller's cwd is. engine_paths
#     then becomes the authoritative path fixer via ensure_on_path(). ---------
try:
    _HERE = Path(__file__).resolve().parent
except NameError:  # pragma: no cover - only when pasted into a raw cell
    _HERE = Path.cwd()
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from engine_paths import ensure_on_path, snapshot_dir  # noqa: E402

# each loader carries its own freshness rule + bundle name + rebuilder
import basis_loader        # noqa: E402
import assumption_loader   # noqa: E402


def refresh_if_stale(folder, *, is_fresh, bundle_name, rezip, label) -> bool:
    """Rebuild the bundle for `folder` only if it is stale.

    Parameters
    ----------
    folder      : snapshot folder holding the loose *.parquet + the bundle.
    is_fresh    : callable(zpath, files) -> bool  (the loader's _bundle_is_fresh).
    bundle_name : the loader's BUNDLE_NAME ("_snapshot_bundle.zip").
    rezip       : callable(folder) -> Path        (the loader's rezip_snapshot).
    label       : short tag for logging ("basis" / "assumption").

    Returns
    -------
    True  if a rebuild happened (bundle was stale),
    False if the bundle was already fresh or there was nothing to bundle.
    """
    folder = Path(folder)
    files = sorted(folder.glob("*.parquet"))
    if not files:
        print(f"[{label}] no parquet in {folder} -- skip")
        return False

    zpath = folder / bundle_name
    if is_fresh(zpath, files):
        print(f"[{label}] bundle already fresh -- skip ({len(files)} parquet)")
        return False

    z = rezip(folder)
    print(f"[{label}] rebuilt stale bundle -> {z}")
    return True


def refresh_all(basis_folder=None, assumption_folder=None) -> dict:
    """Refresh the newest (or explicitly pinned) basis + assumption bundles if stale.

    Returns a summary dict with the resolved folders and whether each was rebuilt.
    """
    ensure_on_path()  # ctr_loader to front (J: first, UNC fallback) -- kills shadowing

    basis_dir = Path(basis_folder) if basis_folder else snapshot_dir("basis")
    assumption_dir = Path(assumption_folder) if assumption_folder else snapshot_dir("assumption")

    rebuilt_basis = refresh_if_stale(
        basis_dir,
        is_fresh=basis_loader._bundle_is_fresh,
        bundle_name=basis_loader.BUNDLE_NAME,
        rezip=basis_loader.rezip_snapshot,
        label="basis",
    )
    rebuilt_assumption = refresh_if_stale(
        assumption_dir,
        is_fresh=assumption_loader._bundle_is_fresh,
        bundle_name=assumption_loader.BUNDLE_NAME,
        rezip=assumption_loader.rezip_snapshot,
        label="assumption",
    )

    return {
        "basis_dir": str(basis_dir),
        "assumption_dir": str(assumption_dir),
        "basis_rebuilt": rebuilt_basis,
        "assumption_rebuilt": rebuilt_assumption,
    }


if __name__ == "__main__":
    summary = refresh_all()
    print("refresh_bundles: done ->", summary)
