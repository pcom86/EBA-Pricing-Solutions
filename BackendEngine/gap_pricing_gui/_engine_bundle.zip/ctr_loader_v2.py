"""CTR loader v2 — dynamic, registry-driven, in-memory only.

No parquet, no cache. Fresh parse per quote.

Reader: python-calamine (Rust-based, robust to SST quirks that trip xlrd).
An xlrd-compatible shim keeps the parse functions unchanged.
"""
from __future__ import annotations
from datetime import datetime, date
from pathlib import Path
from dataclasses import replace
import hashlib
import time
import polars as pl

from python_calamine import CalamineWorkbook

from products_registry import PRODUCT_REGISTRY, IN_SCOPE_PRODUCTS, ProductSpec
from ctr_schemas import SchemeRecord, CTRBundle
from ctr_cache import local_ctr_path
from ctr_coerce import (
    clean_text, to_float, to_int, to_pct,
    excel_to_date, normalize_gender, snake_case,
)


# ============================================================
# xlrd-compat shim over python-calamine
# ============================================================
# The rest of this file was written against xlrd's API surface:
#   wb.sheet_names()
#   wb.sheet_by_name(name)         -> ws
#   wb.datemode                    -> int (0 for 1900, 1 for 1904)
#   wb.unload_sheet(name)          -> free memory (optional)
#   ws.nrows                       -> int
#   ws.ncols                       -> int
#   ws.cell_value(row, col)        -> Any
#
# This shim exposes exactly those APIs on top of calamine, so the parser
# functions below don't need to change. Calamine reads the whole sheet
# into a 2D Python list once, then we index into it.


class _CalamineSheet:
    """Read-only sheet accessor with xlrd-shaped API."""

    __slots__ = ("_rows", "nrows", "ncols")

    def __init__(self, rows: list[list]):
        self._rows = rows
        self.nrows = len(rows)
        self.ncols = max((len(r) for r in rows), default=0)

    def cell_value(self, row: int, col: int):
        """Return raw cell value.

        Calamine returns Python-native types:
          - text -> str
          - number -> float or int
          - date/datetime -> datetime.date / datetime.datetime
          - empty -> '' (empty string)
          - bool -> bool

        Coercion is handled downstream by ctr_coerce helpers, which already
        accept native types (see excel_to_date short-circuit).
        """
        if row >= self.nrows:
            return ""
        r = self._rows[row]
        if col >= len(r):
            return ""
        return r[col]


class _CalamineWorkbook:
    """Workbook accessor with xlrd-shaped API."""

    __slots__ = ("_wb", "_names", "_cache", "datemode")

    def __init__(self, path: Path):
        self._wb = CalamineWorkbook.from_path(str(path))
        self._names = list(self._wb.sheet_names)
        self._cache: dict[str, _CalamineSheet] = {}
        # Calamine handles 1900/1904 internally and always returns real dates.
        # We keep datemode for signature compatibility; ctr_coerce ignores it
        # when the value is already a date/datetime.
        self.datemode = 0

    def sheet_names(self) -> list[str]:
        return self._names

    def sheet_by_name(self, name: str) -> _CalamineSheet:
        if name in self._cache:
            return self._cache[name]
        raw = self._wb.get_sheet_by_name(name).to_python()
        sheet = _CalamineSheet(raw)
        self._cache[name] = sheet
        return sheet

    def unload_sheet(self, name: str) -> None:
        """Free the cached rows for a sheet. No-op if not cached."""
        self._cache.pop(name, None)


def _open_workbook(ctr_path: Path) -> _CalamineWorkbook:
    """Open a .ctr / .xls / .xlsx file via calamine, wrapped in the xlrd shim."""
    return _CalamineWorkbook(ctr_path)


# ============================================================
# Fingerprint (path + mtime + size) — used for audit only
# ============================================================
def _fingerprint(ctr_path: str) -> str:
    p = Path(ctr_path)
    key = f"{p.resolve()}|{p.stat().st_mtime_ns}|{p.stat().st_size}"
    return hashlib.sha256(key.encode()).hexdigest()[:16]


# ============================================================
# Scheme Details - Save parser
# ============================================================
# Static column map for rows 1/2 (the "wide identity band")
_SCHEME_IDENTITY_MAP = {
    # col: (attr_name, coercer_key)
    0:  ("quote_type",          "text"),
    1:  ("quote_group",         "text"),
    2:  ("quote_number",        "int"),
    3:  ("doer",                "text"),
    4:  ("checker",             "text"),
    5:  ("scheme_name",         "text"),
    23: ("effective_date",      "date"),
    24: ("calculation_date",    "date"),
    25: ("commencement_date",   "date"),
    26: ("intermediary",        "text"),
    27: ("broker_name",         "text"),
    28: ("client_manager",      "text"),
    29: ("branch",              "text"),
    30: ("alexander_forbes_scheme", "text"),
    31: ("country_scale",       "text"),
    32: ("pct_comm_applied",    "pct"),
    33: ("initial_commission",  "text"),
    34: ("collection_commission","text"),
    35: ("collection_fee_pct",  "pct"),
    36: ("include_vat_commission","text"),
    37: ("namibian_stamp_duty", "text"),
    38: ("premium_frequency",   "text"),
    39: ("fee_structure",       "text"),
    40: ("annual_fee_gla",      "float"),
    41: ("admin_fee_pct_gla",   "pct"),
    42: ("annual_fee_gip",      "float"),
    43: ("admin_fee_pct_gip",   "pct"),
    44: ("annual_fee_fc",       "float"),
    45: ("admin_fee_pct_fc",    "pct"),
    46: ("annual_fee_tip",      "float"),
    47: ("admin_fee_pct_tip",   "pct"),
    48: ("primary",             "text"),
    49: ("secondary",           "text"),
    50: ("region",              "text"),
}

# Scheme codes span cols 6..22 (17 products)
_SCHEME_CODE_COLS = list(range(6, 23))

# Regions span cols 51..61 (labels come from row 1)
_REGION_COLS = list(range(51, 62))

# Salary def & pear_tgp near col 62..64
_SALARY_DEF_COL = 62
_PEAR_TGP_COL = 64

# Product-repeating sections (start col found via row 0 markers)
_SECTION_MARKERS = {
    "Rating Selections": "rating",
    "Pricing Basis": "pricing_basis",
    "Fees Priced": "fees_priced",
}
_ESWATINI_MARKER = "Add eSwatini"
_BASIC_FEES_MARKER = "Jigsaw/TSA Basic Fees"


def _coerce(kind, v, datemode):
    if kind == "text":  return clean_text(v)
    if kind == "int":   return to_int(v)
    if kind == "float": return to_float(v)
    if kind == "pct":   return to_pct(v)
    if kind == "date":  return excel_to_date(v, datemode)
    return v


def _parse_scheme_details(ws, datemode) -> SchemeRecord:
    """Parse Scheme Details - Save into a SchemeRecord."""
    fields: dict = {}

    # --- Identity band (rows 1 label, row 2 value) ---
    for col, (attr, kind) in _SCHEME_IDENTITY_MAP.items():
        if col >= ws.ncols:
            continue
        v = ws.cell_value(2, col)
        fields[attr] = _coerce(kind, v, datemode)

    # --- Scheme codes ---
    scheme_codes = {}
    for col in _SCHEME_CODE_COLS:
        if col >= ws.ncols:
            continue
        label = clean_text(ws.cell_value(1, col))
        val = clean_text(ws.cell_value(2, col))
        if label:
            # "Scheme Code -GLA" -> "gla"
            key = snake_case(label.replace("Scheme Code -", "").replace("Scheme Code-", ""))
            scheme_codes[key] = val
    fields["scheme_codes"] = scheme_codes

    # --- Regions ---
    regions = {}
    for col in _REGION_COLS:
        if col >= ws.ncols:
            continue
        label = clean_text(ws.cell_value(1, col))
        val = to_float(ws.cell_value(2, col))
        if label:
            regions[snake_case(label)] = val
    fields["regions"] = regions

    # --- Salary def & pear/tgp ---
    if _SALARY_DEF_COL < ws.ncols:
        fields["salary_definition"] = clean_text(ws.cell_value(2, _SALARY_DEF_COL))
    if _PEAR_TGP_COL < ws.ncols:
        fields["pear_tgp_pct"] = to_pct(ws.cell_value(2, _PEAR_TGP_COL))

    # --- Product-repeating sections: locate by row 0 markers ---
    section_bounds = _find_section_bounds(ws)   # {section_name: (start_col, end_col_exclusive)}

    for marker, attr in _SECTION_MARKERS.items():
        bounds = section_bounds.get(marker)
        if bounds is None:
            continue
        start, end = bounds
        block = {}
        for c in range(start, end):
            label = clean_text(ws.cell_value(1, c))
            if not label:
                continue
            if label not in _ALL_PRODUCT_LABELS:
                continue  # skip non-product labels (Primary, Regions, Salary Def, ...)
            raw = ws.cell_value(2, c)
            if attr == "rating":
                block[_product_key_from_label(label)] = clean_text(raw)
            else:
                block[_product_key_from_label(label)] = to_float(raw)
        fields[attr] = block

    # --- Add eSwatini (single cell) ---
    esw_bounds = section_bounds.get(_ESWATINI_MARKER)
    if esw_bounds is not None:
        start, _ = esw_bounds
        fields["eswatini"] = to_float(ws.cell_value(2, start))

    # --- Basic Fees (rows 3=section, 4=labels, 5=values) ---
    basic_fees = _parse_basic_fees(ws)
    fields["basic_fees"] = basic_fees

    return SchemeRecord(**fields)


def _find_section_bounds(ws) -> dict[str, tuple[int, int]]:
    """Scan row 0 for section markers; return (start_col, end_col_exclusive) per marker."""
    markers = []
    for c in range(ws.ncols):
        v = clean_text(ws.cell_value(0, c))
        if v and v in list(_SECTION_MARKERS.keys()) + [_ESWATINI_MARKER, _BASIC_FEES_MARKER,
                                                        "Scheme Details", "Commission Structre",
                                                        "Fee Structure"]:
            markers.append((c, v))
    bounds = {}
    for i, (c, name) in enumerate(markers):
        end = markers[i + 1][0] if i + 1 < len(markers) else ws.ncols
        bounds[name] = (c, end)
    return bounds


def _parse_basic_fees(ws) -> dict[str, float]:
    """Rows 3 (section 'Jigsaw/TSA Basic Fees'), 4 (labels), 5 (values)."""
    if ws.nrows < 6:
        return {}
    out = {}
    for c in range(ws.ncols):
        label = clean_text(ws.cell_value(4, c))
        if not label:
            continue
        if label not in _ALL_PRODUCT_LABELS:
            continue
        val = to_float(ws.cell_value(5, c))
        out[_product_key_from_label(label)] = val
    return out


# Reverse lookup: product label -> registry key
_LABEL_TO_KEY: dict[str, str] = {}
def _build_label_index():
    for key, spec in PRODUCT_REGISTRY.items():
        for lbl in {spec.rating_label, spec.pricing_basis_label,
                    spec.fees_priced_label, spec.basic_fee_label}:
            _LABEL_TO_KEY[lbl] = key
_build_label_index()


# All labels that legitimately belong to a product (in-scope + known out-of-scope)
# NOTE: "FC" removed from out-of-scope now that Family Cover is a registered
# in-scope product (see PRODUCT_REGISTRY["fc"]). Kept the other family/income
# variants that remain out of scope for the current 9-product engine.
_OUT_OF_SCOPE_LABELS = frozenset({
    "Educate a Child", "Extended Family Cover",
    "Spouses & Childrens Income Cover", "S & C Income Cover",
  
})
def _build_all_product_labels() -> frozenset:
    labels = set(_OUT_OF_SCOPE_LABELS)
    for spec in PRODUCT_REGISTRY.values():
        labels.update({spec.rating_label, spec.pricing_basis_label,
                       spec.fees_priced_label, spec.basic_fee_label})
    return frozenset(labels)
_ALL_PRODUCT_LABELS = _build_all_product_labels()


def _product_key_from_label(label: str) -> str:
    """Map a CTR label back to a product registry key.
    Falls back to snake_case of the label for out-of-scope products
    (educate_a_child, fc, gip, tip, extended_family_cover, ...).
    """
    if label in _LABEL_TO_KEY:
        return _LABEL_TO_KEY[label]
    return snake_case(label)


# ============================================================
# CatInput-Save parser
# ============================================================
_CAT_NUM_CATEGORIES_CELL = (0, 7)     # row 0 col 7 = "6.0"
_CAT_TOGGLES_ROW = 3                  # first category row has product Y/N toggles too
_CAT_LABEL_ROW = 2                    # field labels within each product block
_CAT_DATA_START_ROW = 3
_CAT_TOGGLE_COLS = list(range(1, 17)) # cols 1..16 hold per-category product toggles

# BJ1 flag on CatInput-Save controls spouse product data source:
#   "Yes"        -> spouse GLA/LSDB source members from Member Data - SP
#   "No"/blank   -> spouse GLA/LSDB source members from Member Data - GLA
_SPOUSE_SOURCE_FLAG_CELL = (0, 61)


def _read_spouse_source_flag(ws) -> bool:
    """Read BJ1 on CatInput-Save. True = SP sheet, False = GLA sheet."""
    row, col = _SPOUSE_SOURCE_FLAG_CELL
    if ws.nrows <= row or ws.ncols <= col:
        return False
    raw = clean_text(ws.cell_value(row, col))
    if raw is None:
        return False
    return raw.strip().lower() == "yes"


# ---------------------------------------------------------------------------
# Per-product options: AJ26:AK36 on CatInput-Save
# ---------------------------------------------------------------------------
# Order matches Excel rows 26..34 (0-indexed 25..33).
# S&C and EAC are omitted — not in scope for pricing / reporting.
_PRODUCT_OPTION_ORDER = (
    "gla", "lsdb", "ci",
    "spouse_gla", "spouse_lsdb",
    "terminal",
    "accident_death", "accident_disability", "dismemberment",
)

# 0-indexed positions of AJ26 and AK26 in the Calamine shim
_PRODUCT_OPT_START_ROW = 26   # Excel row 27
_PRODUCT_OPT_EXPRESS_COL = 35
_EDUCATION_OPT_ROW_OFFSET = 10  # Excel row 37 -- one slot past unused S&C Income Cover (offset 9); confirmed via live TT AJ37 trace 2026-08-20 # Excel col AJ
_PRODUCT_OPT_SPLIT_COL   = 36 # Excel col AK


# Confirmed 2026-08-14: column AK ("Category Split Options") is NOT
# per-GLA-family-product like AJ ("Express over GLA Option") -- it holds
# exactly 4 values, one per SHEET FAMILY (GLA, FC, GIP, TIP), in that
# fixed row order (rows 27-30 / 0-indexed 26-29). Confirmed via raw .ctr
# inspection (AK only populated for the first 4 of 9 product rows,
# identical value "Sum Assured" across all 4) and directly confirmed by
# user. Whichever split a sheet is set to applies uniformly to every
# product rendered on that sheet (e.g. GLA sheet's split applies to gla,
# lsdb, ci, spouse_gla, spouse_lsdb, terminal, accident_death,
# accident_disability, dismemberment all together).
_CATEGORY_SPLIT_SHEET_ORDER = ("gla", "gip", "tip", "fc")  # FIXED 2026-08-20: was mislabeled (fc/gip/tip) -- confirmed via live TT AK28:AK30 formula trace (Category Breakdown - GIP/TIP/FC respectively)
_CATEGORY_SPLIT_ROW_OFFSETS = (0, 1, 2, 3)  # rows 27,28,29,30 (0-idx 26,27,28,29)


def _read_product_options(ws) -> tuple[dict[str, bool], dict[str, str]]:
    """Read AJ26:AJ34 -> express_over_gla (per GLA-family product, 9 rows).
    Category split is read separately by _read_category_split (per sheet
    family, 4 rows) -- see that function for the 2026-08-14 correction."""
    express: dict[str, bool] = {}
    for i, pkey in enumerate(_PRODUCT_OPTION_ORDER):
        row = _PRODUCT_OPT_START_ROW + i
        if row >= ws.nrows:
            express[pkey] = False
            continue
        aj = ws.cell_value(row, _PRODUCT_OPT_EXPRESS_COL)
        express[pkey] = _to_bool(aj)
    return express


def _read_education_express_over_gla(ws) -> bool:
    """Read AJ37 -> raw express_over_gla boolean for Education (whichever
    variant is active). Kept as its own reader since Education's slot sits
    at _PRODUCT_OPT_START_ROW + _EDUCATION_OPT_ROW_OFFSET (row 37), one row
    past the unused S&C Income Cover slot (row 36) -- NOT reachable via
    _PRODUCT_OPTION_ORDER's enumerate loop. Confirmed via live TT AJ37 trace
    2026-08-20 (TRANSPOSE('GLA - Pricing Outputs'!$C$3:$M$3), col M)."""
    row = _PRODUCT_OPT_START_ROW + _EDUCATION_OPT_ROW_OFFSET
    if row >= ws.nrows:
        return False
    aj = ws.cell_value(row, _PRODUCT_OPT_EXPRESS_COL)
    return _to_bool(aj)


def _read_category_split(ws) -> dict[str, str]:
    """Read AK27:AK30 -> category_split keyed by SHEET FAMILY (gla/fc/gip/tip),
    NOT by individual product. Confirmed 2026-08-14 -- see module notes above
    _CATEGORY_SPLIT_SHEET_ORDER."""
    cat_split: dict[str, str] = {}
    for sheet_key, offset in zip(_CATEGORY_SPLIT_SHEET_ORDER, _CATEGORY_SPLIT_ROW_OFFSETS):
        row = _PRODUCT_OPT_START_ROW + offset
        if row >= ws.nrows:
            cat_split[sheet_key] = ""
            continue
        ak = ws.cell_value(row, _PRODUCT_OPT_SPLIT_COL)
        cat_split[sheet_key] = "" if ak in (None, "") else str(ak).strip()
    return cat_split


def _to_bool(v) -> bool:
    if v is None:
        return False
    return str(v).strip().lower() in ("yes", "y", "true", "1")

# ---------------------------------------------------------------------------
# Profit Refund / PRO / PRB options on CatInput-Save
# ---------------------------------------------------------------------------

# CatInput-Save row 1, zero-indexed row 0:
# T1  = overall PRB yes/no
# U1  = PRB %
# V1  = GLA PRB yes/no
# W1  = LSDB PRB yes/no
# X1  = CI PRB yes/no
# Y1  = GIP PRB yes/no
# Z1  = FC PRB yes/no
# AA1 = TIP PRB yes/no

_PRB_OVERALL_FLAG_CELL = (0, 19)  # T1
_PRB_LOADING_CELL      = (0, 20)  # U1

_PRB_PRODUCT_FLAG_COLS = {
    "gla":      21,  # V1
    "lsdb":     22,  # W1
    "ci":       23,  # X1

    # Out-of-scope for current 9-product engine, but loaded for traceability.
    "gip":      24,  # Y1
    "fc":       25,  # Z1
    "tip": 26,  # AA1
}

# ---------------------------------------------------------------------------
# Rate Basis (Pricing Basis) — Scheme Details - Save row 3, cols CC..CK
# ---------------------------------------------------------------------------
# Row 1: "Pricing Basis" section header
# Row 2: Product labels (GLA, LSDB, CI, ...)
# Row 3: Per-product multipliers. 1.0 = no override.
# ---------------------------------------------------------------------------
_RATE_BASIS_ROW = 2   # 0-indexed → Excel row 3

_RATE_BASIS_PRODUCT_COLS = {
    "gla":                 80,   # CC
    "lsdb":                81,   # CD
    "ci":                  82,   # CE
    "spouse_gla":          83,   # CF
    "spouse_lsdb":         84,   # CG
    "terminal":            85,   # CH
    "accident_death":      86,   # CI
    "accident_disability": 87,   # CJ
    "dismemberment":       88,   # CK
    # Out of scope: CL sc_income, CM education, CN fc
}

def _safe_cell_value(ws, row: int, col: int):
    """
    Safe xlrd/calamine-style cell read.
    Returns None if the requested cell is outside the sheet bounds.
    """
    if row < 0 or col < 0:
        return None
    if row >= ws.nrows or col >= ws.ncols:
        return None
    return ws.cell_value(row, col)


def _normalise_prb_pct(value) -> float | None:
    """
    Normalise PRB percentage to decimal form.

    Handles:
      0.05  -> 0.05
      5     -> 0.05
      '5%'  -> 0.05
    """
    pct = to_pct(value)

    if pct is None:
        return None

    try:
        pct = float(pct)
    except (TypeError, ValueError):
        return None

    # Some CTRs may store 5 instead of 0.05.
    if pct > 1:
        pct = pct / 100.0

    return pct


def _read_profit_refund_loading(ws) -> dict[str, float]:
    """
    Read Profit Refund / PRO / PRB settings from CatInput-Save.

    Source cells:
      T1  = overall PRB yes/no
      U1  = PRB %
      V1  = GLA PRB yes/no
      W1  = LSDB PRB yes/no
      X1  = CI PRB yes/no
      Y1  = GIP PRB yes/no
      Z1  = FC PRB yes/no
      AA1 = TIP PRB yes/no

    Returns:
        dict keyed by product_key, containing decimal PRB loading.
        Example:
            {"gla": 0.05, "lsdb": 0.05, "ci": 0.05}
    """
    overall_row, overall_col = _PRB_OVERALL_FLAG_CELL
    pct_row, pct_col = _PRB_LOADING_CELL

    overall_yes = _to_bool(_safe_cell_value(ws, overall_row, overall_col))
    prb_pct = _normalise_prb_pct(_safe_cell_value(ws, pct_row, pct_col))

    if not overall_yes or prb_pct is None:
        return {}

    out: dict[str, float] = {}

    for product_key, col in _PRB_PRODUCT_FLAG_COLS.items():
        if _to_bool(_safe_cell_value(ws, 0, col)):
            out[product_key] = prb_pct

    return out

def _read_rate_basis(ws) -> dict[str, float]:
    """
    Read per-product Rate Basis (Pricing Basis) multipliers from
    Scheme Details - Save, row 3, cols CC..CK.

    Missing / blank cells default to 1.0 (no override).
    """
    out: dict[str, float] = {}
    for pkey, col in _RATE_BASIS_PRODUCT_COLS.items():
        raw = _safe_cell_value(ws, _RATE_BASIS_ROW, col)
        val = to_float(raw)
        out[pkey] = 1.0 if val is None else float(val)
    return out

# ---------------------------------------------------------------------------
# Per-product "Maximum Cover Amount" columns on CatInput-Save
# ---------------------------------------------------------------------------
# Cat 1..20 live on rows 3..22 (0-indexed).
# (product_key, variant) -> 0-indexed column on CatInput-Save.
# Products with no CTR-side custom cap column are omitted:
#   - gla         : no cap column
#   - spouse_lsdb : no cap column
#   - terminal    : no cap column (per user; TI premium derived from GLA)
_MAX_COVER_COL: dict[tuple[str, str], int] = {
    ("lsdb",                "accelerator"): 35,   # AJ
    ("lsdb",                "standalone"):  79,   # CB
    ("ci",                  "accelerator"): 52,   # BA
    ("ci",                  "standalone"):  96,   # CS
    ("spouse_gla",          "default"):     64,   # BM
    ("accident_death",      "default"):    115,   # DL
    ("accident_disability", "default"):    120,   # DQ
    ("dismemberment",       "default"):    125,   # DV
}

# Row range where Cat 1..20 data lives on CatInput-Save (0-indexed).
_MAX_COVER_ROW_START = 3
_MAX_COVER_ROW_END   = 23   # exclusive; covers 0-idx rows 3..22 = Cat 1..Cat 20


# ---------------------------------------------------------------------------
# FC (Family Cover) per-category fields — CatInput-Save cols EF..EX
# ---------------------------------------------------------------------------
# The FC block spans 0-indexed cols 135..153 (Excel EF..EX), matching
# PRODUCT_REGISTRY["fc"].catinput_blocks["default"] = (135, 154).
#
# Cols 135..137 (EF..EH) — Category Name / Category Flag / NRA — are already
# captured by the generic long-format _parse_catinput path, so we do NOT
# duplicate them here.
#
# Cols 138..145 (EI..EP) — per-category selection toggles and Max Spouses.
# Cols 146..153 (EQ..EX) — the 8 benefit-amount columns per category, which
# form the FC benefit grid used by compute_fc_composite_cover downstream.
# ---------------------------------------------------------------------------

# col -> (SchemeRecord attribute name, coercer kind)
_FC_CATINPUT_FIELD_MAP: dict[int, tuple[str, str]] = {
    138: ("fc_max_no_of_spouses",       "float"),  # EI
    139: ("fc_parents_included",        "text"),   # EJ
    140: ("fc_parents_in_law_included", "text"),   # EK
    141: ("fc_include_ctc",             "text"),   # EL
    142: ("fc_paid_up_benefits_active", "text"),   # EM
    143: ("fc_pup_death",               "text"),   # EN
    144: ("fc_pup_lsdb",                "text"),   # EO
    145: ("fc_pup_death_lsdb",          "text"),   # EP
}

# col -> benefit_type key used in fc_benefit_amounts[cat][benefit_type]
_FC_BENEFIT_AMOUNT_COLS: dict[int, str] = {
    146: "primary_insured",  # EQ — Main member
    147: "spouse",           # ER — Insured Spouse
    148: "child_14_plus",    # ES — Child (Age 14+)
    149: "child_6_13",       # ET — Child (Age 6-13)
    150: "child_1_5",        # EU — Child (Age 1-5)
    151: "child_under_1",    # EV — Child (Under Age 1)
    152: "stillborn",        # EW — Child (Stillborn)
    153: "parents_cover",    # EX — Parents Cover
}


def _read_fc_catinput_fields(
    ws,
    active_categories: dict[str, tuple[int, ...]],
) -> dict[str, dict]:
    """Read FC-specific per-category options + benefit grid from CatInput-Save.

    Returns a dict shaped for `dataclasses.replace(scheme, **out)`:
        {
            "fc_max_no_of_spouses":       {cat_num: float, ...},
            "fc_parents_included":        {cat_num: "Yes"/"No", ...},
            "fc_parents_in_law_included": {cat_num: "Yes"/"No", ...},
            "fc_include_ctc":             {cat_num: "Yes"/"No", ...},
            "fc_paid_up_benefits_active": {cat_num: "Yes"/"No", ...},
            "fc_pup_death":               {cat_num: "Yes"/"No", ...},
            "fc_pup_lsdb":                {cat_num: "Yes"/"No", ...},
            "fc_pup_death_lsdb":          {cat_num: "Yes"/"No", ...},
            "fc_benefit_amounts":         {cat_num: {benefit_type: amount, ...}, ...},
        }

    Only categories flagged Yes for FC on CatInput-Save are populated.
    Returns empty dicts (not omitted keys) if FC is inactive or the sheet is
    too narrow to reach the FC block — this keeps `replace(...)` safe.
    """
    # Initialise every FC dict up-front so replace() is uniform whether FC
    # is active or not.
    out: dict[str, dict] = {
        attr: {} for attr, _ in _FC_CATINPUT_FIELD_MAP.values()
    }
    out["fc_benefit_amounts"] = {}

    fc_active_cats = active_categories.get("fc", ())
    if not fc_active_cats:
        return out

    # If the sheet does not extend past the FC block, bail cleanly.
    if ws.ncols <= 153:
        return out

    for cat_num in fc_active_cats:
        row = _CAT_DATA_START_ROW + int(cat_num) - 1
        if row >= ws.nrows:
            continue

        # --- Selection toggles + max spouses (EI..EP) ---
        for col, (attr, kind) in _FC_CATINPUT_FIELD_MAP.items():
            raw = _safe_cell_value(ws, row, col)
            if kind == "float":
                val = to_float(raw)
            else:
                val = clean_text(raw)
            if val is not None:
                out[attr][int(cat_num)] = val

        # --- Benefit amounts (EQ..EX) ---
        benefits: dict[str, float] = {}
        for col, benefit_key in _FC_BENEFIT_AMOUNT_COLS.items():
            val = to_float(_safe_cell_value(ws, row, col))
            if val is not None:
                benefits[benefit_key] = val
        if benefits:
            out["fc_benefit_amounts"][int(cat_num)] = benefits

    return out

# ---------------------------------------------------------------------------
# GIP per-category fields — CatInput-Save cols 156..196 + trailing col 239
# Leading 154..157 captured by generic path (catinput_blocks=(154,158)).
# GIP has DUPLICATE ladder labels (core vs HCC), so read by explicit index.
# ---------------------------------------------------------------------------
_GIP_CATLEVEL_MAP: dict[int, tuple[str, str]] = {
    156: ("gip_nra", "raw"),               157: ("gip_cover_type", "text"),
    158: ("gip_tax_options", "text"),      159: ("gip_escalation_type", "text"),
    160: ("gip_escalation_pct", "float"),  161: ("gip_waiting_period", "text"),
    162: ("gip_backdating", "text"),       163: ("gip_include_conversion_option", "text"),
    164: ("gip_pre_ex_before", "text"),    165: ("gip_pre_ex_after", "text"),
    166: ("gip_core_disability_definition", "text"), 167: ("gip_initial_period", "text"),
    176: ("gip_core_benefit_perc_additional", "float"),
    177: ("gip_core_benefit_layer_additional", "float"),
    178: ("gip_core_overall_maximum", "float"),
    179: ("gip_employer_waiver", "float"), 180: ("gip_employee_waiver", "float"),
    181: ("gip_hcc_disability_definition", "text"),
    190: ("gip_hcc_overall_maximum", "float"), 191: ("gip_include_hcc_waiver", "text"),
    192: ("gip_hcc_payment_period", "float"),  193: ("gip_hcc_payment_type", "text"),
    194: ("gip_hcc_nominal_amount", "float"),  195: ("gip_hcc_escalation_type", "text"),
    196: ("gip_hcc_escalation_pct", "float"),  239: ("gip_waiver_pct_specified", "text"),
}
_GIP_CORE_PERC_COLS  = [168, 170, 172, 174]
_GIP_CORE_LAYER_COLS = [169, 171, 173, 175]
_GIP_HCC_PERC_COLS   = [182, 184, 186, 188]
_GIP_HCC_LAYER_COLS  = [183, 185, 187, 189]
_GIP_ROW_START, _GIP_ROW_END = 3, 23   # Cat 1..20

def _coerce_gip(kind, v):
    if kind == "text":  return clean_text(v)
    if kind == "float": return to_float(v)
    if kind == "int":   return to_int(v)
    return v                              # "raw" — leave mixed NRA as-is

def _read_gip_catinput_fields(ws, active_categories: dict[str, tuple[int, ...]]) -> dict[str, dict]:
    gip_active = set(active_categories.get("gip", ()))
    out: dict[str, dict] = {attr: {} for attr, _ in _GIP_CATLEVEL_MAP.values()}
    for k in ("gip_core_benefit_perc", "gip_core_benefit_layer",
              "gip_hcc_benefit_perc",  "gip_hcc_benefit_layer"):
        out[k] = {}
    for r in range(_GIP_ROW_START, min(_GIP_ROW_END, ws.nrows)):
        if _safe_cell_value(ws, r, 155) in (None, ""):
            continue
        cat = r - 2                       # ordinal (Cat 1 = row idx 3) — matches FC
        if gip_active and cat not in gip_active:
            continue
        for col, (attr, kind) in _GIP_CATLEVEL_MAP.items():
            out[attr][cat] = _coerce_gip(kind, _safe_cell_value(ws, r, col))
        out["gip_core_benefit_perc"][cat]  = [to_float(_safe_cell_value(ws, r, c)) for c in _GIP_CORE_PERC_COLS]
        out["gip_core_benefit_layer"][cat] = [to_float(_safe_cell_value(ws, r, c)) for c in _GIP_CORE_LAYER_COLS]
        out["gip_hcc_benefit_perc"][cat]   = [to_float(_safe_cell_value(ws, r, c)) for c in _GIP_HCC_PERC_COLS]
        out["gip_hcc_benefit_layer"][cat]  = [to_float(_safe_cell_value(ws, r, c)) for c in _GIP_HCC_LAYER_COLS]
    return out

_TIP_CATLEVEL_MAP: dict[int, tuple[str, str]] = {
    199: ("tip_nra", "raw"),                200: ("tip_cover_type", "text"),
    201: ("tip_tax_options", "text"),       202: ("tip_escalation_type", "text"),
    203: ("tip_escalation_pct", "float"),   204: ("tip_waiting_period", "text"),
    205: ("tip_backdating", "text"),        206: ("tip_pre_ex_before", "text"),
    207: ("tip_pre_ex_after", "text"),      208: ("tip_core_disability_definition", "text"),
    209: ("tip_initial_period", "text"),
    218: ("tip_core_benefit_perc_additional", "float"),
    219: ("tip_core_benefit_layer_additional", "float"),
    220: ("tip_core_overall_maximum", "float"),
    221: ("tip_employer_waiver", "float"),  222: ("tip_employee_waiver", "float"),
    223: ("tip_hcc_disability_definition", "text"),
    232: ("tip_hcc_overall_maximum", "float"), 233: ("tip_include_hcc_waiver", "text"),
    234: ("tip_hcc_payment_period", "float"),  235: ("tip_hcc_payment_type", "text"),
    236: ("tip_hcc_nominal_amount", "float"),  237: ("tip_hcc_escalation_type", "text"),
    238: ("tip_hcc_escalation_pct", "float"),  240: ("tip_payment_period", "text"),
    241: ("tip_waiver_pct_specified", "text"),
}
_TIP_CORE_PERC_COLS  = [210, 212, 214, 216]
_TIP_CORE_LAYER_COLS = [211, 213, 215, 217]
_TIP_HCC_PERC_COLS   = [224, 226, 228, 230]
_TIP_HCC_LAYER_COLS  = [225, 227, 229, 231]
_TIP_ROW_START, _TIP_ROW_END = 3, 23

def _read_tip_catinput_fields(ws, active_categories):
    tip_active = set(active_categories.get("tip", ()))
    out = {attr: {} for attr, _ in _TIP_CATLEVEL_MAP.values()}
    for k in ("tip_core_benefit_perc","tip_core_benefit_layer",
              "tip_hcc_benefit_perc","tip_hcc_benefit_layer"):
        out[k] = {}
    for r in range(_TIP_ROW_START, min(_TIP_ROW_END, ws.nrows)):
        if _safe_cell_value(ws, r, 198) in (None, ""):   # TIP Category Flag @198
            continue
        cat = r - 2
        if tip_active and cat not in tip_active:
            continue
        for col, (attr, kind) in _TIP_CATLEVEL_MAP.items():
            out[attr][cat] = _coerce_gip(kind, _safe_cell_value(ws, r, col))  # reuse gip coercer
        out["tip_core_benefit_perc"][cat]  = [to_float(_safe_cell_value(ws, r, c)) for c in _TIP_CORE_PERC_COLS]
        out["tip_core_benefit_layer"][cat] = [to_float(_safe_cell_value(ws, r, c)) for c in _TIP_CORE_LAYER_COLS]
        out["tip_hcc_benefit_perc"][cat]   = [to_float(_safe_cell_value(ws, r, c)) for c in _TIP_HCC_PERC_COLS]
        out["tip_hcc_benefit_layer"][cat]  = [to_float(_safe_cell_value(ws, r, c)) for c in _TIP_HCC_LAYER_COLS]
    return out

def _read_max_cover_caps(
    ws,
    scheme: SchemeRecord,
    products: tuple[str, ...],
    active_categories: dict[str, tuple[int, ...]] | None = None,
) -> dict[str, dict[int, float]]:
    """Read per-product, per-category 'Maximum Cover Amount' from CatInput-Save.

    Returns dict keyed by product_key -> {category_number: cap_value}.
    Only in-scope products with a CTR-side cap column are populated.
    Cells that are blank / zero / non-numeric are stored as None (interpreted
    downstream as 'no cap for this category').

    The row-order convention on CatInput-Save is:
        0-indexed row 3  = Cat 1
        0-indexed row 4  = Cat 2
        ...
        0-indexed row 22 = Cat 20

    We also read the actual category_number from col 0 of the same row (rather
    than assuming (row - 3 + 1)), so we're robust if the sheet layout ever
    shifts.
    """
    caps: dict[str, dict[int, float]] = {}

    for pkey in products:
        spec = PRODUCT_REGISTRY[pkey]
        variant = _pick_variant(spec, scheme, [])  # warnings already captured earlier
        if variant is None:
            continue

        col = _MAX_COVER_COL.get((pkey, variant))
        if col is None:
            # Product has no CTR-side cap column (e.g. gla, spouse_lsdb, terminal)
            continue

        product_caps: dict[int, float] = {}
        active_set = set(active_categories.get(pkey, ())) if active_categories else None

        for r in range(_MAX_COVER_ROW_START, min(_MAX_COVER_ROW_END, ws.nrows)):
            cat_num = to_int(ws.cell_value(r, 0))
            if cat_num is None:
                continue
            # Optional: only store caps for categories active on this product
            if active_set is not None and cat_num not in active_set:
                continue
            raw = ws.cell_value(r, col)
            val = to_float(raw)
            if val is None or val <= 0:
                product_caps[cat_num] = None   # explicitly "no cap"
            else:
                product_caps[cat_num] = val
        caps[pkey] = product_caps

    return caps


def _parse_catinput(ws, scheme: SchemeRecord, products: tuple[str, ...]
                    ) -> tuple[pl.DataFrame, dict[str, tuple[int, ...]], list[str]]:
    warnings = []

    # --- N categories ---
    num_cats = to_int(ws.cell_value(*_CAT_NUM_CATEGORIES_CELL)) or 0
    if num_cats <= 0:
        warnings.append("Could not determine number of categories from row 0 col 7")
        return pl.DataFrame(schema={"product": pl.Utf8, "category_number": pl.Int64,
                                    "field": pl.Utf8, "value": pl.Utf8}), {}, warnings

    # --- Per-category product toggles (cols 1..16, row 2 = labels, row 3+ = values) ---
    toggle_labels = {}
    for c in _CAT_TOGGLE_COLS:
        lbl = clean_text(ws.cell_value(2, c))
        if lbl:
            toggle_labels[c] = _product_key_from_label(lbl)

    # active_categories[product] = tuple(category_numbers where toggle == 'Yes')
    active_categories: dict[str, list[int]] = {p: [] for p in products}
    for cat_i in range(num_cats):
        row = _CAT_DATA_START_ROW + cat_i
        cat_num = to_int(ws.cell_value(row, 0))
        if cat_num is None:
            continue
        for col, prod_key in toggle_labels.items():
            if prod_key not in products:
                continue
            val = clean_text(ws.cell_value(row, col))
            if val and val.lower() == "yes":
                active_categories[prod_key].append(cat_num)

    # --- Per-product block extraction (LONG format) ---
    long_rows: list[dict] = []
    for prod_key in products:
        spec = PRODUCT_REGISTRY[prod_key]

        # Pick the right block variant
        variant = _pick_variant(spec, scheme, warnings)
        if variant is None:
            continue
        block = spec.catinput_blocks.get(variant)
        if block is None:
            warnings.append(f"[{prod_key}] no block for variant '{variant}'")
            continue
        start, end = block

        # Read field labels from row 2 within the block
        fields_in_block = {}
        for c in range(start, min(end, ws.ncols)):
            lbl = clean_text(ws.cell_value(_CAT_LABEL_ROW, c))
            if lbl:
                fields_in_block[c] = snake_case(lbl)

        # Read categories 1..N (only those active for this product)
        active = set(active_categories.get(prod_key, []))
        for cat_i in range(num_cats):
            row = _CAT_DATA_START_ROW + cat_i
            cat_num = to_int(ws.cell_value(row, 0))
            if cat_num is None or cat_num not in active:
                continue
            for c, fld in fields_in_block.items():
                raw = ws.cell_value(row, c)
                val = clean_text(raw) if not isinstance(raw, (int, float)) else raw
                long_rows.append({
                    "product": prod_key,
                    "variant": variant,
                    "category_number": cat_num,
                    "field": fld,
                    "value": None if val is None else str(val),
                })

    df = pl.DataFrame(long_rows, schema={
        "product": pl.Utf8, "variant": pl.Utf8,
        "category_number": pl.Int64, "field": pl.Utf8, "value": pl.Utf8,
    }) if long_rows else pl.DataFrame(schema={
        "product": pl.Utf8, "variant": pl.Utf8,
        "category_number": pl.Int64, "field": pl.Utf8, "value": pl.Utf8,
    })

    active_frozen = {p: tuple(sorted(cs)) for p, cs in active_categories.items()}
    return df, active_frozen, warnings


def _pick_variant(spec: ProductSpec, scheme: SchemeRecord, warnings: list[str]) -> str | None:
    rating = (scheme.rating or {}).get(spec.key)
    rating_norm = rating.strip() if isinstance(rating, str) else rating
    if spec.rating_type == "yes_no":
        if rating_norm and rating_norm.lower() != "no":
            return "default"
        return None
    # accel_standalone
    if rating_norm == "Accelerator":
        return "accelerator"
    if rating_norm == "Standalone":
        return "standalone"
    if rating_norm in (None, "No"):
        return None
    warnings.append(f"[{spec.key}] unexpected rating '{rating}', defaulting to accelerator")
    return "accelerator"


# ============================================================
# Member Data parser (- GLA or - SP)
# ============================================================
def _parse_member_sheet(ws, datemode) -> pl.DataFrame:
    if ws.nrows < 3:
        return pl.DataFrame()

    # Row 1 is the header row
    headers = []
    for c in range(ws.ncols):
        lbl = clean_text(ws.cell_value(1, c))
        headers.append(snake_case(lbl) if lbl else f"col_{c}")

    # Identify date columns by header name
    DATE_HEADERS = {"date_of_birth", "date_of_disability"}
    GENDER_HEADERS = {"gender"}
    NUMERIC_HEADERS = {
        "annual_salary", "category_flag", "custom_nra", "nra",
        "gla", "lsdb", "ci", "spouses_life_cover", "spouses_db",
        "dismemberment", "accident_death", "accident_db",
        "terminal_illness", "non_reduced", "reduced",
        "spouses_childrens_or_educ_guardian",
        "waiver", "hcc_waiver",   
    }

    records = []
    for r in range(2, ws.nrows):
        row = {}
        # Skip totally blank rows
        first_val = ws.cell_value(r, 0)
        if first_val in (None, ""):
            continue
        for c, h in enumerate(headers):
            raw = ws.cell_value(r, c)
            if h in DATE_HEADERS:
                row[h] = excel_to_date(raw, datemode)
            elif h in GENDER_HEADERS:
                row[h] = normalize_gender(raw)
            elif h in NUMERIC_HEADERS:
                row[h] = to_float(raw)
            else:
                row[h] = clean_text(raw)
        records.append(row)

    if not records:
        return pl.DataFrame()
    return pl.DataFrame(records)


# ============================================================
# Public entry point
# ============================================================
def load_ctr(ctr_path: str | Path,
             products: tuple[str, ...] | None = None) -> CTRBundle:
    ctr_path = Path(ctr_path)
    ctr_path = local_ctr_path(ctr_path)   # serve local cached copy if source is UNC (net-diag 2026-07-30)
    products = products or IN_SCOPE_PRODUCTS
    warnings: list[str] = []

    fp = _fingerprint(str(ctr_path))
    loaded_at = datetime.utcnow().isoformat(timespec="seconds") + "Z"

    t0 = time.perf_counter()
    wb = _open_workbook(ctr_path)
    available = set(wb.sheet_names())

    # --- 1. Scheme Details ---
    if "Scheme Details - Save" not in available:
        raise ValueError("CTR is missing 'Scheme Details - Save' — cannot proceed")
    t = time.perf_counter()
    ws = wb.sheet_by_name("Scheme Details - Save")
    scheme = _parse_scheme_details(ws, wb.datemode)
    try: wb.unload_sheet("Scheme Details - Save")
    except Exception: pass
    print(f"  ✓ Scheme Details - Save parsed in {time.perf_counter()-t:.2f}s")

    # --- Post-parse sanity check: catch silently-empty parses early ---
    if scheme.scheme_name is None and scheme.quote_number is None:
        raise RuntimeError(
            "[load_ctr] Scheme Details parsed but produced NO identity fields "
            "(scheme_name and quote_number both None). "
            "This usually means the reader returned empty strings for all label cells. "
            f"Sheet dims: {ws.nrows} rows × {ws.ncols} cols. "
            f"Available sheets: {sorted(available)}"
        )

    # --- Determine active products from rating ---
    _EDUCATION_PKEYS = ("educate_a_child", "education_guardian")
    active_products = tuple(
        p for p in products
        if p not in _EDUCATION_PKEYS
        and _pick_variant(PRODUCT_REGISTRY[p], scheme, warnings) is not None
    )

    # --- 2. CatInput-Save ---
    categories_df = pl.DataFrame()
    active_categories: dict[str, tuple[int, ...]] = {}
    spouse_use_sp_sheet = False
    express_over_gla: dict[str, bool] = {}
    category_split: dict[str, str] = {}
    max_cover_per_category: dict[str, dict[int, float]] = {}

    if "CatInput-Save" in available:
        t = time.perf_counter()
        ws = wb.sheet_by_name("CatInput-Save")

        # Read BJ1 flag before we unload the sheet
        spouse_use_sp_sheet = _read_spouse_source_flag(ws)

        # Read per-product options from AJ26:AK34
        express_over_gla = _read_product_options(ws)
        category_split = _read_category_split(ws)

        categories_df, active_categories, warns = _parse_catinput(ws, scheme, active_products)
        warnings.extend(warns)

        # Read per-product per-category Maximum Cover Amount
        max_cover_per_category = _read_max_cover_caps(
            ws, scheme, active_products, active_categories
        )

        # Read FC (Family Cover) per-category options + benefit grid.
        # Always returns a full dict (empty inner dicts if FC is inactive),
        # so the replace() call below is safe either way.
        fc_catinput_fields = _read_fc_catinput_fields(ws, active_categories)

        # --- Education (Educate a Child / Education Guardian) ---
        # Activation determined ENTIRELY by CatInput-Save Cover Type (col
        # 133) -- see module notes in _resolve_education_product. Always
        # called (like FC), since it's how we discover which product (if
        # either) is active for this scheme.
        education_product_pkey = _resolve_education_product(ws)
        education_fields = _read_education_catinput_fields(ws)
        if education_product_pkey is not None:
            # Wire Education's express_over_gla (row 37) onto whichever
            # variant is active -- was previously missing entirely, causing
            # _cb_education to silently fall back to False. Confirmed 2026-08-20.
            express_over_gla[education_product_pkey] = _read_education_express_over_gla(ws)
            active_edu_cats = tuple(sorted(
                c for c, is_on in education_fields["education_active"].items() if is_on
            ))
            active_categories[education_product_pkey] = active_edu_cats
            # Guard: only promote into active_products once PRODUCT_REGISTRY
            # actually has an entry for this key (added in Piece 2). Prevents
            # a KeyError in the Member Data sheet-resolution loop below
            # (`PRODUCT_REGISTRY[p]` for every p in active_products) if this
            # runs before Piece 2 lands. Safe to leave permanently -- becomes
            # a no-op once Piece 2 registers the key.
            if (education_product_pkey in PRODUCT_REGISTRY
                    and education_product_pkey not in active_products):
                active_products = active_products + (education_product_pkey,)
        
        # --- GIP per-category fields (only if GIP active) ---
        if "gip" in active_products:
            gip_fields = _read_gip_catinput_fields(ws, active_categories)   # was cat_ws
            scheme = replace(scheme, **gip_fields)

        # --- TIP per-category fields (only if TIP active) ---
        if "tip" in active_products:
            tip_fields = _read_tip_catinput_fields(ws, active_categories)
            scheme = replace(scheme, **tip_fields)

        try: wb.unload_sheet("CatInput-Save")
        except Exception: pass
        print(f"  ✓ CatInput-Save parsed in {time.perf_counter()-t:.2f}s  "
              f"({categories_df.height} rows, BJ1 spouse_use_sp_sheet={spouse_use_sp_sheet})")
        print(f"     express_over_gla = {express_over_gla}")
        print(f"     category_split   = {category_split}")
        # Compact preview of caps (avoid dumping full dict for schemes with 20 cats)
        caps_preview = {
            p: {c: (f"{v:,.0f}" if v is not None else "—")
                for c, v in list(cats.items())[:3]}
            for p, cats in max_cover_per_category.items()
        }
        print(f"     max_cover (first 3 cats/product): {caps_preview}")
        # Compact FC preview: number of FC-active cats and first cat's benefit grid
        fc_cats_ct = len(fc_catinput_fields.get("fc_benefit_amounts", {}))
        if fc_cats_ct:
            first_fc_cat = next(iter(fc_catinput_fields["fc_benefit_amounts"]))
            first_benefits = fc_catinput_fields["fc_benefit_amounts"][first_fc_cat]
            print(f"     fc: {fc_cats_ct} active cat(s); "
                  f"cat {first_fc_cat} benefits = "
                  f"{ {k: f'{v:,.0f}' for k, v in first_benefits.items()} }")
    else:
        warnings.append("CatInput-Save sheet missing")
        fc_catinput_fields = {
            "fc_max_no_of_spouses": {},
            "fc_parents_included": {},
            "fc_parents_in_law_included": {},
            "fc_include_ctc": {},
            "fc_paid_up_benefits_active": {},
            "fc_pup_death": {},
            "fc_pup_lsdb": {},
            "fc_pup_death_lsdb": {},
            "fc_benefit_amounts": {},
        }
        education_product_pkey = None
        education_fields = {
            "education_active": {}, "education_include_ctc": {},
            "education_max_cover": {}, "education_nra": {},
            "education_deferred": {}, "education_deferred_age": {},
            "education_multiple": {},
        }

    # Attach the BJ1 flag, express-over-GLA, category-split, max-cover caps
    # and FC per-category options + benefit grid onto the scheme record.
    # SchemeRecord is a frozen dataclass, so use dataclasses.replace to rebuild.
    
    scheme = replace(
        scheme,
        spouse_use_sp_sheet=spouse_use_sp_sheet,
        express_over_gla=express_over_gla,
        category_split=category_split,
        max_cover_per_category=max_cover_per_category,
        profit_refund_loading_by_product=_read_profit_refund_loading(ws),
        education_product=education_product_pkey,
        **fc_catinput_fields,
        **education_fields,
    )

    # Rate Basis — Scheme Details - Save row 3
    sd_ws = wb.sheet_by_name("Scheme Details - Save")
    rate_basis = _read_rate_basis(sd_ws)
    scheme = replace(scheme, rate_basis_by_product=rate_basis)

    # --- 3. Member Data ---
    members: dict[str, pl.DataFrame] = {}
    # Spouse products may source from either GLA or SP sheet based on BJ1 flag,
    # so we ALWAYS load whichever member sheet is present and needed.
    needed_sheets: set[str] = set()
    for p in active_products:
        spec = PRODUCT_REGISTRY[p]
        if p in ("spouse_gla", "spouse_lsdb"):
            # BJ1 flag decides source
            needed_sheets.add("Member Data - SP" if spouse_use_sp_sheet
                              else "Member Data - GLA")
        else:
            needed_sheets.add(spec.member_source)

    # Explicitly skip these even if referenced elsewhere later
    SKIP_SHEETS = {"Member Data", "GhostDraft Parameter Sheet"}
    for sheet_name in needed_sheets:
        if sheet_name in SKIP_SHEETS:
            continue
        if sheet_name not in available:
            warnings.append(f"Member sheet '{sheet_name}' missing")
            continue
        t = time.perf_counter()
        ws = wb.sheet_by_name(sheet_name)
        df = _parse_member_sheet(ws, wb.datemode)
        try: wb.unload_sheet(sheet_name)
        except Exception: pass
        # Key by short name: "Member Data - GLA" -> "gla_sheet"
        role = "gla_sheet" if sheet_name.endswith("- GLA") else \
               "sp_sheet" if sheet_name.endswith("- SP") else \
               "fc_sheet" if sheet_name.endswith("- FC") else \
               "gip_sheet" if sheet_name.endswith("- GIP") else \
               "tip_sheet" if sheet_name.endswith("- TIP") else \
               snake_case(sheet_name)
        members[role] = df
        print(f"  ✓ {sheet_name} parsed in {time.perf_counter()-t:.2f}s  ({df.height} members)")

    total = time.perf_counter() - t0
    print(f"  ⏱  Total CTR load: {total:.2f}s")

    return CTRBundle(
        ctr_path=ctr_path,
        ctr_fingerprint=fp,
        loaded_at=loaded_at,
        scheme=scheme,
        categories=categories_df,
        members=members,
        active_products=active_products,
        active_categories=active_categories,
        warnings=warnings,
    )

# --- Education (Educate a Child / Education Guardian) parser ---------------
# CatInput-Save layout confirmed 2026-08-18 (raw dump, 46 rows x 252 cols,
# cross-checked against live TT "Education" sheet formulas -- see chat
# record for full derivation). Two mutually-exclusive products share ONE
# CatInput block; a scheme-wide Cover Type cell (col 133, broadcast across
# all 20 category rows) says which one is active.
_EDU_CATEGORY_NAME_COL   = 131   # Block A
_EDU_CATEGORY_FLAG_COL   = 132
_EDU_COVER_TYPE_COL      = 133   # scheme-wide selector, broadcast per row
_EDU_INCLUDE_CTC_COL     = 134

_EDU_ACTIVE_TOGGLE_COL   = 15    # per-category Yes/No (within _CAT_TOGGLE_COLS)

_EDU_MAX_COVER_COL       = 13    # Block B
_EDU_NRA_COL             = 25
_EDU_DEFERRED_COL        = 26
_EDU_DEFERRED_AGE_COL    = 27
_EDU_MULTIPLE_COL        = 31

_EDU_BLOCK_A_ROW_START, _EDU_BLOCK_A_ROW_END = 3, 23    # Cat 1..20 (rows 3..22 inclusive)
_EDU_BLOCK_B_ROW_START, _EDU_BLOCK_B_ROW_END = 26, 46   # Cat 1..20 (rows 26..45 inclusive)

_EDU_COVER_TYPE_TO_PKEY = {
    "Guardian": "education_guardian",
    # CORRECTED 2026-08-19: the CTR's actual Cover Type literal for the
    # Educate-a-Child variant is "Multiple" (Multiple x Salary cover
    # basis), NOT the string "Educate a Child" -- confirmed via a live
    # test CTR with this variant genuinely active (CatInput-Save col 133
    # showed "Multiple" across all active category rows). The original
    # mapping was based on an unverified assumption and would have
    # silently failed to detect this product as active (education_product
    # would resolve to None) on any real Educate-a-Child scheme.
    "Multiple": "educate_a_child",
}


def _resolve_education_product(ws) -> str | None:
    "Scheme-wide Education product selector, read from CatInput-Save col 133."
    for r in range(_EDU_BLOCK_A_ROW_START, min(_EDU_BLOCK_A_ROW_END, ws.nrows)):
        raw = clean_text(_safe_cell_value(ws, r, _EDU_COVER_TYPE_COL))
        if raw:
            return _EDU_COVER_TYPE_TO_PKEY.get(raw)
    return None


def _read_education_catinput_fields(ws) -> dict[str, dict]:
    "Read Education per-category fields from CatInput-Save (Blocks A + B)."
    out: dict[str, dict] = {
        "education_active":        {},
        "education_include_ctc":   {},
        "education_max_cover":     {},
        "education_nra":           {},
        "education_deferred":      {},
        "education_deferred_age":  {},
        "education_multiple":      {},
    }

    for r in range(_EDU_BLOCK_A_ROW_START, min(_EDU_BLOCK_A_ROW_END, ws.nrows)):
        cat = r - 2
        active_raw = clean_text(_safe_cell_value(ws, r, _EDU_ACTIVE_TOGGLE_COL))
        out["education_active"][cat] = _to_bool(active_raw)
        ctc_raw = clean_text(_safe_cell_value(ws, r, _EDU_INCLUDE_CTC_COL))
        if ctc_raw is not None:
            out["education_include_ctc"][cat] = ctc_raw

    for r in range(_EDU_BLOCK_B_ROW_START, min(_EDU_BLOCK_B_ROW_END, ws.nrows)):
        cat = r - 25
        max_cover_raw = _safe_cell_value(ws, r, _EDU_MAX_COVER_COL)
        if max_cover_raw not in (None, ""):
            out["education_max_cover"][cat] = to_float(max_cover_raw)
        nra_raw = _safe_cell_value(ws, r, _EDU_NRA_COL)
        if nra_raw not in (None, ""):
            out["education_nra"][cat] = nra_raw
        deferred_raw = clean_text(_safe_cell_value(ws, r, _EDU_DEFERRED_COL))
        if deferred_raw is not None:
            out["education_deferred"][cat] = deferred_raw
        deferred_age_raw = _safe_cell_value(ws, r, _EDU_DEFERRED_AGE_COL)
        if deferred_age_raw not in (None, ""):
            out["education_deferred_age"][cat] = to_float(deferred_age_raw)
        multiple_raw = _safe_cell_value(ws, r, _EDU_MULTIPLE_COL)
        if multiple_raw not in (None, ""):
            out["education_multiple"][cat] = to_float(multiple_raw)

    return out
