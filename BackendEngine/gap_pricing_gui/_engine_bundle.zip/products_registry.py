"""Product registry: single source of truth for all in-scope products.

Adding a new product = adding one entry here. No script edits elsewhere.
9 in-scope products (sci removed — no basis/assumption tables exist).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal
import polars as pl

RatingType = Literal["yes_no", "accel_standalone"]


@dataclass(frozen=True)
class ProductSpec:
    # --- Identity ---
    key: str
    display_name: str

    # --- CTR-side labels (Scheme Details - Save) ---
    rating_label: str
    pricing_basis_label: str
    fees_priced_label: str
    basic_fee_label: str
    rating_type: RatingType

    # --- CTR CatInput-Save block anchors ---
    catinput_blocks: dict[str, tuple[int, int]]

    # --- CTR member data source ---
    member_source: str
    cover_column: str

    # --- BASIS aliases (which rows of each basis sheet belong to this product) ---
    basis_mortality: tuple[str, ...] = ()
    basis_salary_band: tuple[str, ...] = ()
    basis_industry: tuple[str, ...] = ()
    basis_regional: tuple[str, ...] = ()
    basis_trend: tuple[str, ...] = ()
    basis_waiting_periods: tuple[str, ...] = ()
    basis_product_type_adj: tuple[str, ...] = ()
    basis_education_guardian_cover: tuple[str, ...] = ()
    basis_education_guardian_salary_bands: tuple[str, ...] = ()
    uses_ti_factors: bool = False

    # --- ASSUMPTION aliases ---
    assumption_limits: tuple[str, ...] = ()
    assumption_margins: tuple[str, ...] = ()
    assumption_co: tuple[str, ...] = ()      # conversion_option product filter
    uses_lsdb_features: bool = False
    uses_spouse_factors: bool = False
    uses_ci_table_mapping: bool = False
    uses_ci_reinstatement: bool = False
    uses_ctc_options: bool = False
    uses_tax_tables: bool = False
    uses_fc_rates: bool = False
    uses_fc_demographics: bool = False
    uses_fc_family_composition: bool = False
    uses_fc_db_loading: bool = False
    # --- GIP flag-gated tables ---
    uses_gip_wp_loading: bool = False
    uses_gip_annuity_factors: bool = False
    uses_gip_esc_loading: bool = False
    uses_gip_nra_interp: bool = False
    uses_gip_wp_annuity_mapping: bool = False
    uses_gip_wp_base_inceptions: bool = False
    uses_gip_backdating_loading: bool = False
    uses_gip_rr_loading: bool = False
    uses_gip_ip_loading: bool = False
    uses_gip_db_loading: bool = False
    uses_gip_annuity_salary_bands: bool = False
    uses_gip_annuity_age_bands: bool = False
    uses_gip_hcc_basis: bool = False          # <-- the parquet we just promoted
    uses_gip_fee_table: bool = False
    uses_wp_categories: bool = False
    # --- TIP flag-gated tables (TIP-specific only; incidence reuses gip rows) ---
    # shared GIP incidence basis (flag-gated tables)
    uses_gip_wp_loading=True,
    uses_gip_rr_loading=True,
    uses_gip_wp_base_inceptions=True,
    uses_gip_annuity_salary_bands=True,   # ← BX salary tier
    uses_gip_ip_loading=True,             # ← BO IP mapped_months
    uses_tip_annuity_factors: bool = False
    uses_tip_payment_period_map: bool = False
    uses_tip_age_interp: bool = False
    uses_tip_esc_loading: bool = False
    uses_tip_wp_ann_map: bool = False
    uses_tip_db_loading: bool = False
    uses_education_guardian_table: bool = False   # new age x salary-band cover table (Piece 3)

PRODUCT_REGISTRY: dict[str, ProductSpec] = {
    "gla": ProductSpec(
        key="gla", display_name="Group Life Assurance",
        rating_label="GLA", pricing_basis_label="GLA",
        fees_priced_label="GLA", basic_fee_label="GLA",
        rating_type="yes_no",
        catinput_blocks={"default": (17, 31)},
        member_source="Member Data - GLA", cover_column="gla_cover",
        basis_mortality=("gla", "gla_aids"),
        basis_salary_band=("gla",),
        basis_industry=("gla",),
        basis_trend=("gla",),
        assumption_limits=("gla",),
        assumption_margins=("gla",),
        assumption_co=("gla",),
        uses_tax_tables=True,
    ),
    "lsdb": ProductSpec(
        key="lsdb", display_name="Lump Sum Disability Benefit",
        rating_label="LSDB", pricing_basis_label="LSDB",
        fees_priced_label="LSDB", basic_fee_label="LSDB",
        rating_type="accel_standalone",
        catinput_blocks={"accelerator": (31, 47), "standalone": (75, 91)},
        member_source="Member Data - GLA", cover_column="lsdb_cover",
        basis_mortality=("lsdb",),
        basis_salary_band=("lsdb",),
        basis_industry=("lsdb",),
        basis_trend=("lsdb",),
        basis_waiting_periods=("lsdb",),
        basis_product_type_adj=("lsdb",),
        assumption_limits=("lsdb",),
        assumption_margins=("lsdb",),
        assumption_co=("lsdb",),
        uses_lsdb_features=True,
    ),
    "ci": ProductSpec(
        key="ci", display_name="Critical Illness",
        rating_label="CI", pricing_basis_label="CI",
        fees_priced_label="CI", basic_fee_label="CI",
        rating_type="accel_standalone",
        catinput_blocks={"accelerator": (47, 60), "standalone": (91, 103)},
        member_source="Member Data - GLA", cover_column="ci_cover",
        basis_mortality=(),   # dynamic — resolved via ci_table_mapping at pricing time
        basis_salary_band=("ci", "ci_aids_acc"),
        basis_industry=("ci", "ci_acc", "ci_std", "ci_new", "ci_old"),
        basis_regional=("ci",),
        assumption_limits=("ci", "ci_existing", "ci_new"),
        assumption_margins=("ci","lsdb"),
        assumption_co=("ci",),
        uses_ci_table_mapping=True,
        uses_ci_reinstatement=True,
    ),
    "spouse_gla": ProductSpec(
        key="spouse_gla", display_name="Spouse GLA",
        rating_label="Spouse - GLA", pricing_basis_label="Spouses - GLA",
        fees_priced_label="Spouses - GLA", basic_fee_label="Spouse - GLA",
        rating_type="yes_no",
        catinput_blocks={"default": (60, 68)},
        member_source="Member Data - SP", cover_column="spouse_gla_cover",
        basis_mortality=("gla", "gla_aids"),
        basis_salary_band=("gla",),
        basis_industry=("gla",),
        basis_trend=("gla",),
        basis_regional=("spouse",),
        assumption_limits=("spouse_gla",),
        assumption_margins=("gla",),               # NEW
        assumption_co=("spouse",),
        uses_spouse_factors=True,
        uses_ctc_options=True,
    ),
    "spouse_lsdb": ProductSpec(
        key="spouse_lsdb", display_name="Spouse LSDB",
        rating_label="Spouse - LSDB", pricing_basis_label="Spouses - LSDB",
        fees_priced_label="Spouses - LSDB", basic_fee_label="Spouse - LSDB",
        rating_type="yes_no",
        catinput_blocks={"default": (68, 75)},
        member_source="Member Data - SP", cover_column="spouse_lsdb_cover",
        basis_mortality=("spouse", "spouse_aids"),
        basis_salary_band=("spouse", "spouse_aids"),
        basis_industry=("spouse",),
        basis_regional=("spouse",),
        assumption_limits=("spouse_lsdb",),
        assumption_margins=("lsdb","gla"),              # NEW
        assumption_co=("spouse",),
        uses_spouse_factors=True,
        uses_ctc_options=True,
    ),
    "terminal": ProductSpec(
        key="terminal", display_name="Terminal Illness Cover",
        rating_label="Terminal Illness Cover",
        pricing_basis_label="Terminal Illness Cover",
        fees_priced_label="Terminal Illness Cover",
        basic_fee_label="Terminal Illness Cover",
        rating_type="yes_no",
        catinput_blocks={"default": (103, 111)},
        member_source="Member Data - GLA", cover_column="terminal_illness",
        uses_ti_factors=True,
        assumption_limits=("ti",),
        assumption_margins=("ti",),
    ),
    "accident_death": ProductSpec(
        key="accident_death", display_name="Accidental Death",
        rating_label="Accidental Death", pricing_basis_label="Accidental Death",
        fees_priced_label="Accidental Death", basic_fee_label="Accidental Death",
        rating_type="yes_no",
        catinput_blocks={"default": (111, 116)},
        member_source="Member Data - GLA", cover_column="accident_death",
        basis_mortality=("adb",),
        basis_salary_band=("adb",),
        assumption_limits=("adb",),
        assumption_margins=("adb",),
    ),
    "accident_disability": ProductSpec(
        key="accident_disability", display_name="Accidental Disability",
        rating_label="Accidental Disability",
        pricing_basis_label="Accidental Disability",
        fees_priced_label="Accidental Disability",
        basic_fee_label="Accidental Disability",
        rating_type="yes_no",
        catinput_blocks={"default": (116, 121)},
        member_source="Member Data - GLA", cover_column="accident_disability",
        basis_mortality=("accdb",),
        basis_salary_band=("accdb",),
        assumption_limits=("accdb",),
        assumption_margins=("accdb",),
    ),
    "dismemberment": ProductSpec(
        key="dismemberment", display_name="Dismemberment",
        rating_label="Dismemberment", pricing_basis_label="Dismemberment",
        fees_priced_label="Dismemberment", basic_fee_label="Dismemberment",
        rating_type="yes_no",
        catinput_blocks={"default": (121, 126)},
        member_source="Member Data - GLA", cover_column="dismemberment",
        basis_mortality=("dism",),
        basis_salary_band=("dism",),
        assumption_limits=("dismem",),
        assumption_margins=("dismem",),
    ),
    "fc": ProductSpec(
        key="fc", display_name="Family Cover",
        rating_label="FC",
        pricing_basis_label="FC",
        fees_priced_label="FC",
        basic_fee_label="FC",
        rating_type="yes_no",
        catinput_blocks={"default": (135, 154)},   # CTR traced
        member_source="Member Data - FC",
        cover_column="fc_cover",
        # BASIS — all borrowed from gla (confirmed via row-4 trace)
        basis_mortality=("gla", "gla_aids"),
        basis_salary_band=("gla",),
        basis_industry=("gla",),
        basis_trend=("gla",),
        # ASSUMPTION
        assumption_limits=("fc",),
        assumption_margins=("gla",),           # FC uses Profit_Margin_GLA
        # FC-specific tables
        uses_fc_rates=True,
        uses_fc_demographics=True,
        uses_fc_family_composition=True,
        uses_fc_db_loading=True,
    ),
    "gip": ProductSpec(
        key="gip", display_name="Group Income Protection",
        rating_label="GIP", pricing_basis_label="GIP",
        fees_priced_label="GIP", basic_fee_label="GIP",
        rating_type="yes_no",
        catinput_blocks={"default": (154, 158)},   # unique leading cols only; 156..196+239 read by _read_gip_catinput_fields
        member_source="Member Data - GIP",
        cover_column="gip_cover",
        # BASIS
        basis_mortality=("gip",),
        basis_salary_band=("gip",),
        basis_industry=("gip",),
        # ASSUMPTION
        assumption_limits=("gip",),
        assumption_margins=("gip",),
        assumption_co=("gip",),
        uses_tax_tables=True,          # ← GIP tax cascade needs the 2026-2027_gip bands
        # GIP flag-gated tables ...
        # GIP flag-gated basis tables
        uses_gip_wp_loading=True,
        uses_gip_annuity_factors=True,
        uses_gip_esc_loading=True,
        uses_gip_nra_interp=True,
        uses_gip_wp_annuity_mapping=True,
        uses_gip_wp_base_inceptions=True,
        uses_gip_backdating_loading=True,
        uses_gip_rr_loading=True,
        uses_gip_ip_loading=True,
        uses_gip_db_loading=True,
        uses_gip_annuity_salary_bands=True,
        uses_gip_annuity_age_bands=True,
        uses_gip_hcc_basis=True,
        # GIP flag-gated assumption tables
        uses_gip_fee_table=True,
        uses_wp_categories=True,
    ),
    "tip": ProductSpec(
        key="tip", display_name="Temporary Income Protection",
        rating_label="TIP", pricing_basis_label="TIP",
        fees_priced_label="TIP", basic_fee_label="TIP",
        rating_type="yes_no",
        catinput_blocks={"default": (197, 201)},   # unique leading cols; rest via _read_tip_catinput_fields
        member_source="Member Data - TIP",
        cover_column="tip_cover",
        # BASIS — incidence reuses GIP truth
        basis_mortality=("gip",),
        basis_salary_band=("gip",),
        basis_industry=("gip",),
        # ASSUMPTION — shares GIP tax table + limits + margins
        assumption_limits=("gip",),
        assumption_margins=("gip",),
        uses_tax_tables=True,
        # shared GIP incidence basis (flag-gated tables)
        uses_gip_wp_loading=True,
        uses_gip_rr_loading=True,
        uses_gip_wp_base_inceptions=True,
        # TIP-specific basis
        uses_tip_annuity_factors=True,
        uses_tip_payment_period_map=True,
        uses_tip_age_interp=True,
        uses_tip_esc_loading=True,
        uses_tip_wp_ann_map=True,
        uses_tip_db_loading=True,
    ),
    "educate_a_child": ProductSpec(
        key="educate_a_child", display_name="Educate a Child",
        # Scheme Details - Save Rating Selections col 75 -- CONFIRMED anchor
        # (2026-08-18): this is the only one of the pair with a real Rating
        # Selections column. Activation is nonetheless governed by
        # CatInput-Save Cover Type (see ctr_loader_v2._resolve_education_product)
        # via the Piece 1.5 active_products guard -- rating_label/rating_type
        # here are kept for consistency with the ProductSpec shape and for
        # any future generic-path usage, but are NOT load-bearing for
        # activation today.
        rating_label="Educate a Child",
        pricing_basis_label="Educate a Child",
        fees_priced_label="Educate a Child",
        basic_fee_label="Educate a Child",
        rating_type="yes_no",
        # Shared CatInput-Save block with education_guardian (cols 131-134,
        # Excel EB:EE) -- only one of the two is ever populated/active per
        # scheme, enforced by the Cover Type selector, not by separate
        # column ranges (confirmed 2026-08-18 via raw CTR dump).
        catinput_blocks={"default": (131, 135)},
        member_source="Member Data - GLA", cover_column="education_cover",
        # BASIS -- reuses GLA's mortality/salary/industry/trend chain
        # verbatim (confirmed via live TT "Education" sheet formula trace:
        # edu Basic Premium = Education Cover x GLA Basic rate, using the
        # exact same 'GLA Basis' lookups GLA itself uses).
        basis_mortality=("gla", "gla_aids"),
        basis_salary_band=("gla",),
        basis_industry=("gla",),
        basis_trend=("gla",),
        # ASSUMPTION -- borrows GLA margins (no product-specific margin
        # table found on the Education sheet; TT's rate chain never
        # references anything but 'GLA Basis' for the rate side).
        assumption_margins=("gla",),
        uses_tax_tables=False,
    ),
    "education_guardian": ProductSpec(
        key="education_guardian", display_name="Education Guardian",
        # NOTE: unlike educate_a_child, there is NO Scheme Details - Save
        # Rating Selections column for "Education Guardian" (confirmed
        # 2026-08-18 -- only "Educate a Child" appears in that band).
        # rating_label is set for documentation/shape-consistency only;
        # activation is governed entirely by CatInput-Save Cover Type via
        # the Piece 1.5 active_products guard, NOT by this label.
        rating_label="Education Guardian",
        pricing_basis_label="Education Guardian",
        fees_priced_label="Education Guardian",
        basic_fee_label="Education Guardian",
        rating_type="yes_no",
        # Shared CatInput-Save block with educate_a_child -- see note above.
        catinput_blocks={"default": (131, 135)},
        member_source="Member Data - GLA", cover_column="education_guardian_cover",
        # BASIS -- identical GLA rate-chain reuse as educate_a_child
        # (confirmed via the same formula trace: both variants share
        # 'edu Basic Premium = Cover x GLA Basic', only the cover source
        # differs -- Guardian uses a bespoke age/salary-band table).
        basis_mortality=("gla", "gla_aids"),
        basis_salary_band=("gla",),
        basis_industry=("gla",),
        basis_trend=("gla",),
        assumption_margins=("gla",),
        assumption_limits=("education_guardian",),   # needed for product_limits.male_age_offset (Piece 3b)
        uses_tax_tables=False,
        # Bespoke cover table (age-adjusted-by-gender x 5 salary bands,
        # ages 15-75) sourced from TT 'Assumptions'!C1000:G1060 -- confirmed
        # 2026-08-18. Mirrors the uses_gip_hcc_basis pattern: a flag that
        # signals a NEW basis/assumption parquet is needed (Piece 3), not
        # yet built.
        uses_education_guardian_table=True,
        basis_education_guardian_cover=("education_guardian",),
        basis_education_guardian_salary_bands=("education_guardian",),
    ),    

}

IN_SCOPE_PRODUCTS: tuple[str, ...] = tuple(PRODUCT_REGISTRY.keys())


def get(product_key: str) -> ProductSpec:
    if product_key not in PRODUCT_REGISTRY:
        raise KeyError(f"Product '{product_key}' not registered. Available: {list(PRODUCT_REGISTRY)}")
    return PRODUCT_REGISTRY[product_key]


# ------------------------------------------------------------
# CI dynamic mortality table resolver
# ------------------------------------------------------------
def resolve_ci_mortality_table(ci_table_mapping: pl.DataFrame,
                                product_option: str,
                                variant: str) -> dict:
    """Resolve which CI mortality table to use.

    Args:
        ci_table_mapping: assump.tables['ci_table_mapping'] DataFrame
        product_option:   e.g. "Comprehensive_Plus", "Core", "Cancer_Protect"
        variant:          "accelerator" or "standalone"

    Returns dict: {"table_key": str, "age_definition": str, "variant_type": str}
    """
    row = ci_table_mapping.filter(pl.col("product_option") == product_option)
    if row.height == 0:
        raise KeyError(f"CI product_option '{product_option}' not in ci_table_mapping. "
                       f"Available: {sorted(ci_table_mapping['product_option'].unique().to_list())}")
    row = row.row(0, named=True)
    col = "accelerator_table" if variant == "accelerator" else "standalone_table"
    raw_name = str(row[col])
    # Normalise: "CI_Comprehensive_Plus" -> "ci_comprehensive_plus_acc"
    # "CI_Core_Standalone" -> "ci_core_std"
    name = raw_name.lower()
    if name.endswith("_accelerator"):
        name = name[:-len("_accelerator")] + "_acc"
    elif name.endswith("_standalone"):
        name = name[:-len("_standalone")] + "_std"
    else:
        # New products don't have variant suffix — always append _acc (single table used for both)
        name = name + "_acc"
    return {
        "table_key": name,
        "age_definition": row["age_definition"],
        "variant_type": row["variant_type"],
    }