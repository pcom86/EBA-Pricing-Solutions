"""GAP Pricing Engine — Quote Runner.

Loads a CTR, prices all in-scope products, produces a QuoteResult, and
delegates report writing to reporting.write_pricing_report.

Output artefacts (per quote)
────────────────────────────
    <scheme>_<quote>_<yyyymmdd_hhmmss>.xlsx
        Human-readable Tech Tool-format report:
            • Category Breakdown
            • Pricing Outputs
            • Meta (engine version, snapshot versions, CTR fingerprint)

    <scheme>_<quote>_<yyyymmdd_hhmmss>_calc.parquet
        Full per-member audit dump — every product, every member,
        every intermediate calculation. Written via polars for speed
        (5-10ms at 65k members). Sets up cleanly for SQL persistence.

Applied engine rules
────────────────────
    19  Rate Basis cascade
    20  Scheme-size commission
            small  = grossed-up first tier
            large  = tiered on total net
    21  CO eligibility mask
    22  LSDB pre-NRA cap
    23  profit_margin_basis
    24  Category Breakdown Basic Premium formula
    25  Frequency divisor from CTR
    26  Rate basis applied to basis_net
    27  Cover denominator = GLA cover when express_over_gla=True

Compute timing
──────────────
    Every call to price_quote() logs its wall-clock compute time to
    compute_log.txt (next to this module). The snapshot cache loads once
    per process, so:
        run 1  = COLD  (includes the one-time basis/assumption load)
        run 2+ = WARM  (CTR parse + pure pricing) — the fair headline figure
"""
from __future__ import annotations

import sys
import time
import datetime
from dataclasses import dataclass, field
from datetime import datetime as _datetime
from pathlib import Path
from typing import Any, Callable

import polars as pl


# ---------------------------------------------------------------------------
# Path setup — make all sibling packages importable
# ---------------------------------------------------------------------------
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent

if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

for _sub in ("ctr_loader", "pricing_engine", "reporting"):
    _p = _ROOT / _sub
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))


# ---------------------------------------------------------------------------
# Third-party / engine imports (after path setup)
# ---------------------------------------------------------------------------
from basis_loader import load_basis, get_basis
from engine_paths import snapshot_dir
from assumption_loader import load_assumptions, get_assumptions
from ctr_loader_v2 import load_ctr
from engine import price, build_context
from products_registry import PRODUCT_REGISTRY  # noqa: F401



# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
BASIS_SNAP  = str(snapshot_dir("basis", name="basis_v2026_08"))
ASSUMP_SNAP = str(snapshot_dir("assumption", name="assumption_A2026_08"))
PRICING_OUTPUT_DIR = _ROOT / "pricing_output"

# ---------------------------------------------------------------------------
# DB integration (single-quote only, opt-in via this flag)
# ---------------------------------------------------------------------------
# DEV ADDITION (db integration, 2026-08-25): when True, save_report() also
# loads this quote's flattened per-member results into the SQL Server
# analytics store (Scheme/CategoryConfig/MemberIdentity/Run/PricingResult)
# and lands the parquet in the S3 (or local-S3 stand-in) bucket. Requires
# write_parquet to actually run (it's the default already). A DB-load
# failure is logged but NEVER raises -- the xlsx/parquet on disk remain
# the source of truth regardless of DB status. Batch mode (concurrent_runner.py)
# does NOT call save_report() and is therefore completely unaffected by
# this flag -- it has its own independent write_pricing_report() call path.
DB_ENABLED   = True
DB_CONN_STR  = r"DRIVER={ODBC Driver 17 for SQL Server};SERVER=(localdb)\MSSQLLocalDB;DATABASE=GapPricingPoC;Trusted_Connection=yes;"
DB_S3_ROOT   = str(_ROOT / "local_s3_bucket")

_PRODUCT_DISPLAY = {
    "gla":                 "GLA",
    "lsdb":                "LSDB",
    "ci":                  "CI",
    "spouse_gla":          "Spouses - GLA",
    "spouse_lsdb":         "Spouses - LSDB",
    "terminal":            "Terminal Illness Cover",
    "accident_death":      "Accidental Death",
    "accident_disability": "Accidental Disability",
    "dismemberment":       "Dismemberment",
    "fc":                  "FC",
    "gip":                 "GIP",
    "tip":                 "TIP",
}


# ---------------------------------------------------------------------------
# Compute timing log  (writes compute_log.txt to a REAL writable folder)
# ---------------------------------------------------------------------------
import os
import tempfile


def _resolve_log_dir() -> Path:
    """Pick a writable folder for compute_log.txt.

    When the app runs via engine_bundle.activate(), quote_runner is imported
    from inside _engine_bundle.zip, so __file__ (=_HERE) points INSIDE the
    archive. You can't open a file inside a zip -> errno 2 -> 'log skipped'.
    In that case, fall back to the real folder the zip lives in (engine_bundle.HERE),
    then the cwd (the .bat pushd's onto a writable mapped drive), then temp.
    """
    if ".zip" not in str(_HERE).lower():
        return _HERE                                   # loose import: unchanged behaviour

    # running from the bundle — find a real directory
    try:
        import engine_bundle
        cand = engine_bundle.HERE                      # ...\gap_pricing_gui (where the zip lives)
        if cand.exists():
            return cand
    except Exception:
        pass

    for cand in (Path.cwd(), Path(tempfile.gettempdir())):
        try:
            if cand.exists():
                return cand
        except Exception:
            continue
    return Path(tempfile.gettempdir())


_COMPUTE_LOG = _resolve_log_dir() / "compute_log.txt"
_run_count = {"n": 0}   # process-level counter: run 1 = COLD (incl. snapshot load)


def _log_compute(scheme: str, secs: float) -> None:
    """Append one wall-clock compute timing to compute_log.txt."""
    _run_count["n"] += 1
    tag = "COLD" if _run_count["n"] == 1 else "WARM"
    line = (f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S}  "
            f"{tag}  price_quote={secs:.3f}s  scheme={scheme}")
    print(f"[compute] {tag} price_quote = {secs:.3f}s")
    try:
        with open(_COMPUTE_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as _e:
        print(f"[compute] log skipped: {_e}")


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------
@dataclass
class QuoteResult:
    """One priced quote — passed from `price_quote` to `save_report` and
    to the GUI's Results pane.
    """
    ctr_path: str
    scheme_name: str
    quote_number: str
    calculation_date: str
    active_products: tuple
    per_product_results: dict[str, pl.DataFrame]
    aggregates: dict[str, float]

    # Bundles needed by the reporting layer
    ctr_bundle:    Any = None
    assump_bundle: Any = None

    scheme_params: dict             = field(default_factory=dict)
    timings:       dict[str, float] = field(default_factory=dict)
    warnings:      list[str]        = field(default_factory=list)

    # True end-to-end wall-clock runtime for this quote (basis/assumption
    # load + CTR parse + every product's pricing time), captured by
    # price_quote()'s own _compute_t0 timer. Distinct from writer.py's
    # internal t_total, which only measures report gather/write/save.
    # Confirmed 2026-08-19: "Total Runtime (s)" on the Meta sheet was
    # always blank because this value was computed (for compute_log.txt)
    # but never stored on QuoteResult or threaded through to save_report().
    total_runtime_s: float | None = None

    # Paths to written artefacts — populated by save_report()
    xlsx_path:    Path | None = None
    parquet_path: Path | None = None

    # -----------------------------------------------------------------
    # Human-readable summary shown in the app's Results pane
    # -----------------------------------------------------------------
    def summary_text(self) -> str:
        lines: list[str] = [
            f"Scheme:     {self.scheme_name}",
            f"Quote #:    {self.quote_number}",
            f"Calc date:  {self.calculation_date}",
            f"CTR:        {Path(self.ctr_path).name}",
            "",
            "─" * 60,
            f"{'Product':<28} {'Members':>10} {'Total Premium':>18}",
            "─" * 60,
        ]

        for pkey in self.active_products:
            display = _PRODUCT_DISPLAY.get(pkey, pkey)
            df = self.per_product_results.get(pkey)
            if df is None:
                continue
            active = (
                df.filter(pl.col("product_active"))
                if "product_active" in df.columns else df
            )
            n = active.height
            total = (
                float(active["total_annual_premium"].sum())
                if "total_annual_premium" in active.columns else 0.0
            )
            lines.append(f"{display:<28} {n:>10,} {total:>18,.2f}")

        lines.append("─" * 60)
        lines.append(
            f"{'TOTAL':<28} {'':>10} "
            f"{self.aggregates.get('total_annual_premium', 0):>18,.2f}"
        )
        lines.append("")
        lines.append(
            f"Priced in {sum(self.timings.values()):.2f}s across "
            f"{len(self.active_products)} products."
        )
        lines.append("")
        lines.append("Report will include:")
        lines.append("  • Category Breakdown, Pricing Outputs, Meta   (xlsx)")
        lines.append("  • Full per-member audit dump                  (parquet)")

        if self.warnings:
            lines.append("")
            lines.append("Warnings:")
            for w in self.warnings:
                lines.append(f"  ⚠  {w}")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Pricing pipeline
# ---------------------------------------------------------------------------
def price_quote(
    ctr_path: str,
    progress_cb: Callable[[str], None] | None = None,
    scheme_params_override: dict | None = None,   # noqa: ARG001  (reserved)
) -> QuoteResult:
    """Load CTR + snapshots, price all in-scope products, return a QuoteResult.

    Parameters
    ----------
    ctr_path : str
        Absolute path to the .ctr (or .xls / .xlsx) scheme file.
    progress_cb : Callable[[str], None], optional
        Called with human-readable status strings as each stage completes.
        Used by the Tkinter app to update its status bar in real time.
    scheme_params_override : dict, optional
        Reserved for future use — allows the caller to force scheme-level
        parameters (e.g. a different commission structure) without editing
        the CTR file itself.

    Returns
    -------
    QuoteResult
        Fully populated result object ready to hand to `save_report()` or
        to render in a UI.
    """
    def _log(msg: str) -> None:
        if progress_cb:
            progress_cb(msg)

    # Wall-clock start — logged to compute_log.txt on the way out.
    _compute_t0 = time.perf_counter()

    t: dict[str, float] = {}

    # 1. Load basis snapshot (cached after first call this session)
    _log("Loading basis snapshots…")
    t0 = time.time()
    basis = get_basis(BASIS_SNAP)
    t["basis"] = time.time() - t0

    # 2. Load assumption snapshot (cached after first call this session)
    _log("Loading assumption snapshots…")
    t0 = time.time()
    assump = get_assumptions(ASSUMP_SNAP)
    t["assump"] = time.time() - t0

    # 3. Parse CTR
    _log(f"Parsing CTR: {Path(ctr_path).name}")
    t0 = time.time()
    ctr = load_ctr(ctr_path)
    t["ctr"] = time.time() - t0

    # 4. Build pricing context
    ctx = build_context(ctr, assump)

    # 5. Price each active product.
    #    Order matters: CO / CTC gates on downstream products depend on
    #    prior product results (cascade). We feed each result back into
    #    ctx.prior_results so subsequent products can reference it.
    all_results: dict[str, pl.DataFrame] = {}
    for pkey in ctr.active_products:
        _log(f"Pricing {_PRODUCT_DISPLAY.get(pkey, pkey)}…")
        t0 = time.time()
        all_results[pkey] = price(pkey, ctr, basis, assump, ctx)
        ctx.prior_results[pkey] = all_results[pkey]
        t[pkey] = time.time() - t0

    # 6. Scheme-level aggregates for the GUI status bar
    total_annual_premium = 0.0
    total_cover          = 0.0
    for df in all_results.values():
        active = (
            df.filter(pl.col("product_active"))
            if "product_active" in df.columns else df
        )
        if "total_annual_premium" in active.columns:
            total_annual_premium += float(active["total_annual_premium"].sum())
        if "total_cover" in active.columns:
            total_cover += float(active["total_cover"].sum())

    aggregates = {
        "total_annual_premium":     total_annual_premium,
        "total_subtotal_premium":   total_annual_premium,           # alias
        "total_gross_risk_premium": total_annual_premium * 1.075,   # rough
        "total_cover":              total_cover,
    }

    result = QuoteResult(
        ctr_path            = ctr_path,
        scheme_name         = str(getattr(ctr.scheme, "scheme_name", "")
                                  or Path(ctr_path).stem),
        quote_number        = str(getattr(ctr.scheme, "quote_number", "") or ""),
        calculation_date    = str(getattr(ctr.scheme, "calculation_date", "") or ""),
        active_products     = ctr.active_products,
        per_product_results = all_results,
        aggregates          = aggregates,
        ctr_bundle          = ctr,
        assump_bundle       = assump,
        timings             = t,
        warnings            = list(getattr(ctr, "warnings", []) or []),
    )

    # Log the total wall-clock compute for this quote (COLD on run 1, WARM after).
    _total_runtime = time.perf_counter() - _compute_t0
    _log_compute(result.scheme_name, _total_runtime)

    # Store on the result so save_report() can surface it on the Meta sheet
    # ("Total Runtime (s)" -- previously always blank, see QuoteResult field
    # comment above).
    result.total_runtime_s = _total_runtime

    return result


# ---------------------------------------------------------------------------
# Report writing
# ---------------------------------------------------------------------------
def save_report(
    result: QuoteResult,
    out_dir: str | Path | None = None,
    *,
    write_xlsx: bool = True,
    write_parquet: bool = True,
    write_html: bool = False,
) -> Path:
    """Write the Tech Tool-format report to disk.

    Delegates to reporting.write_pricing_report(), which can produce up
    to THREE artefacts in a single call:

        1. <name>.xlsx           Category Breakdown + Pricing Outputs + Meta
        2. <name>_calc.parquet   Full per-member audit dump
        3. <name>.html           Browsable Category Breakdown + Pricing
                                 Outputs report (same rendering pipeline
                                 as the PySide6 CB/PO viewer)

    The parquet companion is written via polars.write_parquet — 100-200x
    faster than openpyxl at large scheme sizes and roughly 5x smaller on
    disk than xlsx. It's also the exact format the future SQL persistence
    layer will consume, so no re-serialisation is needed later.

    Parameters
    ----------
    result : QuoteResult
        The output of `price_quote()`.
    out_dir : str | Path, optional
        Output folder. Defaults to `pricing_output/` next to this module.
    write_xlsx, write_parquet, write_html : bool, keyword-only
        Which artefacts to produce this call. Defaults match the original
        behaviour (xlsx + parquet, no html) so existing callers are
        unaffected. Pass write_xlsx=False, write_parquet=False,
        write_html=True for a lean HTML-only export that skips
        re-writing artefacts already saved earlier in the session.

    Returns
    -------
    Path
        Absolute path to whichever primary artefact was written this
        call, preferring xlsx > html > parquet (matches prior behaviour
        when called with defaults).
    """
    from reporting import write_pricing_report
    if out_dir is None:
        out_dir = PRICING_OUTPUT_DIR
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Filename: <scheme>[_<quote>]_<yyyymmdd_hhmmss>.xlsx
    ts           = _datetime.now().strftime("%Y%m%d_%H%M%S")
    scheme_clean = _slug(result.scheme_name)
    quote_clean  = _slug(str(result.quote_number)) if result.quote_number else ""

    fname_parts: list[str] = [scheme_clean]
    if quote_clean:
        fname_parts.append(quote_clean)
    fname_parts.append(ts)

    xlsx_path    = out_dir / ("_".join(fname_parts) + ".xlsx")
    parquet_path = xlsx_path.with_name(f"{xlsx_path.stem}_calc.parquet")
    html_path    = xlsx_path.with_suffix(".html")

    # Delegate to the reporting layer (writes whichever artefacts are requested)
    write_pricing_report(
        workbook_path       = xlsx_path,
        all_results         = result.per_product_results,
        ctr                 = result.ctr_bundle,
        assump              = result.assump_bundle,
        ctr_path            = result.ctr_path,
        basis_snapshot      = Path(BASIS_SNAP).name,
        assumption_snapshot = Path(ASSUMP_SNAP).name,
        warnings            = result.warnings,
        runtime_s           = result.total_runtime_s,
        write_xlsx          = write_xlsx,
        write_parquet       = write_parquet,
        write_html          = write_html,
    )

    # Track written artefacts on the result -- GUI + downstream consumers
    # (SQL loader, regression harness) rely on these. Only update the
    # attribute for artefacts actually requested this call, so e.g. an
    # HTML-only save doesn't clobber an xlsx_path/parquet_path set by an
    # earlier "Save xlsx" click in the same session.
    if write_xlsx:
        result.xlsx_path = xlsx_path
    if write_parquet:
        result.parquet_path = parquet_path if parquet_path.exists() else None
    if write_html:
        result.html_path = html_path if html_path.exists() else None

    # DEV ADDITION (db integration, 2026-08-25): see DB_ENABLED docstring above.
    if DB_ENABLED and result.parquet_path and result.parquet_path.exists():
        try:
            import pandas as pd
            from db_loader import load_run_to_db, LocalS3

            df_result = pd.read_parquet(result.parquet_path)
            s3 = LocalS3(DB_S3_ROOT)
            db_summary = load_run_to_db(
                DB_CONN_STR, s3, result.ctr_bundle, df_result, result.parquet_path,
                basis_snapshot=Path(BASIS_SNAP).name,
                assumption_snapshot=Path(ASSUMP_SNAP).name,
                basis_snapshot_folder=BASIS_SNAP,
                assumption_snapshot_folder=ASSUMP_SNAP,
            )
            if db_summary["status"] == "success":
                print(f"[db_loader] run {db_summary['run_id']} loaded "
                      f"({db_summary.get('rows', 0)} rows in "
                      f"{db_summary['timing'].get('total', 0):.2f}s)")
            else:
                print(f"[db_loader] load failed for {result.scheme_name}: {db_summary['error']}")
        except Exception as e:
            print(f"[db_loader] unexpected error (quote save unaffected): {e}")

    if write_xlsx:
        return xlsx_path
    if write_html:
        return html_path
    return parquet_path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _slug(s: str) -> str:
    """Filesystem-safe slug for building output filenames.

    Keeps alphanumerics, hyphens and underscores. Spaces, slashes and
    backslashes become underscores. Everything else is dropped.
    """
    if not s:
        return "unknown"
    out: list[str] = []
    for ch in str(s):
        if ch.isalnum() or ch in ("-", "_"):
            out.append(ch)
        elif ch in (" ", "/", "\\"):
            out.append("_")
    return "".join(out).strip("_") or "unknown"