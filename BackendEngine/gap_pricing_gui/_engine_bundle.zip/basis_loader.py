"""Basis loader — auto-discovers all .parquet files in a snapshot folder.

Author: Mohamed Hussein Gadiwala
Change (2026-07-29): Model B fast-load (+ Sol 5.6 deltas).
    Root cause of slow loads was per-file network open latency on the J:/UNC
    share (~0.48s fixed tax per open; diagnostic showed local reads 64-94x
    faster, threading 11-19x faster, single-open zip ~60x faster).

    Load strategy (all artifacts stay on J:, loose parquet remains source of truth):
      1. If a fresh `_snapshot_bundle.zip` exists -> ONE network open, unzip in
         RAM. (~0.19s for the 31-file basis snapshot.)
      2. Otherwise -> threaded parallel reads of the loose parquets (fallback,
         still ~0.6s), so a missing/stale bundle NEVER blocks or serves stale data.

    Freshness guard: the bundle embeds `_bundle_meta.json` = {name: [size, mtime_ns]}.
    On load we stat() the live folder (~14ms) and compare name-set + size + mtime.
    ANY mismatch => bundle is treated as stale => threaded fallback. A stale zip
    is never silently trusted.

    Deltas from Sol 5.6 review:
      * reads use rechunk=False (skip re-chunk pass on tiny tables).
      * OPT-IN process-level memory cache via get_basis() (see bottom). NOT applied
        to load_basis() itself, because caching there would bypass the freshness
        guard on repeat calls and could silently serve a stale bundle. Use get_basis()
        only where the snapshot is pinned for the process lifetime (e.g. a pricing run).

    Re-zip after any snapshot rebuild with `rezip_snapshot(folder)`.
    Only the read path changed; for_product() logic is untouched.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache, partial
import io
import json
import zipfile
from types import MappingProxyType
import polars as pl
from products_registry import PRODUCT_REGISTRY

BUNDLE_NAME = "_snapshot_bundle.zip"
_META_NAME = "_bundle_meta.json"

# read_parquet with rechunk disabled (tiny tables -> skip the re-chunk pass)
_read_parquet = partial(pl.read_parquet, rechunk=False)


@dataclass(frozen=True)
class BasisBundle:
    version: str
    built_at: str
    source_sha256: str
    tables: dict[str, pl.DataFrame]

    def for_product(self, product_key: str) -> dict[str, pl.DataFrame]:
        spec = PRODUCT_REGISTRY[product_key]
        out: dict[str, pl.DataFrame] = {}

        def _filter(sheet: str, alias: tuple[str, ...]) -> pl.DataFrame | None:
            if not alias or sheet not in self.tables:
                return None
            df = self.tables[sheet]
            if "product" not in df.columns:
                return None
            sub = df.filter(pl.col("product").is_in(list(alias)))
            return sub if sub.height > 0 else None

        # --- Product-filtered basis tables (aliased in registry) ---
        for sheet, alias in [
            ("mortality",         spec.basis_mortality),
            ("salary_band",       spec.basis_salary_band),
            ("industry",          spec.basis_industry),
            ("regional_factors",  spec.basis_regional),
            ("trend",             spec.basis_trend),
            ("waiting_periods",   spec.basis_waiting_periods),
            ("product_type_adj",  spec.basis_product_type_adj),
            ("education_guardian_cover",         spec.basis_education_guardian_cover),
            ("education_guardian_salary_bands",  spec.basis_education_guardian_salary_bands),
        ]:
            sub = _filter(sheet, alias)
            if sub is not None:
                out[sheet] = sub

        # --- TI factors (flag-gated pass-through) ---
        if spec.uses_ti_factors and "ti_factors" in self.tables:
            out["ti_factors"] = self.tables["ti_factors"]

        # --- FC-specific tables (flag-gated pass-through) ---
        for flag, sheet in [
            (spec.uses_fc_rates,               "fc_rates"),
            (spec.uses_fc_demographics,        "fc_demographics"),
            (spec.uses_fc_family_composition,  "fc_family_composition"),
            # --- GIP ---
            (spec.uses_gip_wp_loading,           "wp_loading"),
            (spec.uses_gip_annuity_factors,      "annuity_factors"),
            (spec.uses_gip_esc_loading,          "annuity_esc_loading"),
            (spec.uses_gip_nra_interp,           "annuity_nra_interpolation"),
            (spec.uses_gip_wp_annuity_mapping,   "wp_annuity_mapping"),
            (spec.uses_gip_wp_base_inceptions,   "wp_base_inceptions"),
            (spec.uses_gip_backdating_loading,   "backdating_loading"),
            (spec.uses_gip_rr_loading,           "rr_loading"),
            (spec.uses_gip_ip_loading,           "ip_loading"),
            (spec.uses_gip_db_loading,           "db_loading"),
            (spec.uses_gip_annuity_salary_bands, "annuity_salary_bands"),
            (spec.uses_gip_annuity_age_bands,    "annuity_age_bands"),
            (spec.uses_gip_hcc_basis,            "gip_hcc_basis"),
            # --- TIP-specific ---
            (spec.uses_tip_annuity_factors,    "tip_annuity_factors"),
            (spec.uses_tip_payment_period_map, "tip_payment_period_map"),
            (spec.uses_tip_age_interp,         "tip_age_interp"),
            (spec.uses_tip_esc_loading,        "tip_esc_loading"),
            (spec.uses_tip_wp_ann_map,         "tip_wp_ann_map"),
            (spec.uses_tip_db_loading,         "tip_db_loading"),
        ]:
            if flag and sheet in self.tables:
                out[sheet] = self.tables[sheet]
        return out


# --------------------------------------------------------------------------- #
# Snapshot fast-load helpers (self-contained; no shared module)               #
# --------------------------------------------------------------------------- #
def _live_stat_map(files: list[Path]) -> dict[str, list[int]]:
    """{filename: [size_bytes, mtime_ns]} for the loose parquets. stat() only."""
    out: dict[str, list[int]] = {}
    for p in files:
        st = p.stat()
        out[p.name] = [st.st_size, st.st_mtime_ns]
    return out


def _bundle_is_fresh(zpath: Path, files: list[Path]) -> bool:
    """True only if the bundle's embedded meta matches the live folder exactly."""
    if not zpath.exists():
        return False
    try:
        with zipfile.ZipFile(zpath) as zf:
            if _META_NAME not in zf.namelist():
                return False
            recorded = json.loads(zf.read(_META_NAME))
    except (zipfile.BadZipFile, json.JSONDecodeError, KeyError):
        return False  # corrupt/partial bundle -> treat as stale
    return recorded == _live_stat_map(files)


def _read_from_bundle(zpath: Path) -> dict[str, pl.DataFrame]:
    """ONE network open: pull the whole zip, unpack parquets from RAM."""
    raw = zpath.read_bytes()
    tables: dict[str, pl.DataFrame] = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        for nm in zf.namelist():
            if nm.endswith(".parquet"):
                tables[Path(nm).stem] = _read_parquet(io.BytesIO(zf.read(nm)))
    return tables


def _read_threaded(files: list[Path], max_workers: int) -> dict[str, pl.DataFrame]:
    """Fallback: parallel reads of loose parquets. Order preserved via zip()."""
    workers = max(1, min(max_workers, len(files)))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        frames = list(ex.map(_read_parquet, files))
    return {p.stem: df for p, df in zip(files, frames)}


def rezip_snapshot(folder: str | Path) -> Path:
    """(Re)build the fast-load bundle for a snapshot folder. Call after any rebuild.

    Writes `_snapshot_bundle.zip` (ZIP_STORED, no compression) containing every
    loose parquet plus `_bundle_meta.json` (size+mtime of each). Atomic: writes
    to a temp name then replaces, so a load can never see a half-written bundle.
    """
    folder = Path(folder)
    files = sorted(folder.glob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No .parquet files to bundle in {folder}")
    meta = _live_stat_map(files)
    zpath = folder / BUNDLE_NAME
    tmp = folder / f"{BUNDLE_NAME}.tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as zf:
        for p in files:
            zf.write(p, p.name)
        zf.writestr(_META_NAME, json.dumps(meta, sort_keys=True))
    tmp.replace(zpath)  # atomic on same filesystem
    return zpath


def _read_meta(folder: Path) -> dict:
    """Try optional manifest.json first, then fall back to build_log.csv, else blanks."""
    meta = {"version": folder.name, "built_at": "", "source_sha256": ""}
    mpath = folder / "manifest.json"
    if mpath.exists():
        m = json.loads(mpath.read_text())
        meta["version"]       = m.get("version", meta["version"])
        meta["built_at"]      = m.get("built_at", "")
        meta["source_sha256"] = m.get("source_sha256", "")
        return meta
    log = folder / "build_log.csv"
    if log.exists():
        try:
            df = pl.read_csv(log)
            last = df.tail(1)
            for col_meta, col_log in [
                ("built_at", "built_at"),
                ("source_sha256", "source_sha256"),
                ("version", "version"),
            ]:
                if col_log in last.columns:
                    val = last[col_log][0]
                    if val is not None:
                        meta[col_meta] = str(val)
        except Exception:
            pass
    return meta


def load_basis(folder: str | Path, max_workers: int = 32,
               use_bundle: bool = True) -> BasisBundle:
    folder = Path(folder)
    if not folder.exists():
        raise FileNotFoundError(f"Basis snapshot folder not found: {folder}")

    files = sorted(folder.glob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No .parquet files found in {folder}")

    # Fast path: fresh bundle -> single network open. Else threaded fallback.
    zpath = folder / BUNDLE_NAME
    if use_bundle and _bundle_is_fresh(zpath, files):
        tables = _read_from_bundle(zpath)
    else:
        tables = _read_threaded(files, max_workers)

    meta = _read_meta(folder)
    return BasisBundle(
        version=meta["version"],
        built_at=meta["built_at"],
        source_sha256=meta["source_sha256"],
        tables=tables,
    )


# --------------------------------------------------------------------------- #
# OPT-IN process-level singleton (Sol 5.6 "memory cache").                     #
# Use ONLY where the snapshot is pinned for the process lifetime. This caches  #
# the bundle by folder path and does NOT re-check freshness on repeat calls.   #
# Call get_basis.cache_clear() after promoting a new snapshot in a long-lived  #
# process. For anything that may see a mid-session snapshot swap, use          #
# load_basis() directly (freshness-guarded every call).                        #
# --------------------------------------------------------------------------- #
@lru_cache(maxsize=8)
def _get_basis_cached(folder: str, max_workers: int, use_bundle: bool) -> BasisBundle:
    b = load_basis(folder, max_workers=max_workers, use_bundle=use_bundle)
    # Session cache: read-only view so no consumer can add/remove/re-key a table
    # and corrupt the shared bundle reused by every quote.
    return replace(b, tables=MappingProxyType(dict(b.tables)))


def get_basis(folder, max_workers: int = 32, use_bundle: bool = True) -> BasisBundle:
    # Canonicalise args so positional/keyword/default forms collapse to ONE
    # lru_cache key (else get_basis(dir) and get_basis(dir, max_workers=32) miss
    # each other and silently reload -- the 431ms bug).
    return _get_basis_cached(str(folder), int(max_workers), bool(use_bundle))


# Preserve cache-control API on the public name so existing callers
# (e.g. app_startup.get_basis.cache_clear()) keep working after the split.
get_basis.cache_clear = _get_basis_cached.cache_clear
get_basis.cache_info = _get_basis_cached.cache_info
